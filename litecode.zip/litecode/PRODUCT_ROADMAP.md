# LiteCode — Product Roadmap

## Product promise

LiteCode should feel immediate on modest hardware, stay understandable for new developers, and grow into a capable desktop coding environment without requiring a huge extension stack to perform basic tasks.

**Principles**
- Fast startup and low idle memory are product features, not afterthoughts.
- Local-first: projects and source code remain on the user's machine unless the user explicitly opts into a connected feature.
- Native desktop capabilities belong behind a small, reviewed Rust API; the web UI should not gain unrestricted filesystem or shell access.
- Every major feature needs an explicit test plan, keyboard support, failure states, and a documented resource cost.
- Build a dependable core before adding AI, marketplaces, or dozens of bundled integrations.

## Milestone 1 — Editor foundations (current)

- [x] Stable panel/sidebar layout and core project/file workflows.
- [x] Multi-tab buffers, dirty state, session restoration, command palette, file search, terminal and live preview foundations.
- [x] Settings dialog for theme, font size, tab size, word wrap, autosave, and Python executable.
- [ ] Move session/settings storage to a versioned, validated native persistence layer; include migration and recovery.
- [ ] Recent projects and workspace history.
- [ ] Close-all / close-others / pin-tab / reopen-closed-tab.
- [ ] Split editor groups and per-group active tabs.
- [ ] File watcher abstraction with debouncing and external-change conflict handling.
- [ ] Performance baseline: cold startup, idle RAM, large-file open, tree refresh and search.

## Milestone 2 — Developer workflow

- [ ] Git integration: status, diff, stage/unstage, commit, branch display and conflict awareness.
- [ ] Diagnostics panel with severity filters and file/line navigation.
- [ ] Language Server Protocol client, enabled per language and started on demand.
- [ ] Formatter and linter integration with per-workspace configuration.
- [ ] Debug Adapter Protocol support, beginning with one language end-to-end.
- [ ] Task profiles (`.litecode/tasks.json`) and run configurations; avoid hardcoded one-command-per-language assumptions.
- [ ] Search-and-replace across project with preview and safe apply.

## Milestone 3 — Workspace and extensibility

- [ ] Typed internal command registry and contribution points for activity views, commands, menus and settings.
- [ ] Extension manifest, permissions model, versioning and compatibility checks before a public extension API.
- [ ] Workspace settings, user settings, keybinding profiles, themes and icon themes.
- [ ] Split panes, breadcrumbs, outline/symbols, minimap as an optional feature, and accessible navigation.
- [ ] Terminal profiles, environment variables and task lifecycle controls.

## Milestone 4 — Release quality

- [ ] CI matrix for Windows and Linux plus automated unit/integration tests.
- [ ] Reproducible release artifacts, signing where available, update strategy and rollback behavior.
- [ ] Crash/error reporting only with clear consent; privacy documentation and opt-out.
- [ ] Accessibility review, localization, screen-reader labels and keyboard-only workflows.
- [ ] Security review for filesystem boundaries, terminal commands, preview server, external URLs and extension permissions.
- [ ] Benchmark gates for startup, memory, large files and search latency.

## Explicit non-goals for the first public version

- Do not bundle a heavyweight browser runtime or an entire compiler toolchain by default.
- Do not run downloaded extensions with unrestricted permissions.
- Do not promise full IDE-grade debugging for every language until each adapter is tested.
- Do not ship AI features that upload code without explicit, understandable consent.

## Definition of done for each feature

A feature is not complete because the button exists. It must have a clear UX, keyboard access, error/loading/empty states, tests for important logic, persistence behavior where applicable, documentation, and a performance check on a modest machine.


## Implemented in 0.3.0
- Native Git status, stage/unstage, commit and text diff preview.
- Recent project list on the welcome screen.
- Source Control activity view and keyboard shortcut.

## Still required before calling the product release-ready
- Automated Rust/Tauri integration tests and signed platform builds.
- LSP client and language-server lifecycle management for diagnostics, semantic completion and go-to-definition.
- Debug Adapter Protocol integration, extension API and sandboxed extension management.
- Split editors, robust multi-file replace, formatter/linter integrations, settings sync/import/export, update mechanism, crash reporting opt-in, accessibility audit and measured performance baselines.
