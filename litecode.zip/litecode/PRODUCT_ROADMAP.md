### 0.8.0 update — Complete Python debugger and unified run/debug
- [x] Breakpoint gutter, paused-line highlight and automatic navigation
- [x] Spec-correct DAP startup ordering and event-race fixes; adapter exit/timeout/reconnect handling; restart
- [x] Call stack frame selection, expandable variables, exception breakpoints, debug console evaluation
- [x] Unified Run/Debug configuration (file, working directory, arguments) and clickable Python tracebacks
- [x] Child-process cleanup on exit; JS integration tests against a fake adapter; Rust unit tests written
- [ ] Verify with a real `debugpy` session and compile/run the Tauri app on Windows and Linux (blocking release)
- [ ] Conditional breakpoints / logpoints, watch expressions, attach to a running process, multi-thread selector
- [ ] Terminate the debuggee's process tree when the adapter is force-killed (currently relies on `disconnect` with `terminateDebuggee`)
- [ ] Early adapter stderr can be missed (events are subscribed after `dap_start` returns)

### 0.7.8 update — Initial visible Python debugger
- [x] Add a visible debugger panel and launch confirmation
- [x] Wire DAP initialization, launch, breakpoint setup, and configuration completion
- [x] Add continue, step, pause, stop, stack frame navigation, variable inspection, and console output
- [x] Add visual gutter markers and current execution-line decoration (done in 0.8.0)
- [ ] Verify real debugpy lifecycle and compile the Tauri desktop app on Linux and Windows

### 0.7.7 update — DAP request timeout safety

- DAP requests now have a configurable timeout (default 30 seconds; set `requestTimeoutMs: 0` to disable).
- Timeout removes the pending request and emits `requestTimeout` plus `requestTimeout:<command>` diagnostics.
- Response, send failure, and close clear their timeout handles.
- This improves protocol reliability but does not make the debugger end-to-end usable; visible UI and real adapter validation remain open.

# LiteCode — Product Roadmap

## Product promise

LiteCode should feel immediate on modest hardware, stay understandable for new developers, and grow into a capable desktop coding environment without requiring a huge extension stack to perform basic tasks.

**Principles**
- Fast startup and low idle memory are product features, not afterthoughts.
- Local-first: projects and source code remain on the user's machine unless the user explicitly opts into a connected feature.
- Native desktop capabilities belong behind a small, reviewed Rust API; the web UI should not gain unrestricted filesystem or shell access.
- Every major feature needs an explicit test plan, keyboard support, failure states, and a documented resource cost.
- Build a dependable core before adding AI, marketplaces, or dozens of bundled integrations.

## Milestone 1 — Editor foundations (current)

- [x] Stable panel/sidebar layout and core project/file workflows.
- [x] Multi-tab buffers, dirty state, session restoration, command palette, file search, terminal and live preview foundations.
- [x] Rename synchronization for open tabs, active editor language, and LSP document URIs/diagnostics.
- [x] Settings dialog for theme, font size, tab size, word wrap, autosave, and Python executable.
- [ ] Move session/settings storage to a versioned, validated native persistence layer; include migration and recovery.
- [ ] Recent projects and workspace history.
- [ ] Close-all / close-others / pin-tab / reopen-closed-tab.
- [ ] Split editor groups and per-group active tabs.
- [ ] File watcher abstraction with debouncing and external-change conflict handling.
- [ ] Performance baseline: cold startup, idle RAM, large-file open, tree refresh and search.

## Milestone 2 — Developer workflow

- [ ] Git integration: status, diff, stage/unstage, commit, branch display and conflict awareness.
- [x] Diagnostics panel with severity filters and file/line navigation (LSP-provided diagnostics).
- [ ] Language Server Protocol client, enabled per language and started on demand.
- [ ] Formatter and linter integration with per-workspace configuration.
- [ ] Debug Adapter Protocol support, beginning with one language end-to-end.
- [ ] Task profiles (`.litecode/tasks.json`) and run configurations; avoid hardcoded one-command-per-language assumptions.
- [ ] Search-and-replace across project with preview and safe apply.

## Milestone 3 — Workspace and extensibility

- [ ] Typed internal command registry and contribution points for activity views, commands, menus and settings.
- [ ] Extension manifest, permissions model, versioning and compatibility checks before a public extension API.
- [ ] Workspace settings, user settings, keybinding profiles, themes and icon themes.
- [ ] Split panes, breadcrumbs, outline/symbols, minimap as an optional feature, and accessible navigation.
- [ ] Terminal profiles, environment variables and task lifecycle controls.

## Milestone 4 — Release quality

- [ ] CI matrix for Windows and Linux plus automated unit/integration tests.
- [ ] Reproducible release artifacts, signing where available, update strategy and rollback behavior.
- [ ] Crash/error reporting only with clear consent; privacy documentation and opt-out.
- [ ] Accessibility review, localization, screen-reader labels and keyboard-only workflows.
- [ ] Security review for filesystem boundaries, terminal commands, preview server, external URLs and extension permissions.
- [ ] Benchmark gates for startup, memory, large files and search latency.

## Explicit non-goals for the first public version

- Do not bundle a heavyweight browser runtime or an entire compiler toolchain by default.
- Do not run downloaded extensions with unrestricted permissions.
- Do not promise full IDE-grade debugging for every language until each adapter is tested.
- Do not ship AI features that upload code without explicit, understandable consent.

## Definition of done for each feature

A feature is not complete because the button exists. It must have a clear UX, keyboard access, error/loading/empty states, tests for important logic, persistence behavior where applicable, documentation, and a performance check on a modest machine.


## Implemented in 0.3.0
- Native Git status, stage/unstage, commit and text diff preview.
- Recent project list on the welcome screen.
- Source Control activity view and keyboard shortcut.

## Still required before calling the product release-ready
- Automated Rust/Tauri integration tests and signed platform builds.
- LSP client and language-server lifecycle management for diagnostics, semantic completion and go-to-definition.
- Debug Adapter Protocol integration, extension API and sandboxed extension management.
- Split editors, robust multi-file replace, formatter/linter integrations, settings sync/import/export, update mechanism, crash reporting opt-in, accessibility audit and measured performance baselines.

## Implemented in 0.4.0
- Packages & Dependencies view for npm, pnpm, Yarn, Bun, pip, uv, Cargo, Composer, and RubyGems.
- Explicit confirmation before package commands run in the project terminal; package names use a conservative allow-list and command construction is covered by tests.
- Stable non-blinking CodeMirror cursor to avoid native/drawn caret double-render flicker.
- Theme toggle moved into Appearance settings; gear icon hover/press treatment improved.
- More discoverable resize handles and editor/preview minimum sizing.

## Still required before a public stable release
- Install dependencies and complete Vite/Tauri builds on Windows and Linux.
- Add integration tests for package-manager commands in real PTYs, and verify project manifest detection per ecosystem.
- Implement LSP-backed diagnostics/definitions/completion and DAP debugging.
- Add a proper extension API, extension trust model, update signing, crash reporting opt-in, accessibility review, and measured performance budgets.


## 0.5.3 implementation note
- Added an explicit HTML tag-name completion insertion path so accepting a tag can insert the closing tag and position the caret inside it.
- LSP integration, project-wide semantic completion, diagnostics, formatter/linter adapters, and debug adapter support remain future implementation work; do not describe them as available until implemented and verified.


## 0.5.5 implementation note
- Added the first native LSP transport layer: start/stop supported language-server processes and send/receive framed JSON-RPC messages.
- Supported launchers are `pylsp` for Python and `typescript-language-server --stdio` for JavaScript/TypeScript; users must install them separately and make them available on PATH.
- The editor does not yet use LSP responses for completion or diagnostics. The next step is protocol lifecycle wiring (initialize, open/change/close documents), then CodeMirror completion and diagnostic UI.


## 0.5.6 implementation note
The LSP process lifecycle is now connected to the app and document sync is implemented. LSP-powered editor completion, inline diagnostics, hover, and go-to-definition remain follow-up work; do not describe them as shipped yet.


## 0.5.7 implementation note
- Connected LSP completion responses to CodeMirror's asynchronous completion source and added hover and go-to-definition commands.
- Common server-originated requests receive conservative replies; workspace edits are intentionally not applied yet.
- Inline diagnostic decorations, proper completion text-edit ranges/snippets, and real native runtime verification remain outstanding.


## 0.5.8 implementation note

Inline diagnostic decorations and F8 / Shift+F8 navigation are now implemented. Diagnostics are stored per file path and restored when switching tabs. The next work should verify this against real pylsp and typescript-language-server processes, then improve the Problems panel and code actions. Native Rust/Tauri build has not been confirmed in this environment.


## 0.6.0 update
- [x] Add Quick Fix / Code Actions request through LSP and a command-palette entry / `Ctrl+.` shortcut.
- [x] Apply safe single-document text edits; reject cross-file and resource operations.
- [ ] Verify real Python (`pylsp`) and JS/TS (`typescript-language-server`) server behavior in the desktop runtime.
- [ ] Add version-aware document edits and full workspace-edit support before enabling multi-file refactors.


## 0.6.1 update — offline resilience
- [x] Add an advisory connection indicator without gating local editing, save, search, terminal, Git, preview, or locally installed runners.
- [x] Explain that package downloads and remote registries may fail offline, while cached packages can still work if the package manager supports offline/cache mode.
- [x] Improve language-server startup guidance when offline; LSP works offline only if its server is already installed locally.
- [ ] Verify installed desktop builds with network disconnected, including saving/reopening projects and all local workflows.
- [ ] Add controlled integration tests for package-manager offline/cache behavior; results vary by manager and project cache.


## 0.6.2 update — document formatting
- Added a Format Document command backed by LSP `textDocument/formatting`.
- Formatter edits are checked for valid document ranges and overlap before any edits are applied.
- Offline constraint: no internet is needed to format if the language server and formatter are already installed locally; first-time installs may require network access.
- Still requires native Tauri build and runtime verification in an environment with dependencies installed.

## 0.6.3
- [x] Local crash-recovery snapshot separate from debounced session persistence
- [x] Prefer newer recovery snapshot on next launch
- [x] Clear recovery snapshot after normal close/discard
- [ ] Verify recovery behavior in a real Tauri build with forced process termination and low-storage conditions

## 0.6.5 update — safe project replacement
- [x] Preview project-wide replacement counts and sample before/after lines before applying
- [x] Require explicit confirmation to modify files
- [x] Cap preview rendering to 200 files and disclose truncation
- [x] Refresh open buffers and sync updated text to active language servers after replacement
- [ ] Add native Rust command tests and verify preview/apply parity in a built Tauri app


## 0.6.6 update — workspace search precision
- [x] Navigate to the first matching column, not only the matching line
- [x] Show result counts and disclose when workspace search is truncated by safety limits
- [x] Validate search root and cap query length
- [ ] Add native Rust command tests for Unicode columns, invalid regex, and large workspaces
- [ ] Verify search behavior in a built Tauri desktop app on Windows and Linux


## 0.7.0 update — editor feel and task profiles
- [x] Add configurable cursor blink and gentle caret movement.
- [x] Respect `prefers-reduced-motion` for caret movement.
- [x] Add `.litecode/tasks.json` task profiles with explicit confirmation before shell execution.
- [x] Validate task count, field sizes, duplicate labels, and workspace-contained task working directories.
- [ ] Verify cursor rendering and task execution in a built Tauri app on Windows.
- [ ] Implement a real Debug Adapter Protocol client and end-to-end debugger adapter.


## 0.7.1 update — DAP protocol foundation
- [x] Add byte-safe DAP message framing and incremental parser with size limits
- [x] Add validated request builder and response correlation helper
- [x] Normalize breakpoint responses and validate source locations
- [x] Cover fragmented frames, multiple messages, UTF-8, malformed input, and limits in tests
- [ ] Spawn/own debug adapter processes and connect stdio transport to DAP parser
- [ ] Implement launch/attach lifecycle, breakpoints, stepping, stack trace, scopes and variables UI
- [ ] Verify caret motion visually and test rapid typing in a built Windows app


## 0.7.2 update — recovery performance
- [x] Coalesce recovery snapshot writes during continuous typing.
- [x] Flush pending snapshots when the window is hidden or leaving.
- [x] Prevent intentional-close cleanup from being undone by a late lifecycle event.
- [x] Add deterministic tests for scheduler lifecycle and write coalescing.
- [ ] Verify forced-crash recovery and storage-quota behavior in a built desktop app.


## 0.7.3 update — DAP session coordination
- [x] Correlate multiple outstanding requests with out-of-order responses
- [x] Dispatch adapter events and adapter-originated requests to listeners
- [x] Bound pending requests and reject them cleanly on close or transport failure
- [x] Add deterministic tests for session lifecycle and event routing
- [x] Connect session coordinator to a native adapter process transport
- [ ] Implement launch/attach, breakpoints, stepping, stack trace, scopes and variables UI
- [ ] Verify adapter lifecycle and debugging end-to-end in a built Tauri desktop app


## 0.7.4 update — Python DAP transport foundation
- [x] Add fixed-launcher Tauri commands for Python `debugpy.adapter` start/send/stop
- [x] Frame DAP messages over stdin/stdout with an 8 MB body limit and 16 KB header limit
- [x] Add a JavaScript bridge from Tauri events to the DAP session coordinator
- [x] Avoid exposing arbitrary executable launch arguments through the webview bridge
- [ ] Verify Rust compilation and adapter lifecycle in a built Tauri desktop app
- [ ] Add explicit launch configuration and Python target selection
- [ ] Implement breakpoint, continue/step, stack trace, scopes and variables UI

### 0.7.5 update — Python DAP workflow

The DAP workflow module now handles the standard request sequence and exposes tested APIs for launch, breakpoints, execution control, stack frames, scopes, and variables. Next: integrate this workflow with a visible Debug panel and editor breakpoint gutter, then verify the entire launch/stop lifecycle against a real local `debugpy` installation on Windows and Linux.


### 0.7.6 update — DAP lifecycle reliability

Fixed a race between the adapter's `initialized` event and listener registration, and ensured initialization failures dispose listeners and return the workflow to idle. Next: visible Debug panel and real adapter integration tests.
