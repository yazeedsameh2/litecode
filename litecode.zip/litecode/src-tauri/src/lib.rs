use ignore::WalkBuilder;
use notify::Watcher;
use portable_pty::{native_pty_system, Child, CommandBuilder, MasterPty, PtySize};
use serde::Serialize;
use std::{
    collections::HashMap,
    fs,
    io::{Read, Write},
    path::{Component, Path, PathBuf},
    sync::{
        atomic::{AtomicBool, AtomicU32, AtomicU64, Ordering},
        Arc, Mutex,
    },
    thread,
    time::Duration,
};
use tauri::{AppHandle, Emitter, State};

fn es<E: std::fmt::Display>(e: E) -> String {
    e.to_string()
}

// ───────────────────────── state ─────────────────────────

struct PtyHandle {
    master: Box<dyn MasterPty + Send>,
    writer: Box<dyn Write + Send>,
    child: Box<dyn Child + Send + Sync>,
}

struct LiveServer {
    stop: Arc<AtomicBool>,
    port: u16,
    _watcher: notify::RecommendedWatcher,
}

struct LspHandle {
    stdin: std::process::ChildStdin,
    child: std::process::Child,
    language: String,
}

struct DapHandle {
    stdin: std::process::ChildStdin,
    child: std::process::Child,
}

#[derive(Default)]
struct AppState {
    ptys: Mutex<HashMap<u32, PtyHandle>>,
    next_id: AtomicU32,
    live: Mutex<Option<LiveServer>>,
    lsps: Mutex<HashMap<u32, LspHandle>>,
    next_lsp_id: AtomicU32,
    daps: Mutex<HashMap<u32, DapHandle>>,
    next_dap_id: AtomicU32,
}

// ───────────────────────── files ─────────────────────────

#[derive(Serialize)]
struct Entry {
    name: String,
    path: String,
    is_dir: bool,
}

#[derive(Serialize)]
struct GitFile {
    path: String,
    index_status: String,
    worktree_status: String,
    staged: bool,
    untracked: bool,
}

fn git_output(root: &str, args: &[&str]) -> Result<String, String> {
    let dir = Path::new(root);
    if !dir.is_dir() { return Err("Open a valid project folder first".into()); }
    let out = std::process::Command::new("git")
        .args(args)
        .current_dir(dir)
        .output()
        .map_err(|e| format!("Git could not be started: {e}. Install Git and make sure it is on PATH."))?;
    if !out.status.success() {
        let msg = String::from_utf8_lossy(&out.stderr).trim().to_string();
        return Err(if msg.is_empty() { format!("Git exited with status {}", out.status) } else { msg });
    }
    Ok(String::from_utf8_lossy(&out.stdout).to_string())
}

#[tauri::command]
fn git_status(root: String) -> Result<Vec<GitFile>, String> {
    let output = git_output(&root, &["status", "--short", "--untracked-files=all"])?;
    let mut files = Vec::new();
    for line in output.lines() {
        if line.len() < 4 { continue; }
        let bytes = line.as_bytes();
        let index_status = (bytes[0] as char).to_string();
        let worktree_status = (bytes[1] as char).to_string();
        let path = line[3..].to_string();
        let untracked = index_status == "?" && worktree_status == "?";
        files.push(GitFile {
            path,
            index_status,
            worktree_status,
            staged: !untracked && bytes[0] != b' ',
            untracked,
        });
    }
    Ok(files)
}

#[tauri::command]
fn git_diff(root: String, path: String, staged: bool) -> Result<String, String> {
    let args: Vec<&str> = if staged {
        vec!["diff", "--cached", "--", path.as_str()]
    } else {
        vec!["diff", "--", path.as_str()]
    };
    git_output(&root, &args)
}

#[tauri::command]
fn git_stage(root: String, path: String) -> Result<(), String> {
    git_output(&root, &["add", "--", path.as_str()]).map(|_| ())
}

#[tauri::command]
fn git_unstage(root: String, path: String) -> Result<(), String> {
    // `restore --staged` preserves working-tree edits and also works for paths with spaces.
    git_output(&root, &["restore", "--staged", "--", path.as_str()]).map(|_| ())
}

#[tauri::command]
fn git_commit(root: String, message: String) -> Result<String, String> {
    let message = message.trim();
    if message.is_empty() { return Err("Enter a commit message first".into()); }
    if message.len() > 500 { return Err("Commit message must be 500 characters or fewer".into()); }
    git_output(&root, &["commit", "-m", message])
}

#[tauri::command]
fn os_name() -> String {
    std::env::consts::OS.to_string()
}

#[tauri::command]
fn list_dir(path: String) -> Result<Vec<Entry>, String> {
    let mut v: Vec<Entry> = fs::read_dir(&path)
        .map_err(es)?
        .flatten()
        .filter_map(|e| {
            let name = e.file_name().to_string_lossy().to_string();
            if name == ".git" || name == "__pycache__" || name == ".DS_Store" {
                return None;
            }
            Some(Entry {
                name,
                path: e.path().to_string_lossy().to_string(),
                is_dir: e.file_type().map(|t| t.is_dir()).unwrap_or(false),
            })
        })
        .collect();
    v.sort_by(|a, b| {
        b.is_dir
            .cmp(&a.is_dir)
            .then(a.name.to_lowercase().cmp(&b.name.to_lowercase()))
    });
    Ok(v)
}

#[tauri::command]
fn read_file(path: String) -> Result<String, String> {
    let meta = fs::metadata(&path).map_err(es)?;
    if meta.len() > 10_000_000 {
        return Err("File is larger than 10 MB".into());
    }
    let bytes = fs::read(&path).map_err(es)?;
    let text = String::from_utf8(bytes).map_err(|_| "Binary or non-UTF-8 file".to_string())?;
    Ok(text.trim_start_matches('\u{feff}').to_string())
}

#[tauri::command]
fn write_file(path: String, content: String) -> Result<(), String> {
    fs::write(&path, content).map_err(es)
}

#[tauri::command]
fn create_file(path: String) -> Result<(), String> {
    let p = Path::new(&path);
    if p.exists() {
        return Err("A file or folder with that name already exists".into());
    }
    if let Some(parent) = p.parent() {
        fs::create_dir_all(parent).map_err(es)?;
    }
    fs::File::create(p).map(|_| ()).map_err(es)
}

#[tauri::command]
fn create_dir(path: String) -> Result<(), String> {
    if Path::new(&path).exists() {
        return Err("A file or folder with that name already exists".into());
    }
    fs::create_dir_all(&path).map_err(es)
}

#[tauri::command]
fn rename_path(from: String, to: String) -> Result<(), String> {
    if Path::new(&to).exists() {
        return Err("The target name already exists".into());
    }
    fs::rename(&from, &to).map_err(es)
}

#[tauri::command]
fn delete_path(path: String) -> Result<(), String> {
    let p = Path::new(&path);
    if p.is_dir() {
        fs::remove_dir_all(p).map_err(es)
    } else {
        fs::remove_file(p).map_err(es)
    }
}

fn walker(root: &Path) -> ignore::Walk {
    WalkBuilder::new(root)
        .hidden(false)
        .filter_entry(|e| {
            let n = e.file_name().to_string_lossy();
            !matches!(
                &*n,
                "node_modules" | "__pycache__" | "venv" | ".venv" | "target" | "dist" | ".git"
            )
        })
        .build()
}

#[derive(Serialize)]
struct ReplaceResult {
    files_changed: usize,
    replacements: usize,
}

#[derive(Serialize)]
struct ReplacePreviewFile {
    path: String,
    replacements: usize,
    before: String,
    after: String,
}

#[derive(Serialize)]
struct ReplacePreview {
    files: Vec<ReplacePreviewFile>,
    files_changed: usize,
    replacements: usize,
    truncated: bool,
}

#[tauri::command]
fn preview_replace_in_files(
    root: String,
    query: String,
    replacement: String,
    case_sensitive: bool,
    use_regex: bool,
) -> Result<ReplacePreview, String> {
    let root_path = PathBuf::from(&root).canonicalize().map_err(es)?;
    if !root_path.is_dir() { return Err("Open a valid project folder first".into()); }
    if query.is_empty() { return Err("Search text cannot be empty".into()); }
    if query.len() > 1000 || replacement.len() > 10000 { return Err("Search or replacement text is too long".into()); }
    let pattern = if use_regex { query.clone() } else { regex::escape(&query) };
    let re = regex::RegexBuilder::new(&pattern)
        .case_insensitive(!case_sensitive)
        .build()
        .map_err(|e| format!("Invalid regular expression: {e}"))?;
    let replacement_value = if use_regex { replacement.clone() } else { replacement.replace('$', "$$") };
    let mut files = Vec::new();
    let mut replacements = 0usize;
    let mut files_changed = 0usize;
    let mut files_scanned = 0usize;
    let mut truncated = false;
    for entry in walker(&root_path).flatten() {
        if !entry.file_type().map(|t| t.is_file()).unwrap_or(false) { continue; }
        files_scanned += 1;
        if files_scanned > 100000 { return Err("Safety limit reached (100,000 files scanned). Narrow the search and retry.".into()); }
        let path = entry.path();
        let meta = match fs::metadata(path) { Ok(m) if m.len() <= 10_000_000 => m, _ => continue };
        if !meta.is_file() { continue; }
        let bytes = match fs::read(path) { Ok(b) => b, Err(_) => continue };
        let content = match String::from_utf8(bytes) { Ok(s) => s, Err(_) => continue };
        if !re.is_match(&content) { continue; }
        let count = re.find_iter(&content).count();
        if count == 0 { continue; }
        let after = re.replace_all(&content, replacement_value.as_str()).into_owned();
        replacements = replacements.saturating_add(count);
        files_changed = files_changed.saturating_add(1);
        if files.len() < 200 {
            files.push(ReplacePreviewFile {
                path: path.to_string_lossy().to_string(),
                replacements: count,
                before: content.lines().filter(|line| re.is_match(line)).take(3).collect::<Vec<_>>().join("\n").chars().take(240).collect(),
                after: after.lines().filter(|line| re.is_match(line) || line.contains(replacement.as_str())).take(3).collect::<Vec<_>>().join("\n").chars().take(240).collect(),
            });
        } else { truncated = true; }
    }
    Ok(ReplacePreview { files_changed, replacements, files, truncated })
}

#[tauri::command]
fn replace_in_files(
    root: String,
    query: String,
    replacement: String,
    case_sensitive: bool,
    use_regex: bool,
) -> Result<ReplaceResult, String> {
    let root_path = PathBuf::from(&root).canonicalize().map_err(es)?;
    if !root_path.is_dir() { return Err("Open a valid project folder first".into()); }
    if query.is_empty() { return Err("Search text cannot be empty".into()); }
    if query.len() > 1000 || replacement.len() > 10000 { return Err("Search or replacement text is too long".into()); }
    let pattern = if use_regex { query.clone() } else { regex::escape(&query) };
    let re = regex::RegexBuilder::new(&pattern)
        .case_insensitive(!case_sensitive)
        .build()
        .map_err(|e| format!("Invalid regular expression: {e}"))?;
    let replacement_value = if use_regex { replacement.clone() } else { replacement.replace('$', "$$") };
    let mut files_changed = 0usize;
    let mut replacements = 0usize;
    let mut files_scanned = 0usize;
    for entry in walker(&root_path).flatten() {
        if !entry.file_type().map(|t| t.is_file()).unwrap_or(false) { continue; }
        files_scanned += 1;
        if files_scanned > 100000 { return Err("Safety limit reached (100,000 files scanned). Narrow the search and retry.".into()); }
        let path = entry.path();
        let meta = match fs::metadata(path) { Ok(m) if m.len() <= 10_000_000 => m, _ => continue };
        if !meta.is_file() { continue; }
        let bytes = match fs::read(path) { Ok(b) => b, Err(_) => continue };
        let mut content = match String::from_utf8(bytes) { Ok(s) => s, Err(_) => continue };
        if !re.is_match(&content) { continue; }
        let count = re.find_iter(&content).count();
        if count == 0 { continue; }
        content = re.replace_all(&content, replacement_value.as_str()).into_owned();
        fs::write(path, content).map_err(|e| format!("Could not update {}: {e}", path.display()))?;
        files_changed += 1;
        replacements = replacements.saturating_add(count);
    }
    Ok(ReplaceResult { files_changed, replacements })
}

#[tauri::command]
async fn list_files(root: String) -> Vec<String> {
    let rootp = PathBuf::from(&root);
    let mut out = Vec::new();
    for e in walker(&rootp).flatten() {
        if e.file_type().map(|t| t.is_file()).unwrap_or(false) {
            if let Ok(r) = e.path().strip_prefix(&rootp) {
                out.push(r.to_string_lossy().replace('\\', "/"));
            }
        }
        if out.len() >= 20000 {
            break;
        }
    }
    out
}

#[derive(Serialize)]
struct Hit {
    path: String,
    line: usize,
    col: usize,
    text: String,
}

#[derive(Serialize)]
struct SearchResults {
    hits: Vec<Hit>,
    truncated: bool,
    files_scanned: usize,
}

#[tauri::command]
async fn search_in_files(
    root: String,
    query: String,
    case_sensitive: bool,
    use_regex: bool,
) -> Result<SearchResults, String> {
    if query.is_empty() {
        return Ok(SearchResults { hits: vec![], truncated: false, files_scanned: 0 });
    }
    if query.len() > 1000 { return Err("Search text is too long (maximum 1,000 bytes).".into()); }
    let rootp = PathBuf::from(&root).canonicalize().map_err(es)?;
    if !rootp.is_dir() { return Err("Open a valid project folder first".into()); }
    let pattern = if use_regex { query.clone() } else { regex::escape(&query) };
    let re = regex::RegexBuilder::new(&pattern)
        .case_insensitive(!case_sensitive)
        .build()
        .map_err(|e| format!("Invalid regular expression: {e}"))?;
    let mut hits = Vec::new();
    let mut files_scanned = 0usize;
    let mut truncated = false;
    'outer: for e in walker(&rootp).flatten() {
        if !e.file_type().map(|t| t.is_file()).unwrap_or(false) { continue; }
        files_scanned += 1;
        if files_scanned > 100_000 { truncated = true; break; }
        if e.metadata().map(|m| m.len() > 1_000_000).unwrap_or(true) { continue; }
        let Ok(text) = fs::read_to_string(e.path()) else { continue; };
        for (i, line) in text.lines().enumerate() {
            if let Some(found) = re.find(line) {
                if hits.len() >= 1000 { truncated = true; break 'outer; }
                // Count Unicode scalar values, not UTF-8 bytes, because CodeMirror columns are character based.
                let col = line[..found.start()].chars().count() + 1;
                hits.push(Hit {
                    path: e.path().to_string_lossy().to_string(),
                    line: i + 1,
                    col,
                    text: line.trim().chars().take(200).collect(),
                });
            }
        }
    }
    Ok(SearchResults { hits, truncated, files_scanned: files_scanned.min(100_000) })
}

// ───────────────────────── terminal (PTY) ─────────────────────────

#[derive(Serialize, Clone)]
struct PtyData {
    id: u32,
    data: String,
}

// Turns raw bytes into text without splitting a multi-byte character (Arabic, emoji...)
fn drain_utf8(pending: &mut Vec<u8>) -> String {
    match std::str::from_utf8(pending) {
        Ok(s) => {
            let out = s.to_string();
            pending.clear();
            out
        }
        Err(e) => {
            let up = e.valid_up_to();
            if e.error_len().is_none() {
                let out = String::from_utf8_lossy(&pending[..up]).to_string();
                pending.drain(..up);
                out
            } else {
                let out = String::from_utf8_lossy(pending).to_string();
                pending.clear();
                out
            }
        }
    }
}

#[tauri::command]
fn pty_spawn(
    app: AppHandle,
    state: State<AppState>,
    cwd: Option<String>,
    cols: u16,
    rows: u16,
) -> Result<u32, String> {
    let pair = native_pty_system()
        .openpty(PtySize {
            rows,
            cols,
            pixel_width: 0,
            pixel_height: 0,
        })
        .map_err(es)?;

    let mut cmd = if cfg!(windows) {
        let mut c = CommandBuilder::new("cmd.exe");
        c.args(["/K", "chcp 65001>nul"]);
        c
    } else {
        CommandBuilder::new(std::env::var("SHELL").unwrap_or_else(|_| "/bin/bash".to_string()))
    };
    cmd.env("TERM", "xterm-256color");
    cmd.env("PYTHONIOENCODING", "utf-8");
    cmd.env("PYTHONUTF8", "1");
    if let Some(dir) = cwd {
        if Path::new(&dir).is_dir() {
            cmd.cwd(dir);
        }
    }

    let child = pair.slave.spawn_command(cmd).map_err(es)?;
    drop(pair.slave);
    let mut reader = pair.master.try_clone_reader().map_err(es)?;
    let writer = pair.master.take_writer().map_err(es)?;
    let id = state.next_id.fetch_add(1, Ordering::SeqCst) + 1;

    let app2 = app.clone();
    thread::spawn(move || {
        let mut buf = [0u8; 8192];
        let mut pending: Vec<u8> = Vec::new();
        loop {
            match reader.read(&mut buf) {
                Ok(0) | Err(_) => break,
                Ok(n) => {
                    pending.extend_from_slice(&buf[..n]);
                    let data = drain_utf8(&mut pending);
                    if !data.is_empty() {
                        let _ = app2.emit("pty-data", PtyData { id, data });
                    }
                }
            }
        }
        let _ = app2.emit("pty-exit", id);
    });

    state.ptys.lock().unwrap().insert(
        id,
        PtyHandle {
            master: pair.master,
            writer,
            child,
        },
    );
    Ok(id)
}

#[tauri::command]
fn pty_write(state: State<AppState>, id: u32, data: String) -> Result<(), String> {
    let mut map = state.ptys.lock().unwrap();
    if let Some(p) = map.get_mut(&id) {
        p.writer.write_all(data.as_bytes()).map_err(es)?;
        let _ = p.writer.flush();
    }
    Ok(())
}

#[tauri::command]
fn pty_resize(state: State<AppState>, id: u32, cols: u16, rows: u16) -> Result<(), String> {
    let map = state.ptys.lock().unwrap();
    if let Some(p) = map.get(&id) {
        p.master
            .resize(PtySize {
                rows,
                cols,
                pixel_width: 0,
                pixel_height: 0,
            })
            .map_err(es)?;
    }
    Ok(())
}

#[tauri::command]
fn pty_kill(state: State<AppState>, id: u32) {
    let removed = state.ptys.lock().unwrap().remove(&id);
    if let Some(mut p) = removed {
        let _ = p.child.kill();
    }
}

// ───────────────────────── live server ─────────────────────────

const LIVE_SNIPPET: &str = "<script>(function(){var v=null;setInterval(function(){fetch('/__livereload',{cache:'no-store'}).then(function(r){return r.text()}).then(function(t){if(v===null)v=t;else if(v!==t)location.reload()}).catch(function(){})},600)})()</script>";

fn mime_for(p: &Path) -> &'static str {
    match p
        .extension()
        .and_then(|e| e.to_str())
        .map(|e| e.to_lowercase())
        .as_deref()
    {
        Some("html") | Some("htm") => "text/html; charset=utf-8",
        Some("css") => "text/css; charset=utf-8",
        Some("js") | Some("mjs") => "text/javascript; charset=utf-8",
        Some("json") | Some("map") => "application/json; charset=utf-8",
        Some("txt") | Some("md") | Some("py") => "text/plain; charset=utf-8",
        Some("svg") => "image/svg+xml",
        Some("png") => "image/png",
        Some("jpg") | Some("jpeg") => "image/jpeg",
        Some("gif") => "image/gif",
        Some("webp") => "image/webp",
        Some("ico") => "image/x-icon",
        Some("woff") => "font/woff",
        Some("woff2") => "font/woff2",
        Some("ttf") => "font/ttf",
        Some("wasm") => "application/wasm",
        Some("mp4") => "video/mp4",
        Some("mp3") => "audio/mpeg",
        Some("xml") => "application/xml",
        Some("pdf") => "application/pdf",
        _ => "application/octet-stream",
    }
}

fn inject(bytes: Vec<u8>) -> Vec<u8> {
    let mut s = String::from_utf8_lossy(&bytes).to_string();
    match s.rfind("</body>") {
        Some(i) => s.insert_str(i, LIVE_SNIPPET),
        None => s.push_str(LIVE_SNIPPET),
    }
    s.into_bytes()
}

fn html_escape(value: &str) -> String {
    value.replace('&', "&amp;")
        .replace('<', "&lt;")
        .replace('>', "&gt;")
        .replace('"', "&quot;")
        .replace('\'', "&#39;")
}

fn encoded_path(value: &str) -> String {
    value.split('/')
        .map(|part| percent_encoding::utf8_percent_encode(part, percent_encoding::NON_ALPHANUMERIC).to_string())
        .collect::<Vec<_>>()
        .join("/")
}

fn dir_listing(dir: &Path, root: &Path) -> String {
    let rel = dir.strip_prefix(root).unwrap_or(Path::new(""))
        .to_string_lossy().replace('\\', "/");
    let safe_rel = html_escape(&rel);
    let mut items: Vec<(String, bool)> = Vec::new();
    if let Ok(rd) = fs::read_dir(dir) {
        for e in rd.flatten() {
            let is_dir = e.file_type().map(|t| t.is_dir()).unwrap_or(false);
            items.push((e.file_name().to_string_lossy().to_string(), is_dir));
        }
    }
    items.sort_by(|a, b| b.1.cmp(&a.1).then(a.0.to_lowercase().cmp(&b.0.to_lowercase())));
    let mut s = format!(
        "<!doctype html><meta charset=utf-8><meta name=viewport content='width=device-width,initial-scale=1'><title>/{safe_rel}</title><body style=\"font-family:system-ui;padding:24px\"><h3>/{safe_rel}</h3><ul style=\"line-height:1.9\">"
    );
    let prefix = if rel.is_empty() { String::new() } else { format!("{}/", encoded_path(&rel)) };
    for (name, is_dir) in items {
        let href = format!("/{prefix}{}", encoded_path(&name));
        let slash = if is_dir { "/" } else { "" };
        s.push_str(&format!("<li><a href=\"{href}{slash}\">{}{slash}</a></li>", html_escape(&name)));
    }
    s.push_str("</ul></body>");
    s
}

fn handle(req: tiny_http::Request, root: &Path, ver: &AtomicU64) {
    use tiny_http::{Header, Response};
    let no_store = || Header::from_bytes(&b"Cache-Control"[..], &b"no-store"[..]).unwrap();
    let raw = req.url().split('?').next().unwrap_or("/").to_string();

    if raw == "/__livereload" {
        let body = ver.load(Ordering::SeqCst).to_string();
        let _ = req.respond(Response::from_string(body).with_header(no_store()));
        return;
    }

    let decoded = match percent_encoding::percent_decode_str(&raw).decode_utf8() {
        Ok(value) => value.into_owned(),
        Err(_) => {
            let _ = req.respond(Response::from_string("bad request").with_status_code(400));
            return;
        }
    };
    let rel = decoded.trim_start_matches('/');
    if rel.contains('\0') || Path::new(rel).components().any(|c| matches!(c, Component::ParentDir | Component::RootDir | Component::Prefix(_))) {
        let _ = req.respond(Response::from_string("forbidden").with_status_code(403));
        return;
    }

    // Canonicalization prevents symlinks inside the served tree from exposing
    // files outside the selected project root.
    let canonical_root = match root.canonicalize() {
        Ok(p) => p,
        Err(_) => {
            let _ = req.respond(Response::from_string("project root unavailable").with_status_code(404));
            return;
        }
    };
    let joined = canonical_root.join(rel);
    let mut path = match joined.canonicalize() {
        Ok(p) if p.starts_with(&canonical_root) => p,
        Ok(_) => {
            let _ = req.respond(Response::from_string("forbidden").with_status_code(403));
            return;
        }
        Err(_) => {
            let _ = req.respond(Response::from_string("404 Not Found").with_status_code(404));
            return;
        }
    };
    if path.is_dir() {
        let idx = path.join("index.html");
        if idx.is_file() {
            path = match idx.canonicalize() {
                Ok(p) if p.starts_with(&canonical_root) => p,
                _ => {
                    let _ = req.respond(Response::from_string("forbidden").with_status_code(403));
                    return;
                }
            };
        } else {
            let body = dir_listing(&path, &canonical_root);
            let h = Header::from_bytes(&b"Content-Type"[..], &b"text/html; charset=utf-8"[..]).unwrap();
            let _ = req.respond(Response::from_string(body).with_header(h).with_header(no_store()));
            return;
        }
    }

    match fs::read(&path) {
        Ok(bytes) => {
            let mime = mime_for(&path);
            let data = if mime.starts_with("text/html") { inject(bytes) } else { bytes };
            let h = Header::from_bytes(&b"Content-Type"[..], mime.as_bytes()).unwrap();
            let _ = req.respond(Response::from_data(data).with_header(h).with_header(no_store()));
        }
        Err(_) => {
            let _ = req.respond(Response::from_string("404 Not Found").with_status_code(404));
        }
    }
}

#[tauri::command]
fn live_start(state: State<AppState>, root: String) -> Result<u16, String> {
    let root_path = PathBuf::from(&root).canonicalize().map_err(es)?;
    if !root_path.is_dir() {
        return Err("Live Server root must be a directory".into());
    }
    let root = root_path.to_string_lossy().to_string();
    let mut guard = state.live.lock().map_err(|_| "Live Server state is unavailable")?;
    if let Some(old) = guard.take() {
        old.stop.store(true, Ordering::SeqCst);
    }

    let mut found = None;
    for p in 5500..5600u16 {
        if let Ok(s) = tiny_http::Server::http(("127.0.0.1", p)) {
            found = Some((s, p));
            break;
        }
    }
    let (server, port) = found.ok_or_else(|| "No free port between 5500 and 5599".to_string())?;

    let ver = Arc::new(AtomicU64::new(1));
    let ver_w = ver.clone();
    let mut watcher = notify::recommended_watcher(move |res: notify::Result<notify::Event>| {
        if let Ok(ev) = res {
            let noisy = ev.paths.iter().all(|p| {
                let s = p.to_string_lossy();
                s.contains(".git") || s.contains("node_modules") || s.contains("__pycache__")
            });
            if !noisy {
                ver_w.fetch_add(1, Ordering::SeqCst);
            }
        }
    })
    .map_err(es)?;
    watcher
        .watch(Path::new(&root), notify::RecursiveMode::Recursive)
        .map_err(es)?;

    let stop = Arc::new(AtomicBool::new(false));
    let stop2 = stop.clone();
    let root_path = root_path.clone();
    thread::spawn(move || {
        while !stop2.load(Ordering::SeqCst) {
            match server.recv_timeout(Duration::from_millis(300)) {
                Ok(Some(req)) => {
                    let rp = root_path.clone();
                    let v = ver.clone();
                    thread::spawn(move || handle(req, &rp, &v));
                }
                Ok(None) => {}
                Err(_) => break,
            }
        }
    });

    *guard = Some(LiveServer {
        stop,
        port,
        _watcher: watcher,
    });
    Ok(port)
}

#[tauri::command]
fn live_stop(state: State<AppState>) {
    if let Some(old) = state.live.lock().unwrap().take() {
        old.stop.store(true, Ordering::SeqCst);
    }
}

#[tauri::command]
fn live_port(state: State<AppState>) -> Option<u16> {
    state.live.lock().unwrap().as_ref().map(|l| l.port)
}

#[tauri::command]
fn open_external(url: String) -> Result<(), String> {
    let parsed = url::Url::parse(&url).map_err(|_| "Invalid preview URL")?;
    let host = parsed.host_str().unwrap_or("");
    let port = parsed.port().ok_or("Preview URL must include its port")?;
    if parsed.scheme() != "http"
        || !matches!(host, "127.0.0.1" | "localhost" | "[::1]" | "::1")
        || !(5500..5600).contains(&port)
        || !parsed.username().is_empty()
        || parsed.password().is_some()
        || url.chars().any(|c| c.is_control() || matches!(c, '"' | '\'' | '&' | '|' | '<' | '>' | '^' | '%' | '(' | ')'))
    {
        return Err("Only valid LiteCode localhost preview URLs can be opened".into());
    }
    #[cfg(target_os = "windows")]
    {
        use std::os::windows::process::CommandExt;
        std::process::Command::new("cmd")
            .args(["/C", "start", "", &url])
            .creation_flags(0x08000000)
            .spawn()
            .map_err(es)?;
    }
    #[cfg(target_os = "linux")]
    {
        std::process::Command::new("xdg-open").arg(&url).spawn().map_err(es)?;
    }
    #[cfg(target_os = "macos")]
    {
        std::process::Command::new("open").arg(&url).spawn().map_err(es)?;
    }
    Ok(())
}

// ───────────────────────── language servers (LSP transport) ─────────────────────────

// The UI sends/receives standard LSP JSON-RPC payloads through these commands.
// Only known server launchers are supported; arguments are fixed to avoid
// turning this bridge into an arbitrary shell execution surface.
#[tauri::command]
fn lsp_start(app: AppHandle, state: State<AppState>, language: String, root: String) -> Result<u32, String> {
    let root_path = PathBuf::from(&root).canonicalize().map_err(es)?;
    if !root_path.is_dir() { return Err("Open a valid project folder before starting a language server".into()); }

    let (program, args): (&str, &[&str]) = match language.as_str() {
        "python" => ("pylsp", &[]),
        "typescript" | "javascript" => ("typescript-language-server", &["--stdio"]),
        _ => return Err("Supported LSP launchers: Python (pylsp) and JavaScript/TypeScript (typescript-language-server). Install the server separately and ensure it is on PATH.".into()),
    };

    let mut child = std::process::Command::new(program)
        .args(args)
        .current_dir(&root_path)
        .stdin(std::process::Stdio::piped())
        .stdout(std::process::Stdio::piped())
        .stderr(std::process::Stdio::piped())
        .spawn()
        .map_err(|e| format!("Could not start {program}: {e}. Install the language server and ensure it is on PATH."))?;
    let stdin = child.stdin.take().ok_or("Language server stdin unavailable")?;
    let mut stdout = child.stdout.take().ok_or("Language server stdout unavailable")?;
    let mut stderr = child.stderr.take().ok_or("Language server stderr unavailable")?;
    let id = state.next_lsp_id.fetch_add(1, Ordering::SeqCst) + 1;
    let app_out = app.clone();
    thread::spawn(move || {
        use std::io::BufRead;
        let mut reader = std::io::BufReader::new(&mut stdout);
        loop {
            let mut content_length = None;
            loop {
                let mut line = String::new();
                match reader.read_line(&mut line) {
                    Ok(0) | Err(_) => return,
                    Ok(_) => {
                        if line == "\r\n" || line == "\n" { break; }
                        if let Some((key, value)) = line.split_once(':') {
                            if key.eq_ignore_ascii_case("Content-Length") {
                                content_length = value.trim().parse::<usize>().ok();
                            }
                        }
                    }
                }
            }
            let Some(length) = content_length.filter(|n| *n <= 8_000_000) else { continue; };
            let mut body = vec![0u8; length];
            if reader.read_exact(&mut body).is_err() { return; }
            if let Ok(message) = serde_json::from_slice::<serde_json::Value>(&body) {
                let _ = app_out.emit(&format!("lsp-message-{id}"), message);
            }
        }
    });
    let app_err = app.clone();
    thread::spawn(move || {
        use std::io::Read;
        let mut buf = [0u8; 2048];
        loop {
            match stderr.read(&mut buf) {
                Ok(0) | Err(_) => break,
                Ok(n) => {
                    let text = String::from_utf8_lossy(&buf[..n]).to_string();
                    let _ = app_err.emit(&format!("lsp-stderr-{id}"), text);
                }
            }
        }
    });
    state.lsps.lock().map_err(|_| "Language server registry unavailable")?.insert(id, LspHandle { stdin, child, language });
    Ok(id)
}

#[tauri::command]
fn lsp_send(state: State<AppState>, id: u32, message: serde_json::Value) -> Result<(), String> {
    use std::io::Write;
    let body = serde_json::to_vec(&message).map_err(es)?;
    if body.len() > 8_000_000 { return Err("LSP message exceeds the 8 MB safety limit".into()); }
    let mut registry = state.lsps.lock().map_err(|_| "Language server registry unavailable")?;
    let server = registry.get_mut(&id).ok_or("Language server is not running")?;
    write!(server.stdin, "Content-Length: {}\r\n\r\n", body.len()).map_err(es)?;
    server.stdin.write_all(&body).map_err(es)?;
    server.stdin.flush().map_err(es)
}

#[tauri::command]
fn lsp_stop(state: State<AppState>, id: u32) -> Result<(), String> {
    let server = state.lsps.lock().map_err(|_| "Language server registry unavailable")?.remove(&id);
    if let Some(mut server) = server {
        let _language = server.language;
        let _ = server.child.kill();
        let _ = server.child.wait();
    }
    Ok(())
}


// ───────────────────────── debug adapters (DAP transport) ─────────────────────────

// Deliberately supports a fixed Python debugpy launcher rather than accepting an
// arbitrary executable from the webview. This keeps the bridge from becoming a
// general-purpose command execution endpoint.
#[tauri::command]
fn dap_start(app: AppHandle, state: State<AppState>, root: String) -> Result<u32, String> {
    let root_path = PathBuf::from(&root).canonicalize().map_err(es)?;
    if !root_path.is_dir() { return Err("Open a valid project folder before starting the debugger".into()); }
    #[cfg(target_os = "windows")]
    let program = "python";
    #[cfg(not(target_os = "windows"))]
    let program = "python3";

    let mut child = std::process::Command::new(program)
        .args(["-m", "debugpy.adapter"])
        .current_dir(&root_path)
        .stdin(std::process::Stdio::piped())
        .stdout(std::process::Stdio::piped())
        .stderr(std::process::Stdio::piped())
        .spawn()
        .map_err(|e| format!("Could not start Python debug adapter: {e}. Install debugpy in the selected Python environment."))?;
    let stdin = child.stdin.take().ok_or("Debug adapter stdin unavailable")?;
    let mut stdout = child.stdout.take().ok_or("Debug adapter stdout unavailable")?;
    let mut stderr = child.stderr.take().ok_or("Debug adapter stderr unavailable")?;
    let id = state.next_dap_id.fetch_add(1, Ordering::SeqCst) + 1;

    let app_out = app.clone();
    thread::spawn(move || {
        loop {
            let mut header = Vec::with_capacity(128);
            let mut previous = [0u8; 4];
            loop {
                let mut byte = [0u8; 1];
                if stdout.read_exact(&mut byte).is_err() { return; }
                header.push(byte[0]);
                previous = [previous[1], previous[2], previous[3], byte[0]];
                if previous == [13, 10, 13, 10] { break; }
                if header.len() > 16 * 1024 { let _ = app_out.emit(&format!("dap-error-{id}"), "Debug adapter header exceeded 16 KB"); return; }
            }
            let header_text = String::from_utf8_lossy(&header);
            let lengths: Vec<usize> = header_text.lines().filter_map(|line| {
                let (key, value) = line.split_once(':')?;
                if key.trim().eq_ignore_ascii_case("Content-Length") { value.trim().parse().ok() } else { None }
            }).collect();
            if lengths.len() != 1 || lengths[0] > 8_000_000 {
                let _ = app_out.emit(&format!("dap-error-{id}"), "Debug adapter sent an invalid or oversized Content-Length header");
                return;
            }
            let mut body = vec![0u8; lengths[0]];
            if stdout.read_exact(&mut body).is_err() { return; }
            match serde_json::from_slice::<serde_json::Value>(&body) {
                Ok(message) => { let _ = app_out.emit(&format!("dap-message-{id}"), message); }
                Err(_) => { let _ = app_out.emit(&format!("dap-error-{id}"), "Debug adapter sent invalid JSON"); return; }
            }
        }
    });
    let app_err = app.clone();
    thread::spawn(move || {
        let mut buf = [0u8; 2048];
        loop {
            match stderr.read(&mut buf) {
                Ok(0) | Err(_) => break,
                Ok(n) => {
                    let text = String::from_utf8_lossy(&buf[..n]).to_string();
                    let _ = app_err.emit(&format!("dap-stderr-{id}"), text);
                }
            }
        }
    });
    state.daps.lock().map_err(|_| "Debug adapter registry unavailable")?.insert(id, DapHandle { stdin, child });
    Ok(id)
}

#[tauri::command]
fn dap_send(state: State<AppState>, id: u32, message: serde_json::Value) -> Result<(), String> {
    let body = serde_json::to_vec(&message).map_err(es)?;
    if body.len() > 8_000_000 { return Err("DAP message exceeds the 8 MB safety limit".into()); }
    if !message.is_object() || message.get("type").and_then(|v| v.as_str()).is_none() {
        return Err("DAP message must be a JSON object with a type".into());
    }
    let mut registry = state.daps.lock().map_err(|_| "Debug adapter registry unavailable")?;
    let adapter = registry.get_mut(&id).ok_or("Debug adapter is not running")?;
    write!(adapter.stdin, "Content-Length: {}\r\n\r\n", body.len()).map_err(es)?;
    adapter.stdin.write_all(&body).map_err(es)?;
    adapter.stdin.flush().map_err(es)
}

#[tauri::command]
fn dap_stop(state: State<AppState>, id: u32) -> Result<(), String> {
    let adapter = state.daps.lock().map_err(|_| "Debug adapter registry unavailable")?.remove(&id);
    if let Some(mut adapter) = adapter {
        let _ = adapter.child.kill();
        let _ = adapter.child.wait();
    }
    Ok(())
}

// ───────────────────────── entry ─────────────────────────

pub fn run() {
    tauri::Builder::default()
        .plugin(tauri_plugin_dialog::init())
        .manage(AppState::default())
        .invoke_handler(tauri::generate_handler![
            os_name,
            git_status,
            git_diff,
            git_stage,
            git_unstage,
            git_commit,
            list_dir,
            read_file,
            write_file,
            create_file,
            create_dir,
            rename_path,
            delete_path,
            list_files,
            replace_in_files,
            preview_replace_in_files,
            search_in_files,
            pty_spawn,
            pty_write,
            pty_resize,
            pty_kill,
            live_start,
            live_stop,
            live_port,
            open_external,
            lsp_start,
            lsp_send,
            lsp_stop,
            dap_start,
            dap_send,
            dap_stop
        ])
        .run(tauri::generate_context!())
        .expect("error while running LiteCode");
}
