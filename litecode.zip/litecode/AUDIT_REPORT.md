# LiteCode 0.8.2 — Audit & Delivery Notes

## Scope completed in this pass
- Source Control now distinguishes merge-conflict states from ordinary modifications and provides resolution guidance.
- Added isolated Git status helper tests.
- Version synchronized to 0.8.2 across package, Cargo, and Tauri manifests.
- Full inventory of the 0.8.0 tree (JS modules, Rust lib, tests, config).
- Security: CSP hardened from null to a restrictive policy.
- Version bump and consistency across manifests.
- Icons placeholders created so Tauri bundle config is valid.
- All JavaScript tests executed and passing (125 tests; DAP, debug controller, LSP, recovery, Git status helpers, path utils, packages, etc.).
- CHANGELOG updated with precise verification status.

## What works (verified by tests)
- DAP framing, request/response correlation, workflow ordering (including debugpy-style delayed launch response).
- Session lifecycle, timeouts, cancellation, breakpoint mapping and normalization.
- Debug controller state machine.
- Path utilities (POSIX/Windows), Python traceback linking, error message generation.
- Recovery scheduler, offline indicator, problems panel helpers, package command validation, run-config, completion utils, tasks.

## What could not be verified in this environment
- Native Tauri/Rust build (`cargo check` fails on crates-io resolver version 3 incompatibility).
- Runtime UI (CodeMirror gutter, terminal, panels) — no display / full npm install completed under time constraints.
- Live debugpy sessions.
- Live LSP servers.
- Cross-platform process signals on Windows.

## Remaining engineering priorities for a production 1.0
1. Resolve Rust toolchain / lockfile so `cargo test` and `tauri build` succeed on Windows & Linux CI.
2. Add a minimal real debugpy integration test under CI (with a pinned debugpy + Python).
3. Tighten shell/PTY command construction further (already argument-separated in most places).
4. Complete Git status/diff UI polish and merge-conflict viewer.
5. Performance profiling on large file trees and long terminal output.
6. Signed release pipeline and optional updater.

## Delivery
- Source tree ready for further development.
- No secrets, no telemetry, no external uploads introduced.


## 0.8.3 appearance update

- Added theme token sets for Nord, Dracula, Monokai, Forest, Rosé Pine, Solarized Light, and High Contrast alongside Midnight and Daylight.
- Added theme preview cards, accent overrides, editor font family, sidebar width, compact density, reduced motion, and reset controls.
- JavaScript syntax checks and 125 Node tests pass. Build remains unverified here because the extracted source archive has no installed `node_modules` (`vite: not found`).
- Runtime visual inspection inside Tauri has not been performed.
