# LiteCode 0.4.0 — engineering notes

## Changes in this iteration
- Added a Packages & Dependencies sidebar. Supported managers: npm, pnpm, Yarn, Bun, pip, uv, Cargo, Composer, and RubyGems.
- Package installs and project dependency installs require explicit user confirmation and execute in the integrated terminal at the opened project root.
- Package names are validated against a conservative allow-list. The package command builder is isolated in `src/packages.js` and covered by unit tests. This is input validation, not a sandbox: package manager scripts may execute arbitrary code as part of installation.
- Moved the quick theme toggle from the activity bar into Settings > Appearance.
- Improved settings gear hover/press feedback and made resize handles easier to discover.
- Disabled CodeMirror cursor blinking and hid the browser's native caret to avoid a double-rendered/flickering cursor.
- Added package workflows to the command palette and updated version metadata to 0.4.0.

## Checks performed
- `node --check` passed for edited JavaScript modules.
- `node --test` passed: 8 tests total, including package command construction and rejection of shell injection-like package names.
- HTML ID/reference check passed; no duplicate IDs or missing static `$()` selectors were found.
- `package.json` and `src-tauri/tauri.conf.json` parsed as valid JSON.

## Not verified in this environment
- `npm run build` could not run because dependencies are not installed (`vite: not found`).
- Tauri/Rust native build and runtime UI tests were not performed.
- Package managers were not invoked against live projects; package manifests must exist for the chosen manager's dependency command.

## Release blockers / next engineering work
- Complete clean dependency installation and release builds on supported OSes.
- Add PTY integration tests for package installation, cancel/exit/error cases, and command behavior on Windows/Linux.
- Add manifest-aware manager selection and Python environment/venv detection.
- Implement LSP and DAP integration, extension sandbox/trust policy, signed releases/updater, accessibility and performance profiling.


## 0.5.8 incremental review

- Added pure range-mapping tests for LSP diagnostics, including clamping and UTF-16 offsets.
- Inline diagnostic rendering is implemented through CodeMirror state-field decorations; runtime validation still required.
- F8 and Shift+F8 navigate between diagnostics in the active file.
- Remaining limitation: diagnostics arrive only when the configured language server publishes them; this does not replace a full Problems panel or code-action support.
