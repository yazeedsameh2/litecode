# LiteCode — Audit and changes

## Changes made

- Session snapshots now include each open tab's current buffer, clean baseline, cursor, untitled document name, and active untitled tab metadata. Editor changes schedule a debounced session save. On restore, unsaved buffers are reconstructed without writing them to disk. Older session records remain supported.
- Choosing **Discard** in the close-window prompt now resets dirty buffers to their clean baseline before saving the session, preventing discarded edits from being recovered on the next launch. Failed saves now stop the close sequence rather than allowing it to continue.
- Runner paths are quoted per shell style: POSIX arguments use single-quote escaping, and Windows arguments are double-quoted. Added tests for path helpers, HTML preview detection, paths with spaces, shell-special characters, and unsupported extensions.
- Live Server request paths are UTF-8 validated, checked for traversal components, canonicalized, and constrained to the canonical project root to block symlink escapes. Directory listings now HTML-escape displayed names and percent-encode URL path segments. Directory listings also send no-store headers.
- External preview URLs are parsed structurally and restricted to HTTP localhost addresses using LiteCode's preview port range. URLs containing command-shell metacharacters are rejected before launching the external browser.
- Added an `npm test` script and documented developer checks.

## Verification performed

- `node --test`: 5 tests passed.
- `node --check` on all frontend JavaScript files and the test file: passed.
- JSON configuration and Cargo TOML syntax parsing: passed.

## Not verified in this environment

- `npm install --ignore-scripts --no-audit --no-fund` did not complete within the available time.
- `npm run build` could not run because dependencies were not installed (`vite: not found`).
- Rust compilation, formatting, and native Tauri builds could not be run because `rustc` and `cargo` are not installed in this environment.
- The application was not launched for manual end-to-end testing. Windows-specific shell behavior and the Rust Live Server changes therefore need a real platform build and runtime test before release.


## Follow-up UX and Live Server pass

- Fixed the sidebar collapse layout by explicitly assigning the activity bar, sidebar, resize handle, main work area, and status bar to grid columns/rows. Without explicit placement, hiding the sidebar caused the main editor to auto-flow into a zero-width column.
- Explorer visibility now updates active icon state and saves the layout after the transition.
- When Live Server is active, edits to saved project files are debounced and written to disk so the server's file watcher can trigger browser refresh. Starting Live Server and manually reloading the preview also save dirty open project files first.
- Preview reload now uses a cache-busting query parameter rather than assigning the identical URL, making the reload button deterministic even with browser caching.
- Refined the UI with subtle borders, low-contrast shadows, hover/active transforms, transitions, focus-visible outlines, and reduced-motion support.
- Re-ran `node --check` on the changed JavaScript and the existing Node test suite (5/5 passed). Full Vite/Tauri build still requires dependencies and Rust tooling to be installed in the build environment.

## Product-scale pass (0.3.0)

### Added
- Source Control sidebar powered by native Git commands: status, staged/unstaged grouping, stage/unstage, diff preview, and commit messages.
- Project-wide replace with literal or regex search, case sensitivity, confirmation, file-size/type exclusions, and reload of open buffers after changes.
- Recent project shortcuts on the welcome screen.
- Keyboard shortcut Ctrl+Shift+G and command palette entry for Source Control.

### Validation in this environment
- `node --check` passed for all JavaScript source and test files.
- `node --test`: 5/5 tests passed.
- JSON configuration parsing passed.
- `npm install` did not finish within the available execution window, so `npm run build` could not be verified.
- Rust/Cargo are unavailable in this environment, so native Tauri compilation and the new Rust Git/replace commands have not been compiler-verified here.

This package is a feature-complete development snapshot, not yet a signed or independently release-certified desktop installer. Complete native build and smoke tests on Windows and Linux before distributing it publicly.
