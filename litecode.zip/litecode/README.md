# LiteCode

محرر أكواد خفيف وسريع (Tauri + Rust + CodeMirror 6) يعمل على Windows وLinux.

## المميزات
- محرر بتلوين كود وإكمال تلقائي وEmmet وطي وبحث واستبدال وأكثر من مؤشر
- مستكشف ملفات، تبويبات، Ctrl+P، لوحة أوامر، بحث داخل المشروع
- تيرمنال حقيقي سفلي، وزر Run لتشغيل Python/JS/C/C++/Java/Rust/Go/PHP/Ruby/Bash
- Live Server مع معاينة مدمجة وإعادة تحميل تلقائية عند الحفظ
- ثيم داكن وفاتح، وحفظ الجلسة

## الاختصارات
| الاختصار | الوظيفة |
|---|---|
| Ctrl+Shift+O | فتح مجلد |
| Ctrl+P | فتح ملف بالاسم (اكتب `>` للأوامر، `:` لرقم السطر) |
| Ctrl+Shift+P / F1 | لوحة الأوامر |
| F5 | تشغيل الملف الحالي |
| Ctrl+` | إظهار/إخفاء التيرمنال |
| Ctrl+Alt+L | تشغيل/إيقاف Live Server |
| Ctrl+S / Ctrl+Shift+S | حفظ / حفظ باسم |
| Ctrl+B | إظهار/إخفاء الشريط الجانبي |
| Ctrl+Shift+F | بحث في كل الملفات |
| Ctrl+= / Ctrl+- | تكبير / تصغير الخط |

## البناء
البناء يتم تلقائياً على GitHub Actions (ملف `.github/workflows/build.yml`):
1. ارفع المشروع على مستودع GitHub.
2. افتح تبويب **Actions** وانتظر انتهاء `build`.
3. نزّل `LiteCode-Windows` (ملف exe) أو `LiteCode-Linux-Zorin` (ملف deb) من أسفل صفحة التشغيل.

بناء محلي (اختياري): ثبّت Node 20 وRust ثم:
```
npm install
npx tauri icon app-icon.png
npx tauri build
```
