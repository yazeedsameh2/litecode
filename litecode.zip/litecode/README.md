# LiteCode

محرر أكواد خفيف وسريع (Tauri + Rust + CodeMirror 6) يعمل على Windows وLinux.

## المميزات
- محرر بتلوين كود وإكمال تلقائي وEmmet وطي وبحث واستبدال وأكثر من مؤشر
- مستكشف ملفات، تبويبات، Ctrl+P، لوحة أوامر، بحث داخل المشروع، ومشاريع حديثة على شاشة الترحيب
- تيرمنال حقيقي سفلي، وزر Run لتشغيل Python/JS/C/C++/Java/Rust/Go/PHP/Ruby/Bash
- Live Server مع معاينة مدمجة وإعادة تحميل تلقائية عند الحفظ
- Git Source Control مدمج: عرض التغييرات، معاينة diff، stage/unstage، وإنشاء commit
- استبدال شامل داخل المشروع يدعم النص العادي أو Regex، مع تأكيد قبل التعديل
- ثيم داكن وفاتح، وحفظ الجلسة، ولوحة إعدادات مباشرة لتخصيص الخط والمسافات والحفظ التلقائي

## الاختصارات
| الاختصار | الوظيفة |
|---|---|
| Ctrl+Shift+O | فتح مجلد |
| Ctrl+P | فتح ملف بالاسم (اكتب `>` للأوامر، `:` لرقم السطر) |
| Ctrl+Shift+P / F1 | لوحة الأوامر |
| F5 | تشغيل الملف الحالي |
| Ctrl+` | إظهار/إخفاء التيرمنال |
| Ctrl+Alt+L | تشغيل/إيقاف Live Server |
| Ctrl+S / Ctrl+Shift+S | حفظ / حفظ باسم |
| Ctrl+B | إظهار/إخفاء الشريط الجانبي |
| Ctrl+Shift+F | بحث في كل الملفات |
| Ctrl+Shift+G | إدارة تغييرات Git |
| Ctrl+, | فتح الإعدادات |
| Ctrl+= / Ctrl+- | تكبير / تصغير الخط |

## البناء
البناء يتم تلقائياً على GitHub Actions (ملف `.github/workflows/build.yml`):
1. ارفع المشروع على مستودع GitHub.
2. افتح تبويب **Actions** وانتظر انتهاء `build`.
3. نزّل `LiteCode-Windows` (ملف exe) أو `LiteCode-Linux-Zorin` (ملف deb) من أسفل صفحة التشغيل.

بناء محلي (اختياري): ثبّت Node 20 وRust ثم:
```
npm install
npx tauri icon app-icon.png
npx tauri build
```


## Developer checks

Run the lightweight JavaScript unit tests with `npm test`. They cover cross-platform path helpers and command construction for filenames containing spaces and shell metacharacters. Build the frontend with `npm run build`; build the desktop app with the Tauri CLI after installing the Rust toolchain and the platform-specific prerequisites.


## Product direction

See [`PRODUCT_ROADMAP.md`](PRODUCT_ROADMAP.md) for the staged plan to grow LiteCode into a fast, reliable desktop code editor. Features are considered complete only after UX, keyboard access, error states, tests and performance checks—not merely when a button is added.


### Package installation
Open the Packages icon in the activity bar, choose the package manager, enter a package name, and confirm the generated command. LiteCode runs it in the integrated terminal at the opened project root so output and errors remain visible. Package names are restricted to a conservative character set; third-party install scripts may still execute as part of the selected package manager. Project dependency actions assume the matching manifest is present (for example `package.json`, `requirements.txt` / `pyproject.toml`, or `Cargo.toml`).
