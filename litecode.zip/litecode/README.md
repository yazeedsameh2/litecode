# LiteCode

محرر أكواد خفيف وسريع (Tauri + Rust + CodeMirror 6) يعمل على Windows وLinux.

## المميزات
- محرر بتلوين كود وإكمال تلقائي حسب اللغة، واقتراحات من الملف الحالي، وقوالب Snippets وEmmet وطي وبحث واستبدال وأكثر من مؤشر
- مستكشف ملفات، تبويبات، Ctrl+P، لوحة أوامر، بحث داخل المشروع، ومشاريع حديثة على شاشة الترحيب
- تيرمنال حقيقي سفلي، وزر Run لتشغيل Python/JS/C/C++/Java/Rust/Go/PHP/Ruby/Bash
- Live Server مع معاينة مدمجة وإعادة تحميل تلقائية عند الحفظ
- Git Source Control مدمج: عرض التغييرات، معاينة diff، stage/unstage، وإنشاء commit
- استبدال شامل داخل المشروع يدعم النص العادي أو Regex، مع تأكيد قبل التعديل
- ثيم داكن وفاتح، وحفظ الجلسة، ولوحة إعدادات مباشرة لتخصيص الخط والمسافات والحفظ التلقائي

## الإكمال التلقائي
- اقتراحات كلمات ورموز شائعة حسب امتداد الملف للغات المدعومة.
- اقتراح أسماء ظهرت في الملف الحالي مع إزالة التكرارات.
- قوالب جاهزة للأنماط الشائعة في Python وJavaScript وHTML وCSS وSQL.
- ملاحظة: الاقتراحات الحالية لا تعتمد على LSP، لذلك لا توفر تحليل أنواع أو فهمًا دلاليًا كاملًا للمشروع.

## الاختصارات
| الاختصار | الوظيفة |
|---|---|
| Ctrl+Shift+O | فتح مجلد |
| Ctrl+P | فتح ملف بالاسم (اكتب `>` للأوامر، `:` لرقم السطر) |
| Ctrl+Shift+P / F1 | لوحة الأوامر |
| F5 | تشغيل الملف الحالي (أو Continue أثناء التوقف في المصحح) |
| Ctrl+Alt+R | إعدادات التشغيل/التصحيح (الملف، مجلد العمل، الوسائط) |
| F6 | بدء تصحيح ملف Python |
| F9 | تبديل Breakpoint على السطر الحالي |
| F10 / F11 / Shift+F11 | Step Over / Into / Out أثناء التصحيح |
| Shift+F5 / Ctrl+Shift+F5 | إيقاف / إعادة تشغيل التصحيح |
| Ctrl+` | إظهار/إخفاء التيرمنال |
| Ctrl+Alt+L | تشغيل/إيقاف Live Server |
| Ctrl+S / Ctrl+Shift+S | حفظ / حفظ باسم |
| Ctrl+B | إظهار/إخفاء الشريط الجانبي |
| Ctrl+Shift+F | بحث في كل الملفات |
| Ctrl+Shift+G | إدارة تغييرات Git |
| Ctrl+, | فتح الإعدادات |
| Ctrl+= / Ctrl+- | تكبير / تصغير الخط |

## البناء
البناء يتم تلقائياً على GitHub Actions (ملف `.github/workflows/build.yml`):
1. ارفع المشروع على مستودع GitHub.
2. افتح تبويب **Actions** وانتظر انتهاء `build`.
3. نزّل `LiteCode-Windows` (ملف exe) أو `LiteCode-Linux-Zorin` (ملف deb) من أسفل صفحة التشغيل.

بناء محلي (اختياري): ثبّت Node 20 وRust ثم:
```
npm install
npx tauri icon app-icon.png
npx tauri build
```


## Developer checks

Run the lightweight JavaScript unit tests with `npm test`. They cover cross-platform path helpers and command construction for filenames containing spaces and shell metacharacters. Build the frontend with `npm run build`; build the desktop app with the Tauri CLI after installing the Rust toolchain and the platform-specific prerequisites.


## Product direction

See [`PRODUCT_ROADMAP.md`](PRODUCT_ROADMAP.md) for the staged plan to grow LiteCode into a fast, reliable desktop code editor. Features are considered complete only after UX, keyboard access, error states, tests and performance checks—not merely when a button is added.


### Package installation
Open the Packages icon in the activity bar, choose the package manager, enter a package name, and confirm the generated command. LiteCode runs it in the integrated terminal at the opened project root so output and errors remain visible. Package names are restricted to a conservative character set; third-party install scripts may still execute as part of the selected package manager. Project dependency actions assume the matching manifest is present (for example `package.json`, `requirements.txt` / `pyproject.toml`, or `Cargo.toml`).


### Language-server Quick Fixes (0.6.0)

With a supported Python or JavaScript/TypeScript language server running, place the cursor on a diagnostic and run **Language Server: Quick Fix / Code Actions** from the command palette (`Ctrl+Shift+P` then search), or use `Ctrl+.`. LiteCode currently applies edits only to the active document. Multi-file edits and file/resource operations are intentionally rejected until full workspace-edit handling is implemented.


## Offline behavior

LiteCode's editor UI and bundled editor libraries are local to the installed app; ordinary editing, saving local files, project search, terminal, Git, local program runners, and the local Live Server do not inherently require internet access. The status-bar Online/Offline indicator is advisory only and never turns these features off.

Some workflows can require connectivity: downloading packages from npm/PyPI or other registries, installing tools that are not already on the machine, fetching remote Git repositories, and any external service. Package managers may work offline when the required packages are already cached and the selected command supports offline/cache mode. LSP features work without internet only when the relevant language server is already installed locally. A network-status indicator cannot guarantee that a registry is reachable.


## Project tasks (0.7.0)

LiteCode can run named project tasks from `.litecode/tasks.json`. Example:

```json
{
  "tasks": [
    { "label": "Run tests", "command": "npm test" },
    { "label": "Build frontend", "command": "npm run build" },
    { "label": "Run backend", "command": "python -m uvicorn app:app --reload", "cwd": "backend" }
  ]
}
```

Open the command palette and choose **Run: Run Task…**. LiteCode displays the exact command and working directory for confirmation before starting it in the integrated terminal. Treat task files as executable project configuration; inspect commands before running them. Task working directories must stay inside the opened workspace.

Editor preferences now include cursor blinking and smooth cursor motion. Smooth motion respects the operating system's reduced-motion preference.


### Python debugger (0.8.0)

Open a project folder and a saved `.py` file inside it.
- **Breakpoints:** click the gutter left of the line numbers (or press F9). A hollow marker means the debugger could not bind the line (no executable code there).
- **Start:** F6 / **Debug**, or **⚙ / Ctrl+Alt+R** to choose the file, working directory and arguments, then **Run** (integrated terminal) or **Debug**. Debugging always asks for confirmation because it executes your code.
- **While paused:** the stopped line is highlighted and opened automatically; the panel shows the call stack (click a frame to inspect it), scopes and expandable variables, and the console evaluates expressions. Continue (F5), Step Over (F10), Step Into (F11), Step Out (Shift+F11), Pause, Stop (Shift+F5), Restart (Ctrl+Shift+F5).
- **Errors:** uncaught exceptions pause the program (toggle in the dialog); tracebacks in the terminal and debug console are clickable.
- **Requirements:** `debugpy` installed in the interpreter configured in Settings (`python -m pip install debugpy`). Breakpoints and sources must be saved before starting; edit-and-continue is not supported.
- **Tests:** `npm test` (JavaScript, includes a fake-adapter integration suite); `cargo test --lib` inside `src-tauri` (Rust unit tests).

### Debugging development status (historical)
LiteCode 0.7.4 adds a constrained native transport foundation for the Python `debugpy.adapter` process and a JavaScript bridge that connects it to the DAP session coordinator. LiteCode 0.7.3 added request/response correlation, adapter events, bounded pending requests, and clean shutdown. LiteCode 0.7.2 improves crash-recovery write performance by coalescing editor changes and flushing snapshots when the app is backgrounded. The debugger is still not end-to-end usable: debugpy must be installed locally, and launch/attach, stepping, stack frames, variables, and breakpoint UI remain roadmap items. The Rust/Tauri build and real adapter lifecycle have not yet been verified.

### Python debugging progress (0.7.7)

The project includes `src/dap-workflow.js`, a testable Python Debug Adapter Protocol workflow layer covering initialization, launch configuration, breakpoints, configuration completion, threads, stack frames, scopes, variables, continue, stepping, pause, and disconnect. Version 0.7.7 adds configurable request timeouts to `DapSession` (30 seconds by default) so missing adapter responses do not leave requests pending forever. Run `npm test` to execute the JavaScript tests. This workflow is not yet connected to a visible debugging UI, and the native Tauri build and a real local `debugpy` session still require validation on a machine with the Rust toolchain and Python debugpy installed.


### Python debugger panel (0.7.8)

LiteCode now has an initial visible Python debugger panel. Open a project, open a saved `.py` file inside that project, choose **Debug**, then confirm **Run and Debug**. The panel exposes continue, step over/into/out, pause, stop, per-file breakpoint lists, call-stack navigation, a top-frame scope's variables, and a debug console. Toggle a breakpoint on the current line using the Breakpoint button. `debugpy` must be installed in the Python environment that launches the adapter (`python3 -m pip install debugpy` on Linux/macOS, or `python -m pip install debugpy` on Windows). Only run files you trust. This integration is not yet verified against a real native Tauri build/adapter session; check `npm test` for the available JavaScript unit coverage.
