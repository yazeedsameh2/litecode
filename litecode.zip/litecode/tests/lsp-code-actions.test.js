import test from 'node:test';
import assert from 'node:assert/strict';
import { getCurrentDocumentEdits, getCurrentTextEdits } from '../src/lsp-code-actions.js';

function fakeDoc(lines) {
  const text = lines.join('\n');
  const starts = [0];
  for (let i = 0; i < text.length; i++) if (text[i] === '\n') starts.push(i + 1);
  return {
    lines: starts.length,
    line(n) {
      const from = starts[n - 1];
      const to = n < starts.length ? starts[n] - 1 : text.length;
      return { from, length: to - from };
    },
  };
}

test('maps a single-file workspace edit into editor changes', () => {
  const doc = fakeDoc(['const x = 1;', 'console.log(x);']);
  const changes = getCurrentDocumentEdits({ changes: { 'file:///tmp/a.js': [{ range: { start: { line: 0, character: 6 }, end: { line: 0, character: 7 } }, newText: 'value' }] } }, '/tmp/a.js', doc);
  assert.deepEqual(changes, [{ from: 6, to: 7, insert: 'value' }]);
});

test('rejects edits targeting another file', () => {
  const doc = fakeDoc(['abc']);
  assert.equal(getCurrentDocumentEdits({ changes: { 'file:///tmp/other.js': [] } }, '/tmp/a.js', doc), null);
});

test('rejects resource operations and malformed ranges without returning partial edits', () => {
  const doc = fakeDoc(['abc']);
  assert.equal(getCurrentDocumentEdits({ documentChanges: [{ kind: 'rename', oldUri: 'file:///tmp/a.js', newUri: 'file:///tmp/b.js' }] }, '/tmp/a.js', doc), null);
  assert.equal(getCurrentDocumentEdits({ changes: { 'file:///tmp/a.js': [{ range: { start: { line: 4, character: 0 }, end: { line: 4, character: 1 } }, newText: 'x' }] } }, '/tmp/a.js', doc), null);
});

test('sorts non-overlapping edits in document order and rejects overlaps', () => {
  const doc = fakeDoc(['abcdef']);
  const uri = 'file:///tmp/a.js';
  const edit = (a, b, newText) => ({ range: { start: { line: 0, character: a }, end: { line: 0, character: b } }, newText });
  assert.deepEqual(getCurrentDocumentEdits({ changes: { [uri]: [edit(4, 5, 'E'), edit(0, 1, 'A')] } }, '/tmp/a.js', doc), [
    { from: 0, to: 1, insert: 'A' }, { from: 4, to: 5, insert: 'E' },
  ]);
  assert.equal(getCurrentDocumentEdits({ changes: { [uri]: [edit(0, 3, 'A'), edit(2, 4, 'B')] } }, '/tmp/a.js', doc), null);
});


test('maps valid formatter edits and rejects invalid character offsets', () => {
  const doc = fakeDoc(['const  x=1;', 'console.log(x)']);
  assert.deepEqual(getCurrentTextEdits([
    { range: { start: { line: 0, character: 5 }, end: { line: 0, character: 7 } }, newText: ' ' },
    { range: { start: { line: 1, character: 14 }, end: { line: 1, character: 14 } }, newText: ';' },
  ], doc), [
    { from: 5, to: 7, insert: ' ' },
    { from: 26, to: 26, insert: ';' },
  ]);
  assert.equal(getCurrentTextEdits([
    { range: { start: { line: 0, character: 999 }, end: { line: 0, character: 1000 } }, newText: 'x' },
  ], doc), null);
});

test('rejects overlapping formatter edits instead of applying a partial format', () => {
  const doc = fakeDoc(['abcdef']);
  const edits = [
    { range: { start: { line: 0, character: 0 }, end: { line: 0, character: 3 } }, newText: 'x' },
    { range: { start: { line: 0, character: 2 }, end: { line: 0, character: 4 } }, newText: 'y' },
  ];
  assert.equal(getCurrentTextEdits(edits, doc), null);
});
