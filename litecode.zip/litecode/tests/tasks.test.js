import test from 'node:test';
import assert from 'node:assert/strict';
import { parseTaskConfig, validateTask } from '../src/tasks.js';

test('parses named task configs and trims fields', () => {
  assert.deepEqual(parseTaskConfig(JSON.stringify({ tasks: [{ label: ' Build ', command: ' npm run build ', cwd: 'app' }] })), [
    { label: 'Build', command: 'npm run build', cwd: 'app' },
  ]);
});

test('rejects malformed config and caps task count', () => {
  assert.throws(() => parseTaskConfig('{bad json'), SyntaxError);
  assert.throws(() => parseTaskConfig({ nope: [] }), /tasks array/);
  assert.throws(() => parseTaskConfig({ tasks: Array.from({ length: 81 }, (_, i) => ({ label: `T${i}`, command: 'echo ok' })) }), /at most 80/);
});

test('ignores invalid tasks and duplicate labels', () => {
  assert.deepEqual(parseTaskConfig({ tasks: [
    { label: 'Build', command: 'npm run build' },
    { label: 'build', command: 'npm run other' },
    { label: 'Empty', command: ' ' },
    null,
  ] }), [{ label: 'Build', command: 'npm run build', cwd: '.' }]);
});

test('keeps task working directory inside workspace', () => {
  assert.deepEqual(validateTask({ command: 'npm test', cwd: 'client' }, 'C:\\Work\\App'), { ok: true, cwd: 'C:\\Work\\App/client' });
  assert.equal(validateTask({ command: 'echo bad', cwd: '../outside' }, '/home/user/project').ok, false);
  assert.equal(validateTask({ command: 'echo bad', cwd: 'C:\\Windows' }, '/home/user/project').ok, false);
});
