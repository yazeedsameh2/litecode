import test from 'node:test';
import assert from 'node:assert/strict';
import { DebugController } from '../src/debug-controller.js';
import { BreakpointStore } from '../src/debug-breakpoints.js';
import { createFakeDebugClient } from './helpers/fake-debug-adapter.js';

const PROG = '/proj/main.py';
const STOPS = [
  { path: PROG, line: 3, name: 'main', reason: 'breakpoint' },
  { path: PROG, line: 4, name: 'main', reason: 'step' },
  { path: PROG, line: 8, name: 'helper', reason: 'breakpoint' },
];

function setup(options = {}, { lines = [3, 8] } = {}) {
  const store = new BreakpointStore();
  if (lines.length) store.setLines(PROG, lines, { silent: true });
  const fake = createFakeDebugClient({ stops: STOPS, ...options });
  const events = { states: [], output: '', locations: [], scopes: [], stopped: [], clients: 0 };
  const controller = new DebugController({
    store,
    createClient: async () => { events.clients++; return fake.client; },
    onState: ({ state, detail }) => events.states.push(state),
    onOutput: ({ text }) => { events.output += text; },
    onLocation: (loc) => events.locations.push(loc),
    onScopes: (s) => events.scopes.push(s),
    onStopped: (s) => events.stopped.push(s),
  });
  const config = { program: PROG, cwd: '/proj', args: ['--flag'], stopOnEntry: false };
  return { store, fake, events, controller, config };
}
const until = (fn, ms = 1500) => new Promise((resolve, reject) => {
  const t0 = Date.now();
  (function poll() { if (fn()) return resolve(); if (Date.now() - t0 > ms) return reject(new Error(`condition not met; states poll timed out`)); setTimeout(poll, 3); })();
});

test('debugpy-style ordering: launch response is deferred until configurationDone, no deadlock', async () => {
  const { controller, fake, config } = setup();
  await controller.start(config);
  const order = fake.adapter.commands();
  assert.deepEqual(order.slice(0, 5), ['initialize', 'launch', 'setBreakpoints', 'setExceptionBreakpoints', 'configurationDone']);
  assert.deepEqual(fake.adapter.launchConfig.args, ['--flag']);
  assert.equal(fake.adapter.launchConfig.subProcess, false);
  await controller.stop();
});

test('stops at the breakpoint, reports location, frames, scopes and variables', async () => {
  const { controller, events, config } = setup();
  await controller.start(config);
  await until(() => events.scopes.length > 0);
  assert.equal(controller.state, 'stopped');
  assert.deepEqual(events.locations.at(-1), { path: PROG, line: 3, column: 1, frameId: 100, kind: 'stop' });
  assert.equal(controller.frames.length, 2);
  const scopes = events.scopes.at(-1).scopes;
  assert.equal(scopes[0].name, 'Locals');
  assert.equal(scopes[0].variables[0].value, '3');
  assert.equal(scopes[1].variables, null, 'expensive scopes load lazily');
  assert.equal((await controller.expand(5000))[0].value, "'a'");
  assert.equal((await controller.expand(2100))[0].name, '__name__');
  await controller.stop();
});

test('selecting another frame moves the location and reloads scopes', async () => {
  const { controller, events, config } = setup();
  await controller.start(config);
  await until(() => events.scopes.length > 0);
  await controller.selectFrame(1);
  assert.equal(events.locations.at(-1).kind, 'frame');
  assert.equal(events.scopes.at(-1).frameId, 1);
  await controller.stop();
});

test('stepping and continue walk the script and a finished program tears the adapter down', async () => {
  const { controller, events, fake, config } = setup();
  await controller.start(config);
  await until(() => controller.state === 'stopped');
  await controller.stepOver();
  await until(() => controller.state === 'stopped' && events.locations.at(-1)?.line === 4);
  await controller.continue();
  await until(() => controller.state === 'stopped' && events.locations.at(-1)?.line === 8);
  await controller.continue();
  await until(() => controller.state === 'finished');
  assert.match(controller.detail, /Exit code: 0/);
  await until(() => fake.adapter.closeCalls >= 1);
  assert.equal(events.locations.at(-1), null);
});

test('race: stopped event arriving before the continue response is not overwritten by "running"', async () => {
  const { controller, events, config } = setup({ stopBeforeResponse: true });
  await controller.start(config);
  await until(() => controller.state === 'stopped');
  await controller.stepOver();
  await new Promise((r) => setTimeout(r, 30));
  assert.equal(controller.state, 'stopped');
  assert.equal(events.locations.at(-1).line, 4);
  await controller.stop();
});

test('stopOnEntry stops before the first breakpoint', async () => {
  const { controller, events, config } = setup();
  await controller.start({ ...config, stopOnEntry: true });
  await until(() => events.stopped.length > 0);
  assert.equal(controller.state, 'stopped');
  assert.equal(events.stopped.at(-1).reason, 'entry');
  await controller.stop();
});

test('breakpoint edits during a session are serialized and adapter adjustments flow back', async () => {
  const { controller, store, fake, events, config } = setup({ moveLines: { 8: 9 } });
  await controller.start(config);
  await until(() => controller.state === 'stopped');
  assert.deepEqual(store.lines(PROG), [3, 9], 'adapter moved line 8 to 9');
  store.setLines(PROG, [3, 9, 20]); store.setLines(PROG, [3, 9, 20, 21]); store.setLines(PROG, [3]);
  await controller.syncBreakpoints(PROG);
  const sent = fake.adapter.log.filter((m) => m.command === 'setBreakpoints').map((m) => m.arguments.lines);
  assert.deepEqual(sent.at(-1), [3], 'the latest store state wins');
  assert.deepEqual([...fake.adapter.breakpoints.get(PROG)], [3]);
  await controller.stop();
});

test('unverified breakpoints are flagged and cleared after the session', async () => {
  const { controller, store, config } = setup({ unverified: [8] });
  await controller.start(config);
  assert.deepEqual(store.unverified(PROG), [8]);
  await controller.stop();
  assert.deepEqual(store.unverified(PROG), []);
});

test('transport loss moves to "disconnected", releases the client and allows a clean restart', async () => {
  const { controller, fake, events, config } = setup();
  await controller.start(config);
  await until(() => controller.state === 'stopped');
  fake.adapter.crash('Debug adapter exited unexpectedly');
  await until(() => controller.state === 'disconnected');
  assert.match(events.output, /connection lost/);
  await until(() => fake.adapter.closeCalls >= 1);
  await assert.rejects(controller.continue(), /only available/);
  await controller.stop();
  assert.equal(controller.state, 'idle');
});

test('launch failure aborts quickly instead of waiting for the initialized timeout', async () => {
  const { controller, fake, config } = setup({ failLaunch: 'program does not exist', noInitialized: true });
  const started = Date.now();
  await assert.rejects(controller.start(config), /program does not exist/);
  assert.ok(Date.now() - started < 1000);
  assert.equal(controller.state, 'idle');
  assert.ok(fake.adapter.closeCalls >= 1);
});

test('a request timeout during startup is reported and cleans everything up', async () => {
  const { controller, fake, config } = setup({ neverRespond: ['setBreakpoints'], requestTimeoutMs: 40 });
  await assert.rejects(controller.start(config), /timed out/);
  assert.equal(controller.state, 'idle');
  assert.ok(fake.adapter.closeCalls >= 1);
});

test('stop() during startup cancels it and leaks no client', async () => {
  const { controller, fake, config } = setup({ neverRespond: ['configurationDone'], requestTimeoutMs: 5000 });
  const starting = controller.start(config);
  await until(() => fake.adapter.commands().includes('configurationDone'));
  await controller.stop();
  await starting;
  assert.equal(controller.state, 'idle');
  assert.ok(fake.adapter.closeCalls >= 1);
});

test('disconnect that never answers does not hang stop()', async () => {
  const store = new BreakpointStore();
  const fake = createFakeDebugClient({ stops: STOPS, hangOnDisconnect: true });
  const controller = new DebugController({ store, createClient: async () => fake.client });
  await controller.start({ program: PROG, cwd: '/proj' });
  await until(() => controller.state === 'stopped' || controller.state === 'running' || controller.state === 'finished');
  const t0 = Date.now();
  await controller.stop();
  assert.ok(Date.now() - t0 < 4500);
  assert.equal(controller.state, 'idle');
});

test('restart reuses the last configuration with a fresh adapter', async () => {
  const store = new BreakpointStore(); store.setLines(PROG, [3], { silent: true });
  const fakes = [];
  const controller = new DebugController({
    store,
    createClient: async () => { const f = createFakeDebugClient({ stops: STOPS }); fakes.push(f); return f.client; },
  });
  await controller.start({ program: PROG, cwd: '/proj', args: ['a'] });
  await until(() => controller.state === 'stopped');
  await controller.restart();
  await until(() => controller.state === 'stopped');
  assert.equal(fakes.length, 2);
  assert.ok(fakes[0].adapter.closeCalls >= 1, 'old adapter was closed');
  assert.deepEqual(fakes[1].adapter.launchConfig.args, ['a']);
  await controller.stop();
});

test('adapter reverse requests such as runInTerminal get an error reply', async () => {
  const { controller, fake, config } = setup();
  await controller.start(config);
  fake.adapter.sendReverse('runInTerminal', { args: ['python'] });
  await fake.adapter.waitFor(() => fake.adapter.clientReplies.length > 0);
  assert.equal(fake.adapter.clientReplies[0].success, false);
  assert.equal(fake.adapter.clientReplies[0].command, 'runInTerminal');
  await controller.stop();
});

test('exception stops print exception details with a clickable traceback location', async () => {
  const store = new BreakpointStore(); store.setLines(PROG, [5], { silent: true });
  const fake = createFakeDebugClient({ stops: [{ path: PROG, line: 5, name: 'main', reason: 'exception' }] });
  let out = ''; const locations = [];
  const controller = new DebugController({ store, createClient: async () => fake.client, onOutput: ({ text }) => { out += text; }, onLocation: (l) => locations.push(l) });
  await controller.start({ program: PROG, cwd: '/proj', breakOnUncaught: true });
  await until(() => /ValueError: bad value/.test(out));
  assert.match(out, /File "\/proj\/main\.py", line 5/);
  await until(() => locations.at(-1)?.kind === 'exception');
  await controller.stop();
});

test('evaluate runs against the selected frame and is rejected while running', async () => {
  const { controller, config } = setup({}, { lines: [] });
  await controller.start(config);
  await assert.rejects(controller.evaluate('x'), /Pause the program/);
  await controller.stop();
  const s2 = setup();
  await s2.controller.start(s2.config);
  await until(() => s2.controller.state === 'stopped');
  assert.equal((await s2.controller.evaluate('x + 1')).result, 'eval:x + 1');
  await s2.controller.stop();
});

test('a second start while a session is active is rejected', async () => {
  const { controller, config } = setup({}, { lines: [] });
  await controller.start(config);
  await assert.rejects(controller.start(config), /already active/);
  await controller.stop();
});
