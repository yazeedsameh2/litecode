import test from 'node:test';
import assert from 'node:assert/strict';
import { buildPackageCommand, buildDependencyCommand, validatePackageName } from '../src/packages.js';

test('builds package commands for common ecosystems', () => {
  assert.equal(buildPackageCommand('npm', 'lodash'), 'npm install lodash');
  assert.equal(buildPackageCommand('pnpm', '@scope/pkg'), 'pnpm add @scope/pkg');
  assert.equal(buildPackageCommand('pip', 'requests'), 'python -m pip install requests');
  assert.equal(buildPackageCommand('cargo', 'serde'), 'cargo add serde');
});

test('supports project dependency commands', () => {
  assert.equal(buildDependencyCommand('npm'), 'npm install');
  assert.equal(buildDependencyCommand('uv'), 'uv sync');
  assert.equal(buildDependencyCommand('composer'), 'composer install');
});

test('rejects shell injection and malformed package names', () => {
  for (const name of ['; rm -rf /', 'pkg&&whoami', '$(whoami)', ' --help', '../escape', 'a//b', '']) {
    assert.equal(validatePackageName(name), null, `expected rejection for ${JSON.stringify(name)}`);
  }
  assert.throws(() => buildPackageCommand('npm', 'pkg;whoami'));
});
