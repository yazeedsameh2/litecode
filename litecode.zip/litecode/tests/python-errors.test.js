import test from 'node:test';
import assert from 'node:assert/strict';
import { findPythonErrorLinks, splitErrorSegments, resolveErrorPath, describeAdapterFailure, formatExceptionInfo } from '../src/python-errors.js';

test('finds traceback locations on POSIX and Windows paths', () => {
  const posix = findPythonErrorLinks('  File "/home/u/my proj/main.py", line 12, in <module>');
  assert.deepEqual(posix.map(({ path, line }) => ({ path, line })), [{ path: '/home/u/my proj/main.py', line: 12 }]);
  const win = findPythonErrorLinks('  File "C:\\Users\\Me\\app.py", line 7, in run');
  assert.equal(win[0].path, 'C:\\Users\\Me\\app.py'); assert.equal(win[0].line, 7);
});

test('skips non-openable pseudo files like <stdin> and <frozen runpy>', () => {
  assert.deepEqual(findPythonErrorLinks('  File "<stdin>", line 1, in <module>'), []);
  assert.deepEqual(findPythonErrorLinks('  File "<frozen runpy>", line 198, in _run_module_as_main'), []);
});

test('finds pytest-style path:line:column references without double-counting tracebacks', () => {
  const links = findPythonErrorLinks('tests/test_a.py:42:5: E assert 1 == 2');
  assert.deepEqual(links.map((l) => [l.path, l.line, l.column]), [['tests/test_a.py', 42, 5]]);
  assert.equal(findPythonErrorLinks('  File "a.py", line 3, in f').length, 1);
});

test('splitErrorSegments preserves all text and marks link segments', () => {
  const text = 'Traceback (most recent call last):\n  File "/p/a.py", line 3, in <module>\n    boom()\nValueError: x\n';
  const segments = splitErrorSegments(text);
  assert.equal(segments.map((s) => s.text).join(''), text);
  assert.deepEqual(segments.filter((s) => s.link).map((s) => s.link.line), [3]);
});

test('relative error paths resolve against the run directory only', () => {
  assert.equal(resolveErrorPath('pkg/mod.py', '/work/proj'), '/work/proj/pkg/mod.py');
  assert.equal(resolveErrorPath('.\\pkg\\mod.py', 'C:\\work'), 'C:\\work\\pkg\\mod.py');
  assert.equal(resolveErrorPath('/abs/x.py', '/work'), '/abs/x.py');
  assert.equal(resolveErrorPath('rel.py', null), null);
  assert.equal(resolveErrorPath('<string>', '/w'), null);
});

test('adapter failures produce actionable messages', () => {
  assert.match(describeAdapterFailure("/usr/bin/python3: No module named debugpy", 'python3'), /pip install debugpy/);
  assert.match(describeAdapterFailure('python: command not found', 'python'), /Python command in Settings/);
  assert.equal(describeAdapterFailure('', 'python'), '');
});

test('exception info is formatted with type, message and traceback', () => {
  const text = formatExceptionInfo({ exceptionId: 'ValueError', description: 'bad', details: { typeName: 'ValueError', stackTrace: 'Traceback...\n' } });
  assert.match(text, /^ValueError: bad\nTraceback/);
  assert.equal(formatExceptionInfo(null), '');
});
