import test from 'node:test';
import assert from 'node:assert/strict';
import { createRecoveryScheduler } from '../src/recovery-scheduler.js';

function fakeTimers() {
  let next = 1;
  const tasks = new Map();
  return {
    setTimeout(fn, delay) { const id = next++; tasks.set(id, { fn, delay }); return id; },
    clearTimeout(id) { tasks.delete(id); },
    runAll() { const pending = [...tasks.values()]; tasks.clear(); for (const task of pending) task.fn(); },
    get size() { return tasks.size; },
  };
}

test('repeated edits coalesce into one periodic recovery write', () => {
  const timers = fakeTimers(); let saves = 0;
  const writer = createRecoveryScheduler(() => saves++, 700, timers);
  writer.schedule(); writer.schedule(); writer.schedule();
  assert.equal(timers.size, 1); assert.equal(saves, 0);
  timers.runAll(); assert.equal(saves, 1);
  writer.schedule(); timers.runAll(); assert.equal(saves, 2);
});

test('flush cancels pending timer and writes immediately', () => {
  const timers = fakeTimers(); let saves = 0;
  const writer = createRecoveryScheduler(() => saves++, 700, timers);
  writer.schedule(); assert.equal(writer.flush(), true);
  assert.equal(saves, 1); assert.equal(timers.size, 0);
  timers.runAll(); assert.equal(saves, 1);
});

test('cancel discards pending write; dispose prevents future writes', () => {
  const timers = fakeTimers(); let saves = 0;
  const writer = createRecoveryScheduler(() => saves++, 700, timers);
  writer.schedule(); writer.cancel(); timers.runAll(); assert.equal(saves, 0);
  writer.schedule(); writer.dispose(); writer.schedule(); timers.runAll();
  assert.equal(saves, 0); assert.equal(writer.flush(), false);
});

test('invalid scheduler arguments are rejected', () => {
  assert.throws(() => createRecoveryScheduler(null), /save must be a function/);
  assert.throws(() => createRecoveryScheduler(() => {}, -1), /non-negative/);
});
