// A scripted fake debug adapter that mimics debugpy's message ordering:
//   initialize -> launch (response deferred) + `initialized` event -> setBreakpoints ->
//   configurationDone -> launch response -> run.
// Messages travel through the real Content-Length framing in both directions (split into tiny
// chunks) and through the real DapSession, so framing + correlation are exercised end to end.
import { DapSession } from '../../src/dap-session.js';
import { DapMessageParser, encodeDapMessage } from '../../src/dap-protocol.js';

const later = (fn) => setImmediate(fn);

export function createFakeDebugClient(options = {}) {
  const {
    stops = [], exitCode = 0, failLaunch = null, moveLines = {}, unverified = [],
    stopBeforeResponse = false, neverRespond = [], hangOnDisconnect = false, requestTimeoutMs = 2000,
    noInitialized = false, chunkSize = 7,
  } = options;
  const toAdapter = new DapMessageParser();
  const toClient = new DapMessageParser();
  const log = [];            // every request the client sent, in order
  const clientReplies = [];  // client responses to reverse requests
  const breakpoints = new Map();
  let pendingLaunch = null; let launchCfg = null; let ptr = -1; let transportClosed = false; let closeCalls = 0;
  let seq = 1; let session;

  const deliver = (message) => {
    if (transportClosed) return;
    const bytes = encodeDapMessage(message);
    for (let i = 0; i < bytes.length; i += chunkSize) {
      for (const msg of toClient.push(bytes.slice(i, i + chunkSize))) later(() => session.receive(msg));
    }
  };
  const respond = (req, body = {}, success = true, message) => deliver({ seq: seq++, type: 'response', request_seq: req.seq, command: req.command, success, ...(success ? { body } : { message }) });
  const event = (name, body = {}) => deliver({ seq: seq++, type: 'event', event: name, body });

  const frameFor = (i) => ({ id: 100 + i, name: stops[i].name || '<module>', source: { path: stops[i].path }, line: stops[i].line, column: 1 });
  const emitStop = (i, reason = stops[i].reason || 'breakpoint') => { ptr = i; event('stopped', { reason, threadId: 1, allThreadsStopped: true }); };
  const finish = () => { event('exited', { exitCode }); event('terminated', {}); };
  const nextBreakpointStop = (from) => {
    for (let i = from; i < stops.length; i++) if (stops[i].reason === 'step' ? false : breakpoints.get(stops[i].path)?.includes(stops[i].line)) return i;
    return -1;
  };
  const advance = (kind) => {
    const target = kind === 'continue' ? nextBreakpointStop(ptr + 1) : (ptr + 1 < stops.length ? ptr + 1 : -1);
    if (target < 0) finish(); else emitStop(target, kind === 'continue' ? 'breakpoint' : 'step');
  };

  const handlers = {
    initialize: (r) => respond(r, {
      supportsConfigurationDoneRequest: true,
      exceptionBreakpointFilters: [{ filter: 'raised', label: 'Raised' }, { filter: 'uncaught', label: 'Uncaught' }],
    }),
    launch: (r) => {
      launchCfg = r.arguments;
      if (failLaunch) return respond(r, {}, false, failLaunch);
      pendingLaunch = r;
      if (!noInitialized) event('initialized');
    },
    setBreakpoints: (r) => {
      const path = r.arguments.source.path; const lines = r.arguments.lines;
      breakpoints.set(path, lines);
      respond(r, { breakpoints: lines.map((line) => ({ verified: !unverified.includes(line), line: moveLines[line] ?? line })) });
    },
    setExceptionBreakpoints: (r) => respond(r, {}),
    configurationDone: (r) => {
      respond(r, {});
      if (pendingLaunch) { respond(pendingLaunch, {}); pendingLaunch = null; }
      later(() => {
        if (launchCfg?.stopOnEntry && stops.length) return emitStop(0, 'entry');
        const target = nextBreakpointStop(0);
        if (target < 0) finish(); else emitStop(target);
      });
    },
    threads: (r) => respond(r, { threads: [{ id: 1, name: 'MainThread' }] }),
    stackTrace: (r) => respond(r, { stackFrames: ptr < 0 ? [] : [frameFor(ptr), { id: 1, name: '<module>', source: { path: stops[ptr].path }, line: 1, column: 1 }] }),
    scopes: (r) => respond(r, { scopes: [
      { name: 'Locals', variablesReference: 1000 + r.arguments.frameId, expensive: false },
      { name: 'Globals', variablesReference: 2000 + r.arguments.frameId, expensive: true },
    ] }),
    variables: (r) => {
      const ref = r.arguments.variablesReference;
      if (ref === 5000) return respond(r, { variables: [{ name: '0', value: "'a'", variablesReference: 0 }] });
      if (ref >= 2000) return respond(r, { variables: [{ name: '__name__', value: "'__main__'", variablesReference: 0 }] });
      respond(r, { variables: [{ name: 'x', value: String(stops[ptr]?.line ?? 0), type: 'int', variablesReference: 0 }, { name: 'items', value: '[...]', type: 'list', variablesReference: 5000 }] });
    },
    continue: (r) => { if (stopBeforeResponse) { advance('continue'); later(() => respond(r, { allThreadsContinued: true })); } else { respond(r, { allThreadsContinued: true }); later(() => advance('continue')); } },
    next: (r) => { if (stopBeforeResponse) { advance('next'); later(() => respond(r)); } else { respond(r); later(() => advance('next')); } },
    stepIn: (r) => { respond(r); later(() => advance('stepIn')); },
    stepOut: (r) => { respond(r); later(() => advance('stepOut')); },
    pause: (r) => { respond(r); later(() => event('stopped', { reason: 'pause', threadId: 1, allThreadsStopped: true })); },
    exceptionInfo: (r) => respond(r, { exceptionId: 'ValueError', description: 'bad value', details: { typeName: 'ValueError', message: 'bad value', stackTrace: `Traceback (most recent call last):\n  File "${stops[ptr]?.path}", line ${stops[ptr]?.line}, in <module>\n` } }),
    evaluate: (r) => respond(r, { result: `eval:${r.arguments.expression}`, variablesReference: 0 }),
    disconnect: (r) => { if (hangOnDisconnect) return; respond(r, {}); later(() => { transportClosed = true; session.close('Debug adapter exited'); }); },
  };

  session = new DapSession({
    requestTimeoutMs,
    sendBytes: async (message) => {
      if (transportClosed) throw new Error('pipe closed');
      log.push(message);
      const bytes = encodeDapMessage(message);
      for (let i = 0; i < bytes.length; i += chunkSize) {
        for (const msg of toAdapter.push(bytes.slice(i, i + chunkSize))) {
          if (msg.type === 'response') { clientReplies.push(msg); continue; }
          if (neverRespond.includes(msg.command)) continue;
          later(() => (handlers[msg.command] || ((r) => respond(r, {}, false, `unsupported ${r.command}`)))(msg));
        }
      }
    },
  });
  session.on('adapterRequest', (message) => {
    session.respond(message, { success: false, message: 'unsupported' }).catch(() => {});
  });

  const client = {
    session,
    request: (command, args) => session.request(command, args),
    on: (name, listener) => session.on(name, listener),
    close: async () => { closeCalls++; transportClosed = true; session.close('client closed'); },
  };
  const adapter = {
    log, clientReplies, breakpoints,
    get closeCalls() { return closeCalls; },
    get launchConfig() { return launchCfg; },
    commands: () => log.map((m) => m.command),
    event, emitStop,
    crash: (reason = 'Debug adapter exited unexpectedly') => { transportClosed = true; session.close(reason); },
    sendReverse: (command, args = {}) => deliver({ seq: seq++, type: 'request', command, arguments: args }),
    waitFor: async (predicate, ms = 1500) => {
      const start = Date.now();
      while (!predicate()) { if (Date.now() - start > ms) throw new Error('waitFor timed out'); await new Promise((r) => setTimeout(r, 2)); }
    },
  };
  return { client, adapter };
}
