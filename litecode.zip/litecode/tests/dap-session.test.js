import test from 'node:test';
import assert from 'node:assert/strict';
import { DapSession } from '../src/dap-session.js';

const response = (seq, extra = {}) => ({ type: 'response', request_seq: seq, success: true, ...extra });

test('DAP session correlates responses even when they arrive out of order', async () => {
  const sent = [];
  const session = new DapSession({ sendBytes: async (message) => sent.push(message) });
  const a = session.request('initialize', {});
  const b = session.request('threads', {});
  assert.equal(sent.length, 2);
  assert.equal(session.receive(response(sent[1].seq, { body: { threads: [] } })), true);
  assert.equal(session.receive(response(sent[0].seq, { body: { supportsConfigurationDoneRequest: true } })), true);
  assert.equal((await b).body.threads.length, 0);
  assert.equal((await a).body.supportsConfigurationDoneRequest, true);
  assert.equal(session.pendingCount, 0);
});

test('DAP session rejects failed responses with adapter message', async () => {
  const sent = [];
  const session = new DapSession({ sendBytes: async (message) => sent.push(message) });
  const result = session.request('launch', {});
  session.receive({ type: 'response', request_seq: sent[0].seq, success: false, message: 'Invalid launch config' });
  await assert.rejects(result, /Invalid launch config/);
});

test('send failure removes pending request and rejects', async () => {
  const session = new DapSession({ sendBytes: async () => { throw new Error('pipe closed'); } });
  await assert.rejects(session.request('continue'), /pipe closed/);
  assert.equal(session.pendingCount, 0);
});

test('close rejects outstanding requests and refuses future requests', async () => {
  const sent = [];
  const session = new DapSession({ sendBytes: async (message) => sent.push(message) });
  const pending = session.request('stackTrace', { threadId: 1 });
  session.close('adapter exited');
  await assert.rejects(pending, /adapter exited/);
  await assert.rejects(session.request('threads'), /closed/);
  assert.equal(session.pendingCount, 0);
});

test('event subscriptions can be removed and adapter events are dispatched', () => {
  const session = new DapSession({ sendBytes: async () => {} });
  let seen = 0;
  const off = session.on('event:stopped', (body) => { seen += body.threadId; });
  assert.equal(session.receive({ type: 'event', event: 'stopped', body: { threadId: 3 } }), true);
  off();
  session.receive({ type: 'event', event: 'stopped', body: { threadId: 4 } });
  assert.equal(seen, 3);
  session.close();
});

test('pending requests are bounded and breakpoint normalization is available', async () => {
  const session = new DapSession({ sendBytes: async () => {}, maxPending: 1 });
  const pending = session.request('threads');
  await assert.rejects(session.request('stackTrace'), /Too many/);
  assert.deepEqual(session.normalizeBreakpoints([{ line: 4 }, { line: 0 }, { line: 9, column: 2 }]), [
    { verified: false, line: 4 }, { verified: false, line: 9, column: 2 },
  ]);
  session.close();
  await assert.rejects(pending);
});
