import test from "node:test";
import assert from "node:assert/strict";
import { encodeLspMessage, decodeLspFrame, lspLanguageId, initializeParams, normalizeCompletionItems } from "../src/lsp-protocol.js";

test("LSP framing uses UTF-8 byte length, including non-ASCII text", () => {
  const message = { jsonrpc: "2.0", method: "window/showMessage", params: { message: "مرحبا 🌟" } };
  const encoded = encodeLspMessage(message);
  assert.match(encoded.header, new RegExp(`Content-Length: ${encoded.byteLength}`));
  const frame = decodeLspFrame(encoded.header + encoded.body);
  assert.deepEqual(frame.message, message);
  assert.equal(frame.remaining, "");
});

test("LSP frame parser waits for incomplete frames and preserves trailing frames", () => {
  const first = encodeLspMessage({ jsonrpc: "2.0", id: 1, result: {} });
  const second = encodeLspMessage({ jsonrpc: "2.0", method: "initialized" });
  assert.equal(decodeLspFrame(first.header + first.body.slice(0, 4)), null);
  const parsed = decodeLspFrame(first.header + first.body + second.header + second.body);
  assert.equal(parsed.message.id, 1);
  assert.equal(parsed.remaining, second.header + second.body);
});

test("LSP frame parser rejects missing or oversized Content-Length", () => {
  assert.throws(() => decodeLspFrame("X-Test: 1\r\n\r\n{}"), /missing Content-Length/);
  assert.throws(() => decodeLspFrame("Content-Length: 9000000\r\n\r\n"), /invalid or exceeds/);
});

test("language IDs are selected by file extension", () => {
  assert.equal(lspLanguageId("src/main.py"), "python");
  assert.equal(lspLanguageId("app.tsx"), "typescript");
  assert.equal(lspLanguageId("script.js"), "javascript");
  assert.equal(lspLanguageId("readme.md"), null);
});

test("initialize params advertise completion, diagnostics, definitions and hover", () => {
  const params = initializeParams("file:///work/project", 123);
  assert.equal(params.processId, 123);
  assert.equal(params.rootUri, "file:///work/project");
  assert.equal(params.capabilities.textDocument.completion.completionItem.snippetSupport, true);
  assert.equal(params.capabilities.textDocument.hover.contentFormat[0], "markdown");
  assert.ok(params.capabilities.textDocument.codeAction.codeActionLiteralSupport.codeActionKind.valueSet.includes('quickfix'));
  assert.deepEqual(params.capabilities.textDocument.codeAction.resolveSupport.properties, ['edit', 'command']);
});


test("completion responses normalize both array and CompletionList forms", () => {
  const items = normalizeCompletionItems({ isIncomplete: false, items: [
    { label: "print", kind: 3, detail: "Built-in", documentation: { kind: "markdown", value: "Writes output" } },
    { label: "", kind: 6 },
    { label: "pathlib", kind: 9, insertText: "pathlib.Path" },
  ] });
  assert.equal(items.length, 2);
  assert.equal(items[0].label, "print");
  assert.equal(items[0].type, "function");
  assert.match(items[0].detail, /Writes output/);
  assert.equal(items[1].apply, "pathlib.Path");
  assert.equal(normalizeCompletionItems([{ label: "str", kind: 8 }])[0].type, "type");
});
