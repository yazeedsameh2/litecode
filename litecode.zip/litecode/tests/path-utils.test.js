import test from 'node:test';
import assert from 'node:assert/strict';
import { pathMatchesPrefix, replacePathPrefix } from '../src/path-utils.js';

test('path prefix matching handles nested files and separator variants', () => {
  assert.equal(pathMatchesPrefix('/work/src/app.js', '/work/src'), true);
  assert.equal(pathMatchesPrefix('C:\\work\\src\\app.js', 'C:\\work\\src'), true);
  assert.equal(pathMatchesPrefix('/work/src-old/app.js', '/work/src'), false);
});

test('path prefix matching supports Windows case-insensitive paths', () => {
  assert.equal(pathMatchesPrefix('C:\\WORK\\SRC\\app.js', 'c:\\work\\src', true), true);
  assert.equal(pathMatchesPrefix('/work/src/app.js', '/work/src', false), true);
  assert.equal(pathMatchesPrefix('/work/src/app.js', '/work/SRC', false), false);
});

test('path prefix replacement changes only the requested path segment', () => {
  assert.equal(replacePathPrefix('/work/src/app.js', '/work/src', '/work/lib'), '/work/lib/app.js');
  assert.equal(replacePathPrefix('C:\\work\\src\\app.js', 'C:\\work\\src', 'C:\\work\\lib', true), 'C:\\work\\lib\\app.js');
  assert.equal(replacePathPrefix('/work/src-old/app.js', '/work/src', '/work/lib'), '/work/src-old/app.js');
  assert.equal(replacePathPrefix('/work/src', '/work/src', '/work/lib'), '/work/lib');
});
