import test from 'node:test';
import assert from 'node:assert/strict';
import { PythonDebugWorkflow } from '../src/dap-workflow.js';

function fakeClient() {
  const listeners = new Map(); const requests = [];
  return {
    requests,
    on(name, fn) { const set = listeners.get(name) || new Set(); set.add(fn); listeners.set(name, set); return () => set.delete(fn); },
    emit(name, value = {}) { for (const fn of listeners.get(name) || []) fn(value); },
    async request(command, args = {}) {
      requests.push({ command, args });
      if (command === 'initialize') return { body: { supportsConfigurationDoneRequest: true } };
      if (command === 'setBreakpoints') return { body: { breakpoints: args.lines.map((line) => ({ verified: true, line })) } };
      if (command === 'threads') return { body: { threads: [{ id: 1, name: 'MainThread' }] } };
      if (command === 'stackTrace') return { body: { stackFrames: [{ id: 4, name: 'main', line: 2 }] } };
      if (command === 'scopes') return { body: { scopes: [{ name: 'Locals', variablesReference: 9 }] } };
      if (command === 'variables') return { body: { variables: [{ name: 'x', value: '3' }] } };
      return { body: {} };
    },
  };
}

test('workflow initializes and subscribes to lifecycle events', async () => {
  const client = fakeClient(); const states = [];
  const workflow = new PythonDebugWorkflow(client, { onState: (item) => states.push(item.state) });
  const capabilities = await workflow.initialize();
  assert.equal(capabilities.supportsConfigurationDoneRequest, true);
  client.emit('event:initialized');
  assert.equal(workflow.state, 'configuring');
  assert.deepEqual(states, ['initializing', 'initialized', 'configuring']);
});

test('launch validates input and sends a constrained Python launch configuration', async () => {
  const client = fakeClient(); const workflow = new PythonDebugWorkflow(client);
  await workflow.initialize();
  await assert.rejects(workflow.launch({ program: '', cwd: '/project' }), /script path/);
  await workflow.launch({ program: '/project/main.py', cwd: '/project', args: ['hello'], stopOnEntry: false });
  const launch = client.requests.find((request) => request.command === 'launch');
  assert.equal(launch.args.program, '/project/main.py');
  assert.deepEqual(launch.args.args, ['hello']);
  assert.equal(launch.args.stopOnEntry, false);
});

test('breakpoints are deduplicated, sorted, and invalid lines removed', async () => {
  const client = fakeClient(); const workflow = new PythonDebugWorkflow(client); await workflow.initialize();
  const response = await workflow.setBreakpoints('/project/main.py', [8, 2, 8, 0, -1, '3', 4.5]);
  assert.deepEqual(client.requests.at(-1).args.lines, [2, 8]);
  assert.deepEqual(response.map((bp) => bp.line), [2, 8]);
});

test('configuration done follows adapter capability', async () => {
  const client = fakeClient(); const workflow = new PythonDebugWorkflow(client); await workflow.initialize();
  await assert.rejects(workflow.configurationDone(), /not waiting/);
  workflow.state = 'configuring'; await workflow.configurationDone();
  assert.equal(client.requests.at(-1).command, 'configurationDone');
  assert.equal(workflow.state, 'running');
});

test('stack, scopes, and variables are returned as safe arrays', async () => {
  const client = fakeClient(); const workflow = new PythonDebugWorkflow(client); await workflow.initialize();
  assert.equal((await workflow.threads())[0].id, 1);
  assert.equal((await workflow.stackTrace(1))[0].name, 'main');
  assert.equal((await workflow.scopes(4))[0].variablesReference, 9);
  assert.equal((await workflow.variables(9))[0].value, '3');
  await assert.rejects(workflow.stackTrace(), /stopped thread/);
});

test('execution controls require a valid thread and send correct DAP commands', async () => {
  const client = fakeClient(); const workflow = new PythonDebugWorkflow(client); await workflow.initialize();
  await assert.rejects(workflow.continue(), /debug thread/);
  await workflow.continue(1); await workflow.stepOver(1); await workflow.stepInto(1); await workflow.stepOut(1); await workflow.pause(1);
  assert.deepEqual(client.requests.slice(-5).map((item) => item.command), ['continue', 'next', 'stepIn', 'stepOut', 'pause']);
});

test('stop removes event listeners and resets workflow state', async () => {
  const client = fakeClient(); const workflow = new PythonDebugWorkflow(client); await workflow.initialize();
  workflow.state = 'stopped'; workflow.threadId = 2;
  await workflow.stop();
  assert.equal(workflow.state, 'idle'); assert.equal(workflow.threadId, null);
  client.emit('event:stopped', { threadId: 9 });
  assert.equal(workflow.threadId, null);
  assert.equal(client.requests.at(-1).command, 'disconnect');
});

test('initialized event emitted during initialize response is not lost', async () => {
  const client = fakeClient();
  const originalRequest = client.request;
  client.request = async (command, args) => {
    const result = await originalRequest(command, args);
    if (command === 'initialize') client.emit('event:initialized');
    return result;
  };
  const workflow = new PythonDebugWorkflow(client);
  await workflow.initialize();
  assert.equal(workflow.state, 'configuring');
});

test('failed initialize cleans up lifecycle listeners and returns to idle', async () => {
  const client = fakeClient();
  client.request = async () => { throw new Error('adapter unavailable'); };
  const workflow = new PythonDebugWorkflow(client);
  await assert.rejects(workflow.initialize(), /adapter unavailable/);
  assert.equal(workflow.state, 'idle');
  // The client no longer has a workflow listener that could mutate state later.
  assert.doesNotThrow(() => client.emit('event:stopped', { threadId: 42 }));
  assert.equal(workflow.threadId, null);
});


test('launch waits for a late initialized event before configuration', async () => {
  const client = fakeClient(); const workflow = new PythonDebugWorkflow(client);
  await workflow.initialize();
  await workflow.launch({ program: '/project/main.py', cwd: '/project' });
  assert.equal(workflow.state, 'launching');
  const ready = workflow.waitForInitializedEvent(1000);
  client.emit('event:initialized');
  await ready;
  assert.equal(workflow.state, 'configuring');
  await workflow.configurationDone();
  assert.equal(workflow.state, 'running');
});
