import test from 'node:test';
import assert from 'node:assert/strict';
import { gitStatusLabel, isGitConflict } from '../src/git-utils.js';

test('recognizes every standard unmerged Git status', () => {
  for (const [index_status, worktree_status] of [['U','U'], ['A','U'], ['U','A'], ['D','U'], ['U','D'], ['A','A'], ['D','D'], [' ','U']]) {
    const file = { index_status, worktree_status };
    assert.equal(isGitConflict(file), true, `${index_status}${worktree_status}`);
    assert.equal(gitStatusLabel(file), '!');
  }
});

test('keeps ordinary Git statuses distinct from merge conflicts', () => {
  assert.equal(gitStatusLabel({ untracked: true, index_status: '?', worktree_status: '?' }), 'U');
  assert.equal(gitStatusLabel({ index_status: 'M', worktree_status: ' ' }), 'M');
  assert.equal(gitStatusLabel({ index_status: ' ', worktree_status: 'D' }), 'D');
  assert.equal(gitStatusLabel({ index_status: 'A', worktree_status: ' ' }), 'A');
  assert.equal(isGitConflict({ index_status: 'M', worktree_status: ' ' }), false);
});
