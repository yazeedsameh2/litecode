import test from 'node:test';
import assert from 'node:assert/strict';
import { collectProblems, withinRoot } from '../src/problems.js';

const diag = (severity, message, line = 0, character = 0, code = '') => ({ severity, message, code, range: { start: { line, character } } });

test('collects, normalizes, and orders diagnostics by severity then location', () => {
  const rows = collectProblems(new Map([
    ['/work/z.py', [diag(2, 'unused', 3, 2)]],
    ['/work/a.py', [diag(1, 'syntax', 1, 4, 'E001'), diag(4, 'hint', 0, 0)]],
  ]), { root: '/work' });
  assert.deepEqual(rows.map(({ severity, path, line, column }) => [severity, path, line, column]), [
    [1, '/work/a.py', 2, 5], [2, '/work/z.py', 4, 3], [4, '/work/a.py', 1, 1],
  ]);
});

test('supports severity and text filters', () => {
  const map = new Map([['/work/a.py', [diag(1, 'Syntax error', 0), diag(2, 'Unused variable', 1)]]]);
  assert.equal(collectProblems(map, { severity: 2 }).length, 1);
  assert.equal(collectProblems(map, { query: 'SYNTAX' }).length, 1);
  assert.equal(collectProblems(map, { query: 'missing' }).length, 0);
});

test('root matching respects path boundaries and Windows case', () => {
  assert.equal(withinRoot('/work/project/a.py', '/work/project'), true);
  assert.equal(withinRoot('/work/project2/a.py', '/work/project'), false);
  assert.equal(withinRoot('C:\\Work\\Project\\a.py', 'c:\\work\\project'), true);
  assert.equal(withinRoot('/other/a.py', '/work/project'), false);
});
