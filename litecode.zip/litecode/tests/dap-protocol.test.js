import test from 'node:test';
import assert from 'node:assert/strict';
import { DapMessageParser, encodeDapMessage, createDapRequest, isDapResponse, normalizeDapBreakpoint } from '../src/dap-protocol.js';

test('DAP frame encodes UTF-8 byte length, not character count', () => {
  const bytes = encodeDapMessage({ seq: 1, type: 'event', event: 'output', body: { output: 'مرحبا 🌟' } });
  const split = bytes.findIndex((b, i) => b === 13 && bytes[i + 1] === 10 && bytes[i + 2] === 13 && bytes[i + 3] === 10);
  const header = new TextDecoder().decode(bytes.slice(0, split));
  assert.equal(Number(header.match(/Content-Length: (\d+)/i)[1]), bytes.length - split - 4);
});

test('incremental parser handles split headers, bodies and UTF-8 sequences', () => {
  const frame = encodeDapMessage({ seq: 2, type: 'event', event: 'output', body: { output: '你好 🧪' } });
  const parser = new DapMessageParser();
  const at = Math.floor(frame.length / 2);
  assert.deepEqual(parser.push(frame.slice(0, at)), []);
  assert.deepEqual(parser.push(frame.slice(at)), [{ seq: 2, type: 'event', event: 'output', body: { output: '你好 🧪' } }]);
  assert.equal(parser.bufferedBytes, 0);
});

test('parser emits multiple frames from one chunk', () => {
  const a = encodeDapMessage({ seq: 1, type: 'event', event: 'initialized' });
  const b = encodeDapMessage({ seq: 2, type: 'event', event: 'terminated' });
  const joined = new Uint8Array(a.length + b.length); joined.set(a); joined.set(b, a.length);
  assert.deepEqual(new DapMessageParser().push(joined), [
    { seq: 1, type: 'event', event: 'initialized' }, { seq: 2, type: 'event', event: 'terminated' },
  ]);
});

test('parser rejects missing, duplicate, malformed and oversized lengths', () => {
  assert.throws(() => new DapMessageParser({ maxFrameBytes: 32 }).push('X: y\r\n\r\n{}'), /exactly one Content-Length/);
  assert.throws(() => new DapMessageParser({ maxFrameBytes: 32 }).push('Content-Length: x\r\n\r\n'), /invalid/);
  assert.throws(() => new DapMessageParser({ maxFrameBytes: 32 }).push('Content-Length: 33\r\n\r\n'), /limit/);
  assert.throws(() => new DapMessageParser({ maxFrameBytes: 32 }).push('Content-Length: 0\r\nContent-Length: 0\r\n\r\n'), /exactly one/);
});

test('parser rejects invalid JSON and messages without type', () => {
  const p = new DapMessageParser();
  assert.throws(() => p.push('Content-Length: 1\r\n\r\nx'), /valid JSON/);
  const p2 = new DapMessageParser();
  assert.throws(() => p2.push(encodeDapMessage({ seq: 1 })), /with a type/);
});

test('request builder validates command, sequence and arguments', () => {
  assert.deepEqual(createDapRequest('setBreakpoints', { lines: [2] }, 7), { seq: 7, type: 'request', command: 'setBreakpoints', arguments: { lines: [2] } });
  assert.throws(() => createDapRequest('bad command'), /Invalid/);
  assert.throws(() => createDapRequest('launch', {}, 0), /positive/);
  assert.throws(() => createDapRequest('launch', []), /object/);
});

test('response matcher correlates the request sequence', () => {
  assert.equal(isDapResponse({ type: 'response', request_seq: 4, success: true }, 4), true);
  assert.equal(isDapResponse({ type: 'response', request_seq: 5, success: true }, 4), false);
  assert.equal(isDapResponse({ type: 'response', request_seq: 4 }, 4), false);
});

test('breakpoint normalization validates locations and bounds message size', () => {
  assert.deepEqual(normalizeDapBreakpoint({ verified: true, line: 4, column: 2, id: 9, message: 'OK' }), { verified: true, line: 4, column: 2, id: 9, message: 'OK' });
  assert.equal(normalizeDapBreakpoint({ line: 0 }), null);
  assert.equal(normalizeDapBreakpoint({ line: 2, column: -1 }), null);
  assert.equal(normalizeDapBreakpoint(null), null);
  assert.equal(normalizeDapBreakpoint({ line: 2, message: 'x'.repeat(2000) }).message.length, 1000);
});
