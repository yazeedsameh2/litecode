import test from 'node:test';
import assert from 'node:assert/strict';
import { matchHtmlTagPrefix, buildHtmlTagInsertion } from '../src/completion-utils.js';

test('HTML completion recognizes partial tag names', () => {
  assert.deepEqual(matchHtmlTagPrefix('<di'), { typed: 'di', fromOffset: 2 });
  assert.deepEqual(matchHtmlTagPrefix('<my-widget'), { typed: 'my-widget', fromOffset: 9 });
  assert.deepEqual(matchHtmlTagPrefix('text <sec'), { typed: 'sec', fromOffset: 3 });
});

test('HTML completion ignores non-tag contexts', () => {
  assert.equal(matchHtmlTagPrefix('div'), null);
  assert.equal(matchHtmlTagPrefix('<123'), null);
  assert.equal(matchHtmlTagPrefix('<div>content'), null);
});

test('accepting an HTML tag inserts the close tag and leaves cursor inside', () => {
  assert.deepEqual(buildHtmlTagInsertion('div'), { text: 'div></div>', cursorOffset: 4 });
  assert.deepEqual(buildHtmlTagInsertion('section'), { text: 'section></section>', cursorOffset: 8 });
});
