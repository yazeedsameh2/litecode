import test from 'node:test';
import assert from 'node:assert/strict';
import { DapSession } from '../src/dap-session.js';

const neverReply = () => new DapSession({ sendBytes: async () => {}, requestTimeoutMs: 15 });

test('DAP request timeout rejects and releases the pending slot', async () => {
  const session = neverReply();
  await assert.rejects(session.request('threads'), /timed out after 15 ms/);
  assert.equal(session.pendingCount, 0);
  session.close();
});

test('DAP timeout emits a command-specific diagnostic event', async () => {
  const session = neverReply();
  let detail;
  session.on('requestTimeout:stackTrace', (value) => { detail = value; });
  await assert.rejects(session.request('stackTrace', { threadId: 1 }), /timed out/);
  assert.equal(detail.command, 'stackTrace');
  assert.equal(detail.timeoutMs, 15);
  session.close();
});

test('DAP response clears timeout and resolves normally', async () => {
  let request;
  const session = new DapSession({ sendBytes: async (message) => { request = message; }, requestTimeoutMs: 25 });
  const pending = session.request('threads');
  session.receive({ type: 'response', request_seq: request.seq, command: 'threads', success: true, body: { threads: [] } });
  assert.deepEqual((await pending).body.threads, []);
  assert.equal(session.pendingCount, 0);
  session.close();
});

test('DAP timeout accepts zero to disable and rejects unsafe values', () => {
  assert.doesNotThrow(() => new DapSession({ sendBytes: async () => {}, requestTimeoutMs: 0 }));
  assert.throws(() => new DapSession({ sendBytes: async () => {}, requestTimeoutMs: -1 }), /requestTimeoutMs/);
  assert.throws(() => new DapSession({ sendBytes: async () => {}, requestTimeoutMs: 600001 }), /requestTimeoutMs/);
});
