import test from 'node:test';
import assert from 'node:assert/strict';
import { parseArgsString, formatArgsString, normalizeRunConfig, buildPythonRunCommand, loadRunConfigs, saveRunConfig } from '../src/run-config.js';

test('argument parsing handles quotes, escapes and empty strings', () => {
  assert.deepEqual(parseArgsString('a "b c" d\\ e \'f g\' ""'), ['a', 'b c', 'd e', 'f g', '']);
  assert.deepEqual(parseArgsString('  '), []);
  assert.throws(() => parseArgsString('"open'), /Unterminated/);
  assert.throws(() => parseArgsString('x'.repeat(5000)), /too long/);
});

test('Windows argument parsing keeps backslashes in paths', () => {
  assert.deepEqual(parseArgsString('C:\\data\\in.csv "my file.txt"', { windows: true }), ['C:\\data\\in.csv', 'my file.txt']);
  assert.deepEqual(parseArgsString('say \\"hi\\"', { windows: true }), ['say', '"hi"']);
});

test('format and parse round-trip arbitrary arguments on POSIX', () => {
  const args = ['plain', 'with space', "it's", '$(x)', ''];
  assert.deepEqual(parseArgsString(formatArgsString(args)), args);
});

test('normalizeRunConfig requires a Python file and keeps paths inside the project', () => {
  const ok = normalizeRunConfig({ program: '/p/src/main.py', args: '--n 3' }, { root: '/p' });
  assert.deepEqual(ok, { program: '/p/src/main.py', cwd: '/p/src', args: ['--n', '3'], stopOnEntry: false, breakOnUncaught: true });
  assert.throws(() => normalizeRunConfig({ program: '/p/a.txt' }, { root: '/p' }), /not a Python/);
  assert.throws(() => normalizeRunConfig({ program: '' }, { root: '/p' }), /Choose a Python file/);
  assert.throws(() => normalizeRunConfig({ program: '/other/a.py' }, { root: '/p' }), /inside the opened project/);
  assert.throws(() => normalizeRunConfig({ program: '/p/a.py', cwd: '/etc' }, { root: '/p' }), /working directory/);
  assert.throws(() => normalizeRunConfig({ program: '/p-evil/a.py' }, { root: '/p' }), /inside/);
  assert.throws(() => normalizeRunConfig({ program: '/p/a.py' }, {}), /Open a project/);
});

test('Windows validation is case-insensitive', () => {
  const cfg = normalizeRunConfig({ program: 'c:\\Proj\\sub\\Main.PY', cwd: 'C:\\proj' }, { root: 'C:\\PROJ', os: 'windows' });
  assert.equal(cfg.cwd, 'C:\\proj');
});

test('python run command quotes every user-controlled value', () => {
  const posix = buildPythonRunCommand({ program: "/p/my dir/a'b.py", cwd: '/p/my dir', args: ['x y', '$(rm)'] }, 'linux', 'python3');
  assert.equal(posix, `cd '/p/my dir' && clear && 'python3' '/p/my dir/a'\\''b.py' 'x y' '$(rm)'`);
  const win = buildPythonRunCommand({ program: 'C:\\My Proj\\a.py', cwd: 'C:\\My Proj', args: ['q"x'] }, 'windows', 'py');
  assert.equal(win, 'cd /d "C:\\My Proj" && cls && "py" "C:\\My Proj\\a.py" "q""x"');
});

test('run configurations persist per program with a bounded history', () => {
  const data = new Map();
  const storage = { getItem: (k) => data.get(k) ?? null, setItem: (k, v) => data.set(k, v) };
  for (let i = 0; i < 60; i++) saveRunConfig(`/p/${i}.py`, { cwd: '/p', args: [String(i)] }, storage);
  const all = loadRunConfigs(storage);
  assert.equal(Object.keys(all).length, 50);
  assert.deepEqual(all['/p/59.py'].args, ['59']);
  assert.deepEqual(loadRunConfigs({ getItem: () => '[1]' }), {});
  assert.deepEqual(loadRunConfigs({ getItem: () => { throw new Error('x'); } }), {});
});
