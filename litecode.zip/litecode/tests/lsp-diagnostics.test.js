import test from 'node:test';
import assert from 'node:assert/strict';
import { mapDiagnosticsToRanges } from '../src/lsp-diagnostics.js';

test('maps zero-based LSP ranges to UTF-16 offsets across lines', () => {
  const ranges = mapDiagnosticsToRanges('const x = 1;\nprint(x)', [{ severity: 1, message: 'bad name', range: { start: { line: 1, character: 6 }, end: { line: 1, character: 7 } } }]);
  assert.deepEqual(ranges[0], { from: 19, to: 20, lineFrom: 13, severity: 1, message: 'bad name', code: '' });
});

test('clamps out-of-range positions and supports empty ranges', () => {
  const ranges = mapDiagnosticsToRanges('abc\nxy', [
    { severity: 2, message: 'point', range: { start: { line: 99, character: 99 }, end: { line: 99, character: 99 } } },
    { message: 'bad range', range: { start: { line: 0, character: -2 }, end: { line: 0, character: 999 } } },
    { message: 'no range' },
  ]);
  assert.equal(ranges.length, 2);
  assert.deepEqual([ranges[0].from, ranges[0].to, ranges[0].lineFrom, ranges[0].severity], [6, 6, 4, 2]);
  assert.deepEqual([ranges[1].from, ranges[1].to], [0, 3]);
});

test('handles unicode characters using JavaScript UTF-16 offsets', () => {
  const ranges = mapDiagnosticsToRanges('🌟name', [{ message: 'symbol', range: { start: { line: 0, character: 2 }, end: { line: 0, character: 6 } } }]);
  assert.deepEqual([ranges[0].from, ranges[0].to], [2, 6]);
});
