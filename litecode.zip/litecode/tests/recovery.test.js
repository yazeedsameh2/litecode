import test from 'node:test';
import assert from 'node:assert/strict';
import { saveRecoverySnapshot, loadRecoverySnapshot, clearRecoverySnapshot, shouldRecover } from '../src/state.js';

function memoryStorage() {
  const data = new Map();
  return { getItem: (k) => data.has(k) ? data.get(k) : null, setItem: (k, v) => data.set(k, String(v)), removeItem: (k) => data.delete(k) };
}

test('recovery snapshot is stored locally and round-trips unsaved text', () => {
  const storage = memoryStorage();
  const snapshot = { tabs: [{ name: 'draft.py', path: null, content: 'print("unsaved")', cleanContent: '', cursor: 5 }], activeName: 'draft.py' };
  assert.equal(saveRecoverySnapshot(snapshot, storage), true);
  const restored = loadRecoverySnapshot(storage);
  assert.equal(restored.tabs[0].content, 'print("unsaved")');
  assert.ok(Number.isFinite(restored.recoveryAt));
});

test('invalid or corrupt recovery snapshots are ignored', () => {
  const storage = memoryStorage();
  storage.setItem('litecode.crashRecovery', '{broken');
  assert.equal(loadRecoverySnapshot(storage), null);
  storage.setItem('litecode.crashRecovery', JSON.stringify({ recoveryAt: Date.now(), tabs: [{ name: 'x' }] }));
  assert.equal(loadRecoverySnapshot(storage), null);
});

test('only a recovery snapshot newer than the regular session is restored', () => {
  assert.equal(shouldRecover({ savedAt: 100 }, { recoveryAt: 101, tabs: [] }), true);
  assert.equal(shouldRecover({ savedAt: 101 }, { recoveryAt: 100, tabs: [] }), false);
  assert.equal(shouldRecover({}, null), false);
});

test('clear recovery removes only the recovery snapshot', () => {
  const storage = memoryStorage();
  saveRecoverySnapshot({ tabs: [] }, storage);
  assert.equal(clearRecoverySnapshot(storage), true);
  assert.equal(loadRecoverySnapshot(storage), null);
});
