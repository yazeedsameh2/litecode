import test from 'node:test';
import assert from 'node:assert/strict';
import { PythonDebugWorkflow } from '../src/dap-workflow.js';
import { DapSession } from '../src/dap-session.js';

function manualClient() {
  const listeners = new Map(); const requests = []; const pending = [];
  return {
    requests, pending,
    on(name, fn) { const set = listeners.get(name) || new Set(); set.add(fn); listeners.set(name, set); return () => set.delete(fn); },
    emit(name, value = {}) { for (const fn of [...(listeners.get(name) || [])]) fn(value); },
    request(command, args = {}) {
      requests.push({ command, args });
      return new Promise((resolve, reject) => pending.push({ command, resolve, reject }));
    },
    answer(command, body = {}) { const i = pending.findIndex((p) => p.command === command); pending.splice(i, 1)[0].resolve({ body }); },
    fail(command, error) { const i = pending.findIndex((p) => p.command === command); pending.splice(i, 1)[0].reject(error); },
  };
}
const tick = () => new Promise((r) => setImmediate(r));

test('launch() resolves without waiting for the (deferred) launch response', async () => {
  const client = manualClient(); const wf = new PythonDebugWorkflow(client);
  const init = wf.initialize(); client.answer('initialize', { supportsConfigurationDoneRequest: true }); await init;
  const { response } = await wf.launch({ program: '/p/a.py', cwd: '/p' });
  assert.equal(client.pending.some((p) => p.command === 'launch'), true);
  client.emit('event:initialized');
  assert.equal(wf.state, 'configuring');
  const done = wf.configurationDone(); client.answer('configurationDone'); await done;
  client.answer('launch'); await response;
  assert.equal(wf.state, 'running');
});

test('a launch failure rejects the response without an unhandled rejection', async () => {
  const client = manualClient(); const wf = new PythonDebugWorkflow(client);
  const init = wf.initialize(); client.answer('initialize'); await init;
  const { response } = await wf.launch({ program: '/p/a.py', cwd: '/p' });
  client.fail('launch', new Error('bad program'));
  await assert.rejects(response, /bad program/);
});

test('configurationDone does not clobber a stopped event that arrived during the request', async () => {
  const client = manualClient(); const wf = new PythonDebugWorkflow(client);
  const init = wf.initialize(); client.answer('initialize', { supportsConfigurationDoneRequest: true }); await init;
  await wf.launch({ program: '/p/a.py', cwd: '/p' });
  client.emit('event:initialized');
  const done = wf.configurationDone();
  client.emit('event:stopped', { reason: 'entry', threadId: 1 });
  client.answer('configurationDone'); await done;
  assert.equal(wf.state, 'stopped');
  assert.equal(wf.threadId, 1);
});

test('stopped before the continue response wins; a failed resume restores the paused state', async () => {
  const client = manualClient(); const wf = new PythonDebugWorkflow(client);
  const init = wf.initialize(); client.answer('initialize'); await init;
  client.emit('event:stopped', { reason: 'breakpoint', threadId: 1 });
  const resumed = wf.continue(); assert.equal(wf.state, 'running');
  client.emit('event:stopped', { reason: 'breakpoint', threadId: 1 });
  client.answer('continue'); await resumed;
  assert.equal(wf.state, 'stopped');
  const failing = wf.stepOver(); assert.equal(wf.state, 'running');
  client.fail('next', new Error('thread is gone'));
  await assert.rejects(failing, /thread is gone/);
  assert.equal(wf.state, 'stopped');
});

test('session loss rejects waiters and reports a disconnected state', async () => {
  const client = manualClient(); const states = []; const wf = new PythonDebugWorkflow(client, { onState: (s) => states.push(s.state) });
  const init = wf.initialize(); client.answer('initialize'); await init;
  const wait = wf.waitForInitializedEvent(5000);
  client.emit('close', new Error('Debug adapter exited'));
  await assert.rejects(wait, /Debug adapter exited/);
  assert.equal(wf.state, 'disconnected');
  await wf.stop(); // must not send disconnect to a dead adapter
  assert.equal(client.requests.some((r) => r.command === 'disconnect'), false);
  assert.equal(states.at(-1), 'idle');
});

test('stop() gives up on a silent adapter after the disconnect timeout', async () => {
  const client = manualClient(); const wf = new PythonDebugWorkflow(client, { disconnectTimeoutMs: 20 });
  const init = wf.initialize(); client.answer('initialize'); await init;
  const t0 = Date.now(); await wf.stop();
  assert.ok(Date.now() - t0 < 500);
  assert.equal(wf.state, 'idle');
});

test('exception filters are limited to what the adapter advertises', async () => {
  const client = manualClient(); const wf = new PythonDebugWorkflow(client);
  const init = wf.initialize(); client.answer('initialize', { exceptionBreakpointFilters: [{ filter: 'uncaught' }] }); await init;
  const p = wf.setExceptionBreakpoints(['uncaught', 'bogus']); await tick();
  assert.deepEqual(client.requests.at(-1).args, { filters: ['uncaught'] });
  client.answer('setExceptionBreakpoints'); assert.deepEqual(await p, ['uncaught']);
});

test('events after a terminated program do not revive the session', async () => {
  const client = manualClient(); const wf = new PythonDebugWorkflow(client);
  const init = wf.initialize(); client.answer('initialize'); await init;
  client.emit('event:exited', { exitCode: 3 }); client.emit('event:terminated', {});
  assert.equal(wf.state, 'terminated'); assert.equal(wf.exitCode, 3);
});

test('DapSession.respond sends well-formed replies to reverse requests', async () => {
  const sent = []; const session = new DapSession({ sendBytes: async (m) => sent.push(m) });
  await session.respond({ type: 'request', seq: 9, command: 'runInTerminal' }, { success: false, message: 'nope' });
  assert.deepEqual({ ...sent[0], seq: undefined }, { seq: undefined, type: 'response', request_seq: 9, success: false, command: 'runInTerminal', message: 'nope' });
  await assert.rejects(session.respond({ type: 'event' }), /request is required/);
  session.close();
  assert.equal(await session.respond({ type: 'request', seq: 1, command: 'x' }), false);
});
