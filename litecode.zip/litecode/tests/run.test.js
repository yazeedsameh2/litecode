import test from 'node:test';
import assert from 'node:assert/strict';
import { basename, dirname, joinPath, buildRun } from '../src/run.js';

test('path helpers support Windows and POSIX paths', () => {
  assert.equal(basename('C:\\Users\\Test User\\main.py'), 'main.py');
  assert.equal(dirname('C:\\Users\\Test User\\main.py'), 'C:\\Users\\Test User');
  assert.equal(basename('/home/test/main.py'), 'main.py');
  assert.equal(joinPath('C:\\work\\', 'src/main.py', 'windows'), 'C:\\work\\src\\main.py');
});

test('HTML files request the Live Server instead of terminal execution', () => {
  assert.deepEqual(buildRun('/tmp/site/index.html', 'linux'), { live: true });
});

test('POSIX runner safely single-quotes filenames containing shell metacharacters', () => {
  const result = buildRun("/tmp/my project/a'b;$(touch nope).py", 'linux');
  assert.ok(result.cmd.includes("'a'\\''b;$(touch nope).py'"));
  assert.ok(result.cmd.startsWith("cd '/tmp/my project' && clear && 'python3' "));
});

test('Windows runner quotes paths with spaces and supports native compilation', () => {
  const result = buildRun('C:\\My Projects\\hello world.cpp', 'windows');
  assert.ok(result.cmd.startsWith('cd /d "C:\\My Projects" && cls && g++ "hello world.cpp"'));
  assert.ok(result.cmd.includes('"hello world.exe"'));
});

test('runner returns null for unsupported file extensions', () => {
  assert.equal(buildRun('/tmp/file.unknown', 'linux'), null);
});
