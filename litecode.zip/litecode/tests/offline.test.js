import test from 'node:test';
import assert from 'node:assert/strict';
import { getConnectionState, connectionLabel, connectionHint, isLikelyNetworkFailure } from '../src/offline.js';

test('offline state is advisory and clearly labelled', () => {
  assert.equal(getConnectionState(false), 'offline');
  assert.equal(connectionLabel(false), '● Offline');
  assert.match(connectionHint(false), /remain available/i);
  assert.match(connectionHint(false), /Package downloads/i);
});

test('unknown and online states do not claim core features need internet', () => {
  assert.equal(getConnectionState(true), 'online');
  assert.equal(getConnectionState(undefined), 'online');
  assert.match(connectionHint(true), /run locally/i);
});

test('network failure classification is narrow and safe for helpful messages', () => {
  assert.equal(isLikelyNetworkFailure('npm ERR! ECONNRESET'), true);
  assert.equal(isLikelyNetworkFailure('Could not resolve host registry.npmjs.org'), true);
  assert.equal(isLikelyNetworkFailure('permission denied'), false);
});
