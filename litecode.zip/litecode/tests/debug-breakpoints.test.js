import test from 'node:test';
import assert from 'node:assert/strict';
import { BreakpointStore } from '../src/debug-breakpoints.js';
import { remapBreakpointLines } from '../src/breakpoint-mapping.js';

test('toggle adds/removes lines, keeps them sorted and emits change events', () => {
  const store = new BreakpointStore(); const events = [];
  store.subscribe((e) => events.push(e));
  assert.equal(store.toggle('/p/a.py', 9), true);
  assert.equal(store.toggle('/p/a.py', 2), true);
  assert.deepEqual(store.lines('/p/a.py'), [2, 9]);
  assert.equal(store.toggle('/p/a.py', 2), false);
  assert.deepEqual(events.map((e) => e.type), ['change', 'change', 'change']);
  assert.throws(() => store.toggle('/p/a.py', 0), /Invalid/);
});

test('setLines dedupes, drops invalid values and ignores no-op updates', () => {
  const store = new BreakpointStore(); let n = 0;
  store.subscribe(() => n++);
  assert.equal(store.setLines('/p/a.py', [5, 5, 1, -3, 'x', 2.5]), true);
  assert.deepEqual(store.lines('/p/a.py'), [1, 5]);
  assert.equal(store.setLines('/p/a.py', [1, 5]), false);
  assert.equal(n, 1);
  store.setLines('/p/a.py', []);
  assert.deepEqual(store.entries(), []);
});

test('Windows-style stores match paths case-insensitively and across separators', () => {
  const store = new BreakpointStore({ caseInsensitive: true });
  store.toggle('C:\\Proj\\Main.py', 4);
  assert.deepEqual(store.lines('c:/proj/main.py'), [4]);
  assert.equal(store.has('C:/PROJ/MAIN.PY', 4), true);
});

test('adapter results move lines, flag unverified ones and keep newer user edits', () => {
  const store = new BreakpointStore(); const events = [];
  store.setLines('/p/a.py', [3, 8]);
  store.subscribe((e) => events.push(e.type));
  store.setLines('/p/a.py', [3, 8, 12], { silent: true }); // user added 12 while the request was in flight
  assert.equal(store.applyAdapterResult('/p/a.py', [3, 8], [{ verified: true, line: 3 }, { verified: false, line: 9 }]), true);
  assert.deepEqual(store.lines('/p/a.py'), [3, 9, 12]);
  assert.deepEqual(store.unverified('/p/a.py'), [9]);
  assert.deepEqual(events, ['verification']);
  store.resetVerification();
  assert.deepEqual(store.unverified('/p/a.py'), []);
});

test('rename follows files and folders without touching siblings', () => {
  const store = new BreakpointStore();
  store.setLines('/p/src/a.py', [1]); store.setLines('/p/src-old/a.py', [2]);
  assert.equal(store.rename('/p/src', '/p/lib'), 1);
  assert.deepEqual(store.entries().map(([p]) => p).sort(), ['/p/lib/a.py', '/p/src-old/a.py']);
});

test('serialize/restore round-trips and rejects malformed data', () => {
  const store = new BreakpointStore(); store.setLines('/p/a.py', [4, 2]);
  const copy = new BreakpointStore();
  assert.equal(copy.restore(store.serialize()), 1);
  assert.deepEqual(copy.lines('/p/a.py'), [2, 4]);
  assert.equal(copy.restore(null), 0);
  assert.equal(copy.restore([1, 2]), 0);
  copy.restore({ '/x.py': 'nope', '': [1], '/y.py': [7] });
  assert.deepEqual(copy.entries(), [['/y.py', [7]]]);
});

// Minimal CodeMirror-like docs for the remapping test.
const docOf = (text) => {
  const starts = [0]; for (let i = 0; i < text.length; i++) if (text[i] === '\n') starts.push(i + 1);
  return { length: text.length, lines: starts.length, line: (n) => ({ from: starts[n - 1] }), lineAt: (pos) => ({ number: starts.filter((s) => s <= pos).length }) };
};
test('breakpoints follow their code when lines are inserted above, at column 0, or deleted', () => {
  const before = docOf('a\nb\nc\nd');
  // insert "x\n" at position 0 -> everything moves down one line
  const after1 = docOf('x\na\nb\nc\nd');
  assert.deepEqual(remapBreakpointLines([2, 4], before, after1, (p) => p + 2), [3, 5]);
  // Enter at column 0 of line 3 (insert "\n" at pos 4): assoc=1 keeps the breakpoint with "c"
  const after2 = docOf('a\nb\n\nc\nd');
  assert.deepEqual(remapBreakpointLines([3], before, after2, (p, assoc) => (p === 4 && assoc === 1 ? p + 1 : p)), [4]);
  // deleting line 2 entirely ("b\n", positions 2..4) collapses its breakpoint onto the next line
  const after3 = docOf('a\nc\nd');
  assert.deepEqual(remapBreakpointLines([2, 3], before, after3, (p) => (p >= 4 ? p - 2 : p >= 2 ? 2 : p)), [2]);
  assert.deepEqual(remapBreakpointLines([99, 0, 1.5], before, before, (p) => p), []);
});
