/**
 * Offline-first helpers. Network state is advisory only: browser online/offline
 * events cannot prove registry reachability, so core editor features must never
 * be gated on this value.
 */
export function getConnectionState(isOnline) {
  return isOnline === false ? 'offline' : 'online';
}

export function connectionLabel(isOnline) {
  return getConnectionState(isOnline) === 'offline' ? '● Offline' : '● Online';
}

export function connectionHint(isOnline) {
  return getConnectionState(isOnline) === 'offline'
    ? 'Offline: editing, local files, terminal, Git, and installed tools remain available. Package downloads and remote services may need internet.'
    : 'Network appears available. Core editor features run locally; package downloads and remote services may use the network.';
}

export function isLikelyNetworkFailure(message) {
  return /ENETUNREACH|ENOTFOUND|ECONNRESET|ECONNREFUSED|ETIMEDOUT|network|offline|internet|registry|fetch failed|could not resolve/i.test(String(message || ''));
}
