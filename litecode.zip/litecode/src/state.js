const SKEY = 'litecode.settings';
const SESSION = 'litecode.session';
const RECENTS = 'litecode.recentProjects';

export const defaults = {
  theme: 'dark',
  fontSize: 14,
  tabSize: 4,
  wordWrap: false,
  autoSave: false,
  pythonCmd: '',
};

let stored = {};
try { stored = JSON.parse(localStorage.getItem(SKEY) || '{}'); } catch { /* ignore */ }
export const settings = { ...defaults, ...stored };

export function saveSettings() {
  try { localStorage.setItem(SKEY, JSON.stringify(settings)); } catch { /* ignore */ }
}

export function loadSession() {
  try { return JSON.parse(localStorage.getItem(SESSION) || '{}'); } catch { return {}; }
}

export function saveSession(s) {
  try { localStorage.setItem(SESSION, JSON.stringify(s)); } catch { /* ignore */ }
}

export function loadRecentProjects() {
  try {
    const items = JSON.parse(localStorage.getItem(RECENTS) || '[]');
    return Array.isArray(items) ? items.filter((x) => typeof x === 'string').slice(0, 8) : [];
  } catch { return []; }
}

export function rememberRecentProject(path) {
  if (!path || typeof path !== 'string') return loadRecentProjects();
  const items = [path, ...loadRecentProjects().filter((x) => x !== path)].slice(0, 8);
  try { localStorage.setItem(RECENTS, JSON.stringify(items)); } catch { /* storage may be unavailable */ }
  return items;
}
