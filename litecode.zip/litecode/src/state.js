const SKEY = 'litecode.settings';
const SESSION = 'litecode.session';

export const defaults = {
  theme: 'dark',
  fontSize: 14,
  tabSize: 4,
  wordWrap: false,
  autoSave: false,
  pythonCmd: '',
};

let stored = {};
try { stored = JSON.parse(localStorage.getItem(SKEY) || '{}'); } catch { /* ignore */ }
export const settings = { ...defaults, ...stored };

export function saveSettings() {
  try { localStorage.setItem(SKEY, JSON.stringify(settings)); } catch { /* ignore */ }
}

export function loadSession() {
  try { return JSON.parse(localStorage.getItem(SESSION) || '{}'); } catch { return {}; }
}

export function saveSession(s) {
  try { localStorage.setItem(SESSION, JSON.stringify(s)); } catch { /* ignore */ }
}
