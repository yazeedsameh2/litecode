const SKEY = 'litecode.settings';
const SESSION = 'litecode.session';
const RECENTS = 'litecode.recentProjects';
const RECOVERY = 'litecode.crashRecovery';

export const defaults = {
  theme: 'dark',
  fontSize: 14,
  tabSize: 4,
  wordWrap: false,
  autoSave: false,
  pythonCmd: '',
};

let stored = {};
try { stored = JSON.parse(localStorage.getItem(SKEY) || '{}'); } catch { /* ignore */ }
export const settings = { ...defaults, ...stored };

export function saveSettings() {
  try { localStorage.setItem(SKEY, JSON.stringify(settings)); } catch { /* ignore */ }
}

export function loadSession() {
  try { return JSON.parse(localStorage.getItem(SESSION) || '{}'); } catch { return {}; }
}

export function saveSession(s) {
  try { localStorage.setItem(SESSION, JSON.stringify(s)); } catch { /* ignore */ }
}

export function loadRecentProjects() {
  try {
    const items = JSON.parse(localStorage.getItem(RECENTS) || '[]');
    return Array.isArray(items) ? items.filter((x) => typeof x === 'string').slice(0, 8) : [];
  } catch { return []; }
}

export function rememberRecentProject(path) {
  if (!path || typeof path !== 'string') return loadRecentProjects();
  const items = [path, ...loadRecentProjects().filter((x) => x !== path)].slice(0, 8);
  try { localStorage.setItem(RECENTS, JSON.stringify(items)); } catch { /* storage may be unavailable */ }
  return items;
}

// Crash-recovery snapshots are stored separately from normal session state.
export function saveRecoverySnapshot(snapshot, storage = localStorage) {
  if (!snapshot || !Array.isArray(snapshot.tabs)) return false;
  try { storage.setItem(RECOVERY, JSON.stringify({ ...snapshot, recoveryAt: Date.now() })); return true; } catch { return false; }
}
export function loadRecoverySnapshot(storage = localStorage) {
  try { const value = JSON.parse(storage.getItem(RECOVERY) || 'null'); if (!value || !Array.isArray(value.tabs) || !Number.isFinite(value.recoveryAt)) return null; if (!value.tabs.every((t) => t && typeof t.content === 'string' && typeof t.name === 'string')) return null; return value; } catch { return null; }
}
export function clearRecoverySnapshot(storage = localStorage) { try { storage.removeItem(RECOVERY); return true; } catch { return false; } }
export function shouldRecover(session, recovery) { return !!recovery && recovery.recoveryAt > (Number(session?.savedAt) || 0); }
