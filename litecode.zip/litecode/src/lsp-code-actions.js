const fileUri = (path) => { let p = String(path).replace(/\\/g, '/'); if (/^[A-Za-z]:\//.test(p)) p = `/${p}`; return `file://${encodeURI(p).replace(/#/g, '%23').replace(/\?/g, '%3F')}`; };

export function getCurrentDocumentEdits(workspaceEdit, path, doc) {
  const uri = fileUri(path);
  let edits = [];
  if (workspaceEdit.changes) {
    const keys = Object.keys(workspaceEdit.changes);
    if (keys.some((key) => key !== uri)) return null;
    edits = workspaceEdit.changes[uri] || [];
  } else if (workspaceEdit.documentChanges) {
    if (workspaceEdit.documentChanges.some((change) => !change.textDocument || change.textDocument.uri !== uri || !Array.isArray(change.edits))) return null;
    edits = workspaceEdit.documentChanges.flatMap((change) => change.edits);
  }
  const mapped = [];
  for (const edit of edits) {
    const start = edit?.range?.start;
    const end = edit?.range?.end;
    if (!start || !end || typeof edit.newText !== 'string') return null;
    if (start.line < 0 || end.line < start.line || start.line >= doc.lines || end.line >= doc.lines) return null;
    const fromLine = doc.line(start.line + 1);
    const toLine = doc.line(end.line + 1);
    const from = fromLine.from + Math.min(fromLine.length, Math.max(0, Number(start.character) || 0));
    const to = toLine.from + Math.min(toLine.length, Math.max(0, Number(end.character) || 0));
    if (to < from) return null;
    mapped.push({ from, to, insert: edit.newText });
  }
  mapped.sort((a, b) => a.from - b.from || a.to - b.to);
  for (let i = 1; i < mapped.length; i++) if (mapped[i].from < mapped[i - 1].to || (mapped[i].from === mapped[i - 1].from && mapped[i].to === mapped[i].from)) return null;
  return mapped;
}


// Convert LSP TextEdit[] into safe CodeMirror changes for the current document.
// Reject malformed/out-of-bounds/overlapping edits rather than partially applying them.
export function getCurrentTextEdits(edits, doc) {
  if (!Array.isArray(edits)) return null;
  const mapped = [];
  for (const edit of edits) {
    const start = edit?.range?.start;
    const end = edit?.range?.end;
    if (!start || !end || typeof edit.newText !== 'string' ||
        !Number.isInteger(start.line) || !Number.isInteger(start.character) ||
        !Number.isInteger(end.line) || !Number.isInteger(end.character) ||
        start.line < 0 || end.line < start.line || start.line >= doc.lines || end.line >= doc.lines) return null;
    const fromLine = doc.line(start.line + 1);
    const toLine = doc.line(end.line + 1);
    if (start.character < 0 || end.character < 0 || start.character > fromLine.length || end.character > toLine.length) return null;
    const from = fromLine.from + start.character;
    const to = toLine.from + end.character;
    if (to < from) return null;
    mapped.push({ from, to, insert: edit.newText });
  }
  mapped.sort((a, b) => a.from - b.from || a.to - b.to);
  for (let i = 1; i < mapped.length; i++) {
    if (mapped[i].from < mapped[i - 1].to ||
        (mapped[i].from === mapped[i - 1].from && mapped[i].to === mapped[i].from)) return null;
  }
  return mapped;
}
