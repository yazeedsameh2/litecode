const MAX_TASKS = 80;
const MAX_COMMAND = 2000;
const MAX_LABEL = 100;

/** Parse the intentionally small .litecode/tasks.json format. */
export function parseTaskConfig(input) {
  const data = typeof input === 'string' ? JSON.parse(input) : input;
  const tasks = Array.isArray(data) ? data : data?.tasks;
  if (!Array.isArray(tasks)) throw new TypeError('expected an array or an object with a tasks array');
  if (tasks.length > MAX_TASKS) throw new RangeError(`at most ${MAX_TASKS} tasks are allowed`);
  const result = [];
  const seen = new Set();
  for (const raw of tasks) {
    if (!raw || typeof raw !== 'object' || Array.isArray(raw)) continue;
    const command = typeof raw.command === 'string' ? raw.command.trim() : '';
    const label = typeof raw.label === 'string' ? raw.label.trim() : (typeof raw.name === 'string' ? raw.name.trim() : '');
    const cwd = typeof raw.cwd === 'string' ? raw.cwd.trim() : '.';
    if (!command || !label || command.length > MAX_COMMAND || label.length > MAX_LABEL) continue;
    if (/[\u0000-\u0008\u000b\u000c\u000e-\u001f]/.test(command)) continue;
    const key = label.toLowerCase();
    if (seen.has(key)) continue;
    seen.add(key);
    result.push({ label, command, cwd });
  }
  return result;
}

export function validateTask(task, root) {
  if (!task || typeof task.command !== 'string' || !task.command.trim()) return { ok: false, error: 'Task has no command.' };
  if (typeof root !== 'string' || !root.trim()) return { ok: false, error: 'Open a project folder first.' };
  const cwd = String(task.cwd || '.').replace(/\\/g, '/');
  if (cwd.startsWith('/') || /^[A-Za-z]:/.test(cwd) || cwd.split('/').some((part) => part === '..')) {
    return { ok: false, error: 'Task working directory must stay inside the project folder.' };
  }
  const normalizedRoot = root.replace(/[\\/]+$/, '');
  const resolved = cwd === '.' ? normalizedRoot : `${normalizedRoot}/${cwd.replace(/^\.\//, '').replace(/\/+$/, '')}`;
  return { ok: true, cwd: resolved };
}
