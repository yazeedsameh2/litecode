import './style.css';
import { invoke } from '@tauri-apps/api/core';
import { open as openDialog, save as saveDialog } from '@tauri-apps/plugin-dialog';
import { getCurrentWindow } from '@tauri-apps/api/window';
import { $, el, esc, toast, askInput, askChoice, openPalette, fuzzy, drag } from './ui.js';
import { settings, saveSettings, loadSession, saveSession } from './state.js';
import { createEditor, langInfo } from './editor.js';
import { createTree, colorFor } from './tree.js';
import { initTerminals, newTerminal, runInTerminal, stopActive, closeTerminal, hasTerminals, fitActive, restyle, focusActive } from './terminal.js';
import { buildRun, dirname, basename, joinPath } from './run.js';

const app = $('#app');
const S = { root: null, tabs: [], active: null, os: 'linux', live: null, files: null, untitled: 1, view: 'explorer' };
let autosaveTimer = 0;
let sessionTimer = 0;

// ───────────── editor + tabs ─────────────
const editor = createEditor($('#editor'), {
  onChange: () => {
    const t = S.active;
    if (!t) return;
    renderTabDirty(t);
    if (settings.autoSave && t.path) {
      clearTimeout(autosaveTimer);
      autosaveTimer = setTimeout(() => { if (isDirty(t)) saveTab(t); }, 800);
    }
  },
  onSelection: updateStatus,
});

const stateOf = (t) => (t === S.active ? editor.view.state : t.state);
const isDirty = (t) => !stateOf(t).doc.eq(t.clean);

function updateStatus(st) {
  const s = st || (S.active && stateOf(S.active));
  if (!s || !S.active) {
    $('#st-pos').textContent = '';
    $('#st-lang').textContent = '';
    $('#st-indent').textContent = '';
  } else {
    const sel = s.selection.main;
    const ln = s.doc.lineAt(sel.head);
    const picked = sel.empty ? '' : `  (${Math.abs(sel.to - sel.from)} selected)`;
    $('#st-pos').textContent = `Ln ${ln.number}, Col ${sel.head - ln.from + 1}${picked}`;
    $('#st-lang').textContent = langInfo(S.active.path || S.active.name)[0];
    $('#st-indent').textContent = `Spaces: ${settings.tabSize}`;
  }
  $('#st-root').textContent = S.root ? basename(S.root) : '';
  const live = $('#st-live');
  live.textContent = S.live ? `◉ Port ${S.live.port}` : '○ Live';
  $('#btn-live').classList.toggle('on', !!S.live);
}

function renderTabs() {
  const bar = $('#tabs');
  bar.innerHTML = '';
  for (const t of S.tabs) {
    const d = el('div', 'tab' + (t === S.active ? ' active' : '') + (isDirty(t) ? ' dirty' : ''));
    d.title = t.path || t.name;
    d.innerHTML = `<span class="fi" style="background:${colorFor(t.name)}"></span><span class="tl">${esc(t.name)}</span><span class="tx"></span>`;
    d._tab = t;
    d.onmousedown = (e) => {
      if (e.button === 1) { e.preventDefault(); closeTab(t); }
      else if (e.button === 0 && !e.target.classList.contains('tx')) activate(t);
    };
    d.querySelector('.tx').onclick = (e) => { e.stopPropagation(); closeTab(t); };
    bar.appendChild(d);
  }
  const a = bar.querySelector('.tab.active');
  if (a) a.scrollIntoView({ block: 'nearest', inline: 'nearest' });
  const empty = S.tabs.length === 0;
  $('#welcome').style.display = empty ? 'flex' : 'none';
  $('#editor').style.visibility = empty ? 'hidden' : 'visible';
}

function renderTabDirty(t) {
  for (const d of $('#tabs').children) if (d._tab === t) d.classList.toggle('dirty', isDirty(t));
}

function activate(t, line) {
  if (S.active && S.active !== t) S.active.state = editor.view.state;
  S.active = t;
  editor.setState(t.state);
  renderTabs();
  tree.setActive(t.path);
  updateStatus();
  if (line) editor.goTo(line.line, line.col); else editor.focus();
  saveSessionSoon();
}

async function openFile(path, line) {
  const found = S.tabs.find((t) => t.path === path);
  if (found) return activate(found, line);
  let text;
  try { text = await invoke('read_file', { path }); }
  catch (e) { return toast(`Can't open ${basename(path)}: ${e}`, 'err'); }
  const state = editor.makeState(text, path);
  const tab = { path, name: basename(path), state, clean: state.doc };
  S.tabs.push(tab);
  activate(tab, line);
}

function newUntitled() {
  const name = `untitled-${S.untitled++}`;
  const state = editor.makeState('', name);
  const tab = { path: null, name, state, clean: state.doc };
  S.tabs.push(tab);
  activate(tab);
}

async function saveTab(t, saveAs = false) {
  let path = t.path;
  if (!path || saveAs) {
    const start = t.path || (S.root ? joinPath(S.root, t.name, S.os) : t.name);
    path = await saveDialog({ defaultPath: start });
    if (!path) return false;
  }
  const text = stateOf(t).doc.toString();
  try { await invoke('write_file', { path, content: text }); }
  catch (e) { toast(`Save failed: ${e}`, 'err'); return false; }
  const renamed = path !== t.path;
  t.path = path;
  t.name = basename(path);
  t.clean = stateOf(t).doc;
  if (renamed) {
    if (t === S.active) editor.setLanguage(path);
    S.files = null;
    tree.refresh();
  }
  renderTabs();
  updateStatus();
  tree.setActive(S.active && S.active.path);
  return true;
}

async function closeTab(t, force = false) {
  if (!force && isDirty(t)) {
    const c = await askChoice(`Save changes to ${t.name}?`, ['Save', "Don't save", 'Cancel'], 1);
    if (c === -1 || c === 2) return false;
    if (c === 0 && !(await saveTab(t))) return false;
  }
  const i = S.tabs.indexOf(t);
  S.tabs.splice(i, 1);
  if (S.active === t) {
    S.active = null;
    const next = S.tabs[Math.min(i, S.tabs.length - 1)];
    if (next) activate(next);
    else { editor.setState(editor.makeState('', '')); renderTabs(); tree.setActive(null); updateStatus(); }
  } else renderTabs();
  saveSessionSoon();
  return true;
}

function cycleTab(dir) {
  if (S.tabs.length < 2) return;
  const i = S.tabs.indexOf(S.active);
  activate(S.tabs[(i + dir + S.tabs.length) % S.tabs.length]);
}

// ───────────── explorer ─────────────
const tree = createTree($('#tree'), {
  onOpen: (p) => openFile(p),
  onChange: saveSessionSoon,
  onOpenFolder: () => pickFolder(),
  onTerminalHere: async (dir) => { showPanel(true); await newTerminal(dir); },
  onNewFile: (dir) => newFileIn(dir),
  onNewFolder: (dir) => newFolderIn(dir),
  onRename: async (path) => {
    const name = await askInput('Rename', basename(path));
    if (!name || name === basename(path)) return;
    const to = joinPath(dirname(path), name, S.os);
    try { await invoke('rename_path', { from: path, to }); } catch (e) { return toast(String(e), 'err'); }
    for (const t of S.tabs) {
      if (t.path && (t.path === path || t.path.startsWith(path + '/') || t.path.startsWith(path + '\\'))) {
        t.path = to + t.path.slice(path.length);
        t.name = basename(t.path);
      }
    }
    S.files = null;
    renderTabs();
    tree.refresh();
  },
  onDelete: async (path, isDir) => {
    const c = await askChoice(`Delete ${basename(path)}${isDir ? ' and everything inside it' : ''}? This can't be undone.`, ['Cancel', 'Delete'], 1);
    if (c !== 1) return;
    try { await invoke('delete_path', { path }); } catch (e) { return toast(String(e), 'err'); }
    for (const t of [...S.tabs]) {
      if (t.path && (t.path === path || t.path.startsWith(path + '/') || t.path.startsWith(path + '\\'))) await closeTab(t, true);
    }
    S.files = null;
    tree.refresh();
  },
});

async function pickFolder() {
  const p = await openDialog({ directory: true, multiple: false });
  if (p) openFolder(p);
}

async function openFolder(path) {
  try { await invoke('list_dir', { path }); } catch (e) { return toast(`Can't open folder: ${e}`, 'err'); }
  S.root = path.replace(/[\\/]+$/, '') || path;
  S.files = null;
  $('#folder-name').textContent = basename(S.root) || S.root;
  await tree.setRoot(S.root);
  if (S.live) await stopLive();
  updateStatus();
  saveSessionSoon();
}

async function openFiles() {
  const sel = await openDialog({ multiple: true, directory: false });
  if (!sel) return;
  for (const p of [].concat(sel)) await openFile(p);
}

// ───────────── search in files ─────────────
const sOpt = { c: false, r: false };
let searchTimer = 0;
async function runSearch() {
  const q = $('#sq').value;
  const box = $('#sresults');
  if (!S.root) { box.innerHTML = '<div class="empty">Open a folder to search in it.</div>'; return; }
  if (!q) { box.innerHTML = ''; return; }
  let hits;
  try { hits = await invoke('search_in_files', { root: S.root, query: q, caseSensitive: sOpt.c, useRegex: sOpt.r }); }
  catch (e) { box.innerHTML = `<div class="empty">${esc(e)}</div>`; return; }
  if (!hits.length) { box.innerHTML = '<div class="empty">No results.</div>'; return; }
  const groups = new Map();
  for (const h of hits) { if (!groups.has(h.path)) groups.set(h.path, []); groups.get(h.path).push(h); }
  box.innerHTML = '';
  for (const [path, list] of groups) {
    const rel = path.slice(S.root.length + 1);
    box.appendChild(el('div', 'sfile', `${esc(rel)}<small>${list.length}</small>`));
    for (const h of list.slice(0, 200)) {
      const d = el('div', 'shit', `<b>${h.line}</b>${esc(h.text)}`);
      d.onclick = () => openFile(path, { line: h.line, col: 1 });
      box.appendChild(d);
    }
  }
}
$('#sq').oninput = () => { clearTimeout(searchTimer); searchTimer = setTimeout(runSearch, 300); };
$('#sq').onkeydown = (e) => { if (e.key === 'Enter') runSearch(); };
$('#sc-case').onclick = (e) => { sOpt.c = !sOpt.c; e.currentTarget.classList.toggle('on', sOpt.c); runSearch(); };
$('#sc-re').onclick = (e) => { sOpt.r = !sOpt.r; e.currentTarget.classList.toggle('on', sOpt.r); runSearch(); };

function showView(v) {
  S.view = v;
  app.classList.remove('no-side');
  for (const b of document.querySelectorAll('.abtn[data-view]')) b.classList.toggle('active', b.dataset.view === v);
  $('#view-explorer').style.display = v === 'explorer' ? 'flex' : 'none';
  $('#view-search').style.display = v === 'search' ? 'flex' : 'none';
  if (v === 'search') { $('#sq').focus(); $('#sq').select(); }
  fitSoon();
}
for (const b of document.querySelectorAll('.abtn[data-view]')) {
  b.onclick = () => {
    if (S.view === b.dataset.view && !app.classList.contains('no-side')) toggleSidebar();
    else showView(b.dataset.view);
  };
}
function toggleSidebar() { app.classList.toggle('no-side'); fitSoon(); }

// ───────────── terminal panel ─────────────
function showPanel(on) {
  const show = on == null ? app.classList.contains('panel-hidden') : on;
  app.classList.toggle('panel-hidden', !show);
  if (show) {
    if (!hasTerminals()) newTerminal(S.root);
    else { fitSoon(); focusActive(); }
  } else editor.focus();
  saveSessionSoon();
}
let fitRaf = 0;
function fitSoon() { cancelAnimationFrame(fitRaf); fitRaf = requestAnimationFrame(fitActive); }

// ───────────── run + live server ─────────────
async function runCurrent() {
  const t = S.active;
  if (!t) return toast('Open a file to run it');
  if (!t.path) { if (!(await saveTab(t))) return; }
  else if (isDirty(t)) { if (!(await saveTab(t))) return; }
  const r = buildRun(t.path, S.os, settings.pythonCmd);
  if (!r) return toast(`No runner for .${t.name.split('.').pop()} files`, 'err');
  if (r.live) return goLive(true);
  showPanel(true);
  await runInTerminal(r.cmd, dirname(t.path));
}

function previewUrl() {
  if (!S.live) return '';
  let rel = '/';
  const a = S.active;
  if (a && a.path && S.root && /\.html?$/i.test(a.path) && a.path.startsWith(S.root)) {
    rel = a.path.slice(S.root.length).replace(/\\/g, '/');
    if (!rel.startsWith('/')) rel = '/' + rel;
  }
  return `http://127.0.0.1:${S.live.port}${encodeURI(rel)}`;
}

async function startLive() {
  if (!S.root) { toast('Open a folder first — the Live Server serves that folder', 'err'); return false; }
  try { S.live = { port: await invoke('live_start', { root: S.root }) }; }
  catch (e) { toast(`Live Server failed: ${e}`, 'err'); return false; }
  return true;
}
async function stopLive() {
  await invoke('live_stop');
  S.live = null;
  app.classList.remove('preview-on');
  $('#pv-frame').src = 'about:blank';
  updateStatus();
}
function showPreview() {
  if (!S.live) return;
  const url = previewUrl();
  $('#pv-url').value = url;
  $('#pv-frame').src = url;
  app.classList.add('preview-on');
}
async function goLive(navigate = false) {
  if (!S.live && !(await startLive())) return;
  if (navigate || !app.classList.contains('preview-on')) showPreview();
  updateStatus();
}
async function toggleLive() {
  if (S.live) await stopLive();
  else await goLive(true);
}
$('#pv-reload').onclick = () => { $('#pv-frame').src = $('#pv-url').value; };
$('#pv-current').onclick = () => showPreview();
$('#pv-close').onclick = () => app.classList.remove('preview-on');
$('#pv-ext').onclick = () => invoke('open_external', { url: $('#pv-url').value }).catch((e) => toast(String(e), 'err'));

// ───────────── settings + theme ─────────────
function applySettings() {
  document.documentElement.dataset.theme = settings.theme;
  document.documentElement.style.setProperty('--fs', settings.fontSize + 'px');
  editor.reconfigure();
  restyle();
  updateStatus();
  saveSettings();
}
const setNumber = async (key, label, min, max) => {
  const v = await askInput(label, String(settings[key]));
  const n = parseInt(v, 10);
  if (!Number.isFinite(n) || n < min || n > max) return v && toast(`Enter a number between ${min} and ${max}`, 'err');
  settings[key] = n;
  applySettings();
};
const toggleTheme = () => { settings.theme = settings.theme === 'dark' ? 'light' : 'dark'; applySettings(); };
const zoom = (d) => { settings.fontSize = Math.min(32, Math.max(9, settings.fontSize + d)); applySettings(); };

// ───────────── commands + palette ─────────────
const commands = [
  { label: 'File: New File', key: 'Ctrl+N', run: newUntitled },
  { label: 'File: Open File…', key: 'Ctrl+O', run: openFiles },
  { label: 'File: Open Folder…', key: 'Ctrl+Shift+O', run: pickFolder },
  { label: 'File: Save', key: 'Ctrl+S', run: () => S.active && saveTab(S.active) },
  { label: 'File: Save As…', key: 'Ctrl+Shift+S', run: () => S.active && saveTab(S.active, true) },
  { label: 'File: Save All', run: async () => { for (const t of S.tabs) if (isDirty(t)) await saveTab(t); } },
  { label: 'File: Close Tab', key: 'Ctrl+W', run: () => S.active && closeTab(S.active) },
  { label: 'File: Toggle Auto Save', run: () => { settings.autoSave = !settings.autoSave; applySettings(); toast(`Auto save ${settings.autoSave ? 'on' : 'off'}`); } },
  { label: 'Run: Run Current File', key: 'F5', run: runCurrent },
  { label: 'Run: Stop', run: stopActive },
  { label: 'Live Server: Start / Stop', key: 'Ctrl+Alt+L', run: toggleLive },
  { label: 'Live Server: Show Current File in Preview', run: () => goLive(true) },
  { label: 'Terminal: Toggle Panel', key: 'Ctrl+`', run: () => showPanel() },
  { label: 'Terminal: New Terminal', key: 'Ctrl+Shift+`', run: () => { showPanel(true); newTerminal(S.root); } },
  { label: 'Terminal: Close Terminal', run: () => closeTerminal() },
  { label: 'View: Toggle Sidebar', key: 'Ctrl+B', run: toggleSidebar },
  { label: 'View: Explorer', key: 'Ctrl+Shift+E', run: () => showView('explorer') },
  { label: 'View: Search in Files', key: 'Ctrl+Shift+F', run: () => showView('search') },
  { label: 'View: Toggle Light / Dark Theme', run: toggleTheme },
  { label: 'View: Zoom In', key: 'Ctrl+=', run: () => zoom(1) },
  { label: 'View: Zoom Out', key: 'Ctrl+-', run: () => zoom(-1) },
  { label: 'Preferences: Set Font Size…', run: () => setNumber('fontSize', 'Font size', 9, 32) },
  { label: 'Preferences: Set Tab Size…', run: () => setNumber('tabSize', 'Spaces per tab', 1, 8) },
  { label: 'Preferences: Toggle Word Wrap', run: () => { settings.wordWrap = !settings.wordWrap; applySettings(); } },
  {
    label: 'Preferences: Set Python Command…',
    run: async () => {
      const v = await askInput('Python command', settings.pythonCmd || (S.os === 'windows' ? 'python' : 'python3'), 'For example: python, python3 or py');
      if (v) { settings.pythonCmd = v; applySettings(); }
    },
  },
  { label: 'Go to Line…', key: 'Ctrl+G', run: () => quickOpen(':') },
];

async function quickOpen(initial = '') {
  if (S.root && !S.files) {
    try { S.files = await invoke('list_files', { root: S.root }); } catch { S.files = []; }
  }
  const provider = (q) => {
    if (q.startsWith('>')) {
      return fuzzy(commands, q.slice(1), (c) => c.label).map((c) => ({ label: c.label, detail: c.key || '', run: c.run }));
    }
    if (q.startsWith(':')) {
      const n = parseInt(q.slice(1), 10);
      if (!Number.isFinite(n) || !S.active) return [{ label: 'Type a line number', detail: '', run: () => {} }];
      return [{ label: `Go to line ${n}`, detail: '', run: () => editor.goTo(n) }];
    }
    const list = S.files || S.tabs.filter((t) => t.path).map((t) => t.path);
    return fuzzy(list, q, (f) => f).map((f) => ({
      label: basename(f),
      detail: dirname(f.replace(/\\/g, '/')),
      run: () => openFile(S.files ? joinPath(S.root, f, S.os) : f),
    }));
  };
  openPalette(provider, initial);
}

// ───────────── keyboard ─────────────
// Use the physical key (e.code) for letters so shortcuts also work with an Arabic layout.
function keyOf(e) {
  if (e.code && e.code.startsWith('Key')) return e.code.slice(3).toLowerCase();
  const map = { Backquote: '`', Equal: '=', Minus: '-', NumpadAdd: '=', NumpadSubtract: '-' };
  return map[e.code] || e.key.toLowerCase();
}
addEventListener('keydown', (e) => {
  const ctrl = e.ctrlKey || e.metaKey;
  const k = keyOf(e);
  const inTerm = !!e.target.closest && !!e.target.closest('.xterm');
  if (inTerm && !(e.shiftKey || e.altKey || (/^f\d+$/.test(k)) || k === '`')) return;
  const go = (fn) => { e.preventDefault(); e.stopPropagation(); fn(); };

  if (e.key === 'F5') return go(runCurrent);
  if (e.key === 'F1') return go(() => quickOpen('>'));
  if (!ctrl) return;
  if (k === 's') return go(() => S.active && saveTab(S.active, e.shiftKey));
  if (k === 'p') return go(() => quickOpen(e.shiftKey ? '>' : ''));
  if (k === 'n' && !e.shiftKey) return go(newUntitled);
  if (k === 'o') return go(e.shiftKey ? pickFolder : openFiles);
  if (k === 'w') return go(() => S.active && closeTab(S.active));
  if (k === 'b') return go(toggleSidebar);
  if (k === '`') return go(() => (e.shiftKey ? (showPanel(true), newTerminal(S.root)) : showPanel()));
  if (k === 'e' && e.shiftKey) return go(() => showView('explorer'));
  if (k === 'f' && e.shiftKey) return go(() => showView('search'));
  if (k === 'l' && e.altKey) return go(toggleLive);
  if (e.key === 'Tab') return go(() => cycleTab(e.shiftKey ? -1 : 1));
  if (k === '=') return go(() => zoom(1));
  if (k === '-') return go(() => zoom(-1));
  if (k === 'g' && !e.altKey) return go(() => quickOpen(':'));
}, true);

addEventListener('contextmenu', (e) => { if (!e.target.closest('.cm-editor, .xterm, input')) e.preventDefault(); });
document.addEventListener('modal-closed', () => { if (S.active) editor.focus(); });

// ───────────── layout (resizers) ─────────────
drag($('#rs'), (e) => { app.style.setProperty('--sw', Math.min(600, Math.max(160, e.clientX - 46)) + 'px'); });
drag($('#hrs'), (e) => {
  const h = innerHeight - e.clientY - 24;
  app.style.setProperty('--ph', Math.min(innerHeight - 160, Math.max(90, h)) + 'px');
});
drag($('#prs'), (e) => {
  const r = $('#work').getBoundingClientRect();
  app.style.setProperty('--pw', Math.min(r.width - 200, Math.max(180, r.right - e.clientX)) + 'px');
});
document.addEventListener('layout-changed', () => { fitSoon(); saveSessionSoon(); });

// ───────────── buttons ─────────────
$('#btn-run').onclick = runCurrent;
$('#btn-live').onclick = toggleLive;
$('#st-live').onclick = toggleLive;
$('#btn-theme').onclick = toggleTheme;
$('#w-open').onclick = pickFolder;
$('#t-newfile').onclick = () => (S.root ? newFileIn(tree.selectedDir()) : pickFolder());
$('#t-newfolder').onclick = () => (S.root ? newFolderIn(tree.selectedDir()) : pickFolder());
$('#t-refresh').onclick = () => { S.files = null; tree.refresh(); };
$('#p-new').onclick = () => newTerminal(S.root);
$('#p-stop').onclick = stopActive;
$('#p-kill').onclick = () => closeTerminal();
$('#p-hide').onclick = () => showPanel(false);
$('#tabs').addEventListener('dblclick', (e) => { if (e.target === $('#tabs')) newUntitled(); });
async function newFileIn(dir) {
  const name = await askInput('New file', '', 'Name, or folder/name to create folders too');
  if (!name) return;
  const path = joinPath(dir, name, S.os);
  try { await invoke('create_file', { path }); } catch (e) { return toast(String(e), 'err'); }
  S.files = null;
  await tree.refresh();
  openFile(path);
}
async function newFolderIn(dir) {
  const name = await askInput('New folder');
  if (!name) return;
  try { await invoke('create_dir', { path: joinPath(dir, name, S.os) }); } catch (e) { return toast(String(e), 'err'); }
  S.files = null;
  tree.refresh();
}

// ───────────── session ─────────────
function saveSessionSoon() { clearTimeout(sessionTimer); sessionTimer = setTimeout(saveSessionNow, 600); }
function saveSessionNow() {
  const cs = getComputedStyle(app);
  saveSession({
    root: S.root,
    files: S.tabs.filter((t) => t.path).map((t) => t.path),
    active: S.active && S.active.path,
    expanded: tree.expanded(),
    sw: app.style.getPropertyValue('--sw') || cs.getPropertyValue('--sw'),
    ph: app.style.getPropertyValue('--ph'),
    pw: app.style.getPropertyValue('--pw'),
    panel: !app.classList.contains('panel-hidden'),
    view: S.view,
  });
}

// refresh the tree + file index when coming back to the window (files may have changed in the terminal)
let focusTimer = 0;
addEventListener('focus', () => {
  clearTimeout(focusTimer);
  focusTimer = setTimeout(() => { S.files = null; if (S.root) tree.refresh(); }, 250);
});

// ───────────── close guard ─────────────
getCurrentWindow().onCloseRequested(async (e) => {
  const dirty = S.tabs.filter(isDirty);
  if (dirty.length) {
    e.preventDefault();
    const c = await askChoice(`${dirty.length} file(s) have unsaved changes.`, ['Save all', 'Discard', 'Cancel'], 1);
    if (c === -1 || c === 2) return;
    if (c === 0) {
      for (const t of dirty) await saveTab(t);
      if (S.tabs.some(isDirty)) return;
    }
    saveSessionNow();
    await getCurrentWindow().destroy();
  } else saveSessionNow();
});

// ───────────── boot ─────────────
(async function boot() {
  S.os = await invoke('os_name');
  applySettings();
  await initTerminals({ tabs: $('#ptabs'), body: $('#pbody'), onAllClosed: () => showPanel(false) });
  app.classList.add('panel-hidden');

  const ses = loadSession();
  if (ses.sw) app.style.setProperty('--sw', ses.sw);
  if (ses.ph) app.style.setProperty('--ph', ses.ph);
  if (ses.pw) app.style.setProperty('--pw', ses.pw);
  tree.setExpanded(ses.expanded);
  if (ses.root) await openFolder(ses.root); else await tree.refresh();
  for (const f of ses.files || []) await openFile(f);
  const a = S.tabs.find((t) => t.path === ses.active);
  if (a) activate(a);
  if (ses.view === 'search') showView('search');
  if (ses.panel) showPanel(true);
  renderTabs();
  updateStatus();
})();
