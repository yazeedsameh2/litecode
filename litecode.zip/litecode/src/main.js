import './style.css';
import { invoke } from '@tauri-apps/api/core';
import { open as openDialog, save as saveDialog } from '@tauri-apps/plugin-dialog';
import { getCurrentWindow } from '@tauri-apps/api/window';
import { $, el, esc, toast, askInput, askChoice, openPalette, fuzzy, drag } from './ui.js';
import { settings, saveSettings, loadSession, saveSession, loadRecentProjects, rememberRecentProject, saveRecoverySnapshot, loadRecoverySnapshot, clearRecoverySnapshot, shouldRecover } from './state.js';
import { createEditor, langInfo } from './editor.js';
import { createTree, colorFor } from './tree.js';
import { initTerminals, newTerminal, runInTerminal, stopActive, closeTerminal, hasTerminals, fitActive, restyle, focusActive } from './terminal.js';
import { buildRun, dirname, basename, joinPath } from './run.js';
import { parseTaskConfig, validateTask } from './tasks.js';
import { pathMatchesPrefix, replacePathPrefix } from './path-utils.js';
import { buildPackageCommand, buildDependencyCommand } from './packages.js';
import { LspClient, fileUri } from './lsp-client.js';
import { collectProblems } from './problems.js';
import { getCurrentDocumentEdits, getCurrentTextEdits } from './lsp-code-actions.js';
import { connectionLabel, connectionHint, isLikelyNetworkFailure } from './offline.js';
import { createRecoveryScheduler } from './recovery-scheduler.js';
import { DapClient } from './dap-client.js';
import { PythonDebugWorkflow } from './dap-workflow.js';

const app = $('#app');
const S = { root: null, tabs: [], active: null, os: 'linux', live: null, files: null, gitFiles: [], untitled: 1, view: 'explorer', lsp: null };
let dapClient = null;
let debugWorkflow = null;
let debugView = null;
let debugMode = false;
let debugBusy = false;
const debugBreakpoints = new Map();
const lspVersions = new Map();
const lspDiagnostics = new Map();
let lspChangeTimer = 0;
let autosaveTimer = 0;
let liveSaveTimer = 0;
let sessionTimer = 0;
const recoveryWriter = createRecoveryScheduler(saveRecoveryNow, 700);

// Network state is informational only. Never disable local editor features
// based on navigator.onLine; it does not reliably indicate registry reachability.
function updateNetworkStatus() {
  const online = navigator.onLine !== false;
  const item = $('#st-network');
  if (!item) return;
  item.textContent = connectionLabel(online);
  item.classList.toggle('network-online', online);
  item.classList.toggle('network-offline', !online);
  item.title = connectionHint(online);
  item.setAttribute('aria-label', item.title);
}
window.addEventListener('online', updateNetworkStatus);
window.addEventListener('offline', updateNetworkStatus);
window.addEventListener('pagehide', () => { recoveryWriter.flush(); if (dapClient) stopPythonDebug(true); });
document.addEventListener('visibilitychange', () => { if (document.visibilityState === 'hidden') recoveryWriter.flush(); });
$('#st-network').addEventListener('click', () => toast(connectionHint(navigator.onLine !== false)));
updateNetworkStatus();

// ───────────── editor + tabs ─────────────
const editor = createEditor($('#editor'), {
  onChange: () => {
    const t = S.active;
    if (!t) return;
    renderTabDirty(t);
    if (S.lsp && t.path && lspVersions.has(t.path)) {
      clearTimeout(lspChangeTimer);
      lspChangeTimer = setTimeout(() => {
        const version = (lspVersions.get(t.path) || 1) + 1; lspVersions.set(t.path, version);
        S.lsp?.changeDocument(t.path, stateOf(t).doc.toString(), version).catch((e) => console.warn('LSP document sync failed:', e));
      }, 180);
    }
    saveSessionSoon();
    recoveryWriter.schedule();
    if (settings.autoSave && t.path) {
      clearTimeout(autosaveTimer);
      autosaveTimer = setTimeout(() => { if (isDirty(t)) saveTab(t); }, 800);
    }
    // Live Server serves files from disk, so sync edits to disk while previewing.
    if (S.live && t.path && S.root && (t.path === S.root || t.path.startsWith(S.root + '/') || t.path.startsWith(S.root + '\\'))) {
      clearTimeout(liveSaveTimer);
      liveSaveTimer = setTimeout(() => { if (isDirty(t)) saveTab(t); }, 500);
    }
  },
  onSelection: updateStatus,
  getLspCompletions: (context, path) => {
    if (!S.lsp || !path || !S.active || S.active.path !== path) return null;
    return S.lsp.complete(path, context.state, context.pos);
  },
});

const stateOf = (t) => (t === S.active ? editor.view.state : t.state);
const lspLanguageIdSafe = (path) => ['py','js','mjs','cjs','jsx','ts','tsx'].includes(String(path || '').split('.').pop().toLowerCase());
const pathWithinRoot = (path, root) => {
  if (!path || !root) return false;
  const normalize = (value) => String(value).replace(/\\/g, '/').replace(/\/+$/, '');
  const file = normalize(path);
  const base = normalize(root);
  const insensitive = S.os === 'windows';
  return (insensitive ? file.toLowerCase() : file) === (insensitive ? base.toLowerCase() : base) ||
    (insensitive ? file.toLowerCase() : file).startsWith((insensitive ? base.toLowerCase() : base) + '/');
};
const isDirty = (t) => !stateOf(t).doc.eq(t.clean);

function updateStatus(st) {
  const s = st || (S.active && stateOf(S.active));
  if (!s || !S.active) {
    $('#st-pos').textContent = '';
    $('#st-lang').textContent = '';
    $('#st-indent').textContent = '';
  } else {
    const sel = s.selection.main;
    const ln = s.doc.lineAt(sel.head);
    const picked = sel.empty ? '' : `  (${Math.abs(sel.to - sel.from)} selected)`;
    $('#st-pos').textContent = `Ln ${ln.number}, Col ${sel.head - ln.from + 1}${picked}`;
    $('#st-lang').textContent = langInfo(S.active.path || S.active.name)[0];
    $('#st-indent').textContent = `Spaces: ${settings.tabSize}`;
  }
  $('#st-root').textContent = S.root ? basename(S.root) : '';
  const live = $('#st-live');
  live.textContent = S.live ? `◉ Port ${S.live.port}` : '○ Live';
  $('#btn-live').classList.toggle('on', !!S.live);
}

function renderRecentProjects() {
  const box = $('#recent-projects');
  if (!box) return;
  const paths = loadRecentProjects();
  box.innerHTML = paths.length ? '<div class="recent-title">Recent projects</div>' : '';
  for (const path of paths) {
    const button = el('button', 'recent-project', `<span class="recent-icon">▣</span><span class="recent-name">${esc(basename(path))}</span><small>${esc(path)}</small>`);
    button.title = path;
    button.onclick = () => openFolder(path);
    box.appendChild(button);
  }
}

function renderTabs() {
  const bar = $('#tabs');
  bar.innerHTML = '';
  for (const t of S.tabs) {
    const d = el('div', 'tab' + (t === S.active ? ' active' : '') + (isDirty(t) ? ' dirty' : ''));
    d.title = t.path || t.name;
    d.innerHTML = `<span class="fi" style="background:${colorFor(t.name)}"></span><span class="tl">${esc(t.name)}</span><span class="tx"></span>`;
    d._tab = t;
    d.onmousedown = (e) => {
      if (e.button === 1) { e.preventDefault(); closeTab(t); }
      else if (e.button === 0 && !e.target.classList.contains('tx')) activate(t);
    };
    d.querySelector('.tx').onclick = (e) => { e.stopPropagation(); closeTab(t); };
    bar.appendChild(d);
  }
  const a = bar.querySelector('.tab.active');
  if (a) a.scrollIntoView({ block: 'nearest', inline: 'nearest' });
  const empty = S.tabs.length === 0;
  $('#welcome').style.display = empty ? 'flex' : 'none';
  $('#editor').style.visibility = empty ? 'hidden' : 'visible';
  if (empty) renderRecentProjects();
}

function renderTabDirty(t) {
  for (const d of $('#tabs').children) if (d._tab === t) d.classList.toggle('dirty', isDirty(t));
}

function activate(t, line) {
  if (S.active && S.active !== t) S.active.state = editor.view.state;
  S.active = t;
  editor.setState(t.state);
  renderTabs();
  tree.setActive(t.path);
  updateStatus();
  if (line) editor.goTo(line.line, line.col); else editor.focus();
  editor.setDiagnostics(t.path ? (lspDiagnostics.get(t.path) || []) : []);
  saveSessionSoon();
}

async function openFile(path, line) {
  const found = S.tabs.find((t) => t.path === path);
  if (found) return activate(found, line);
  let text;
  try { text = await invoke('read_file', { path }); }
  catch (e) { return toast(`Can't open ${basename(path)}: ${e}`, 'err'); }
  const state = editor.makeState(text, path);
  const tab = { path, name: basename(path), state, clean: state.doc };
  if (S.lsp && pathWithinRoot(path, S.root)) { lspVersions.set(path, 1); S.lsp.openDocument(path, text, 1).catch((e) => toast(`LSP: ${e.message || e}`, 'err')); }
  S.tabs.push(tab);
  activate(tab, line);
}

function newUntitled() {
  const name = `untitled-${S.untitled++}`;
  const state = editor.makeState('', name);
  const tab = { path: null, name, state, clean: state.doc };
  S.tabs.push(tab);
  activate(tab);
}

async function saveTab(t, saveAs = false) {
  let path = t.path;
  if (!path || saveAs) {
    const start = t.path || (S.root ? joinPath(S.root, t.name, S.os) : t.name);
    path = await saveDialog({ defaultPath: start });
    if (!path) return false;
  }
  const text = stateOf(t).doc.toString();
  try { await invoke('write_file', { path, content: text }); }
  catch (e) { toast(`Save failed: ${e}`, 'err'); return false; }
  const previousPath = t.path;
  const renamed = path !== previousPath;
  t.path = path;
  t.name = basename(path);
  t.clean = stateOf(t).doc;
  if (renamed) {
    if (S.lsp && previousPath) {
      await S.lsp.closeDocument(previousPath);
      lspVersions.delete(previousPath);
    }
    if (S.lsp && pathWithinRoot(path, S.root) && lspLanguageIdSafe(path)) {
      lspVersions.set(path, 1);
      await S.lsp.openDocument(path, text, 1).catch((e) => console.warn('LSP document open failed:', e));
    }
    if (t === S.active) editor.setLanguage(path);
    S.files = null;
    tree.refresh();
  }
  renderTabs();
  updateStatus();
  tree.setActive(S.active && S.active.path);
  saveSessionSoon();
  return true;
}

async function closeTab(t, force = false) {
  if (!force && isDirty(t)) {
    const c = await askChoice(`Save changes to ${t.name}?`, ['Save', "Don't save", 'Cancel'], 1);
    if (c === -1 || c === 2) return false;
    if (c === 0 && !(await saveTab(t))) return false;
  }
  const i = S.tabs.indexOf(t);
  if (t.path && S.lsp) { S.lsp.closeDocument(t.path); lspVersions.delete(t.path); }
  if (t.path) lspDiagnostics.delete(t.path);
  renderProblems();
  S.tabs.splice(i, 1);
  if (S.active === t) {
    S.active = null;
    const next = S.tabs[Math.min(i, S.tabs.length - 1)];
    if (next) activate(next);
    else { editor.setState(editor.makeState('', '')); renderTabs(); tree.setActive(null); updateStatus(); }
  } else renderTabs();
  saveSessionSoon();
  return true;
}

function cycleTab(dir) {
  if (S.tabs.length < 2) return;
  const i = S.tabs.indexOf(S.active);
  activate(S.tabs[(i + dir + S.tabs.length) % S.tabs.length]);
}

// ───────────── explorer ─────────────
const tree = createTree($('#tree'), {
  onOpen: (p) => openFile(p),
  onChange: saveSessionSoon,
  onOpenFolder: () => pickFolder(),
  onTerminalHere: async (dir) => { showPanel(true); await newTerminal(dir); },
  onNewFile: (dir) => newFileIn(dir),
  onNewFolder: (dir) => newFolderIn(dir),
  onRename: async (path) => {
    const name = await askInput('Rename', basename(path));
    if (!name || name === basename(path)) return;
    const to = joinPath(dirname(path), name, S.os);
    try { await invoke('rename_path', { from: path, to }); } catch (e) { return toast(String(e), 'err'); }
    const affected = S.tabs.filter((t) => t.path && pathMatchesPrefix(t.path, path, S.os === 'windows'));
    for (const t of affected) {
      const previousPath = t.path;
      const nextPath = replacePathPrefix(previousPath, path, to, S.os === 'windows');
      const text = stateOf(t).doc.toString();
      // Keep language-server document URIs and diagnostics aligned with the renamed path.
      if (S.lsp && lspVersions.has(previousPath)) {
        await S.lsp.closeDocument(previousPath).catch(() => {});
        lspVersions.delete(previousPath);
      }
      lspDiagnostics.delete(previousPath);
      t.path = nextPath;
      t.name = basename(nextPath);
      if (S.lsp && pathWithinRoot(nextPath, S.root) && lspLanguageIdSafe(nextPath)) {
        lspVersions.set(nextPath, 1);
        await S.lsp.openDocument(nextPath, text, 1).catch((e) => console.warn('LSP document reopen after rename failed:', e));
      }
      if (t === S.active) {
        editor.setLanguage(nextPath);
        editor.setDiagnostics(lspDiagnostics.get(nextPath) || []);
      }
    }
    renderProblems();
    S.files = null;
    renderTabs();
    tree.setActive(S.active && S.active.path);
    saveSessionSoon();
    tree.refresh();
  },
  onDelete: async (path, isDir) => {
    const c = await askChoice(`Delete ${basename(path)}${isDir ? ' and everything inside it' : ''}? This can't be undone.`, ['Cancel', 'Delete'], 1);
    if (c !== 1) return;
    try { await invoke('delete_path', { path }); } catch (e) { return toast(String(e), 'err'); }
    for (const t of [...S.tabs]) {
      if (t.path && (t.path === path || t.path.startsWith(path + '/') || t.path.startsWith(path + '\\'))) await closeTab(t, true);
    }
    S.files = null;
    tree.refresh();
  },
});

async function pickFolder() {
  const p = await openDialog({ directory: true, multiple: false });
  if (p) openFolder(p);
}

async function openFolder(path) {
  try { await invoke('list_dir', { path }); } catch (e) { return toast(`Can't open folder: ${e}`, 'err'); }
  const nextRoot = path.replace(/[\\/]+$/, '') || path;
  if (S.lsp && nextRoot !== S.root) {
    await S.lsp.dispose();
    S.lsp = null;
    lspVersions.clear();
    lspDiagnostics.clear();
    editor.setDiagnostics([]);
    renderProblems();
  }
  S.root = nextRoot;
  rememberRecentProject(S.root);
  renderRecentProjects();
  S.files = null;
  $('#folder-name').textContent = basename(S.root) || S.root;
  await tree.setRoot(S.root);
  if (S.live) await stopLive();
  if (S.view === 'source-control') refreshGit();
  updateStatus();
  saveSessionSoon();
}

async function openFiles() {
  const sel = await openDialog({ multiple: true, directory: false });
  if (!sel) return;
  for (const p of [].concat(sel)) await openFile(p);
}

// ───────────── search in files ─────────────
const sOpt = { c: false, r: false };
let searchTimer = 0;
async function runSearch() {
  const q = $('#sq').value;
  const box = $('#sresults');
  if (!S.root) { box.innerHTML = '<div class="empty">Open a folder to search in it.</div>'; return; }
  if (!q) { box.innerHTML = ''; return; }
  let result;
  try { result = await invoke('search_in_files', { root: S.root, query: q, caseSensitive: sOpt.c, useRegex: sOpt.r }); }
  catch (e) { box.replaceChildren(el('div', 'empty', String(e))); return; }
  const hits = result?.hits || [];
  box.replaceChildren();
  if (!hits.length) {
    box.appendChild(el('div', 'empty', result?.truncated ? 'Search limit reached before any matches were found.' : 'No results.'));
    if (result?.truncated) box.appendChild(el('div', 'search-limit-note', 'Narrow the search to scan a smaller project area.'));
    return;
  }
  const summary = el('div', 'search-summary', `${hits.length}${result.truncated ? '+' : ''} result(s) · ${result.files_scanned} file(s) scanned`);
  box.appendChild(summary);
  const groups = new Map();
  for (const h of hits) { if (!groups.has(h.path)) groups.set(h.path, []); groups.get(h.path).push(h); }
  for (const [path, list] of groups) {
    const rel = pathMatchesPrefix(path, S.root, S.os === 'windows') ? path.slice(S.root.replace(/[\\/]+$/, '').length).replace(/^[\\/]+/, '') : path;
    const heading = el('div', 'sfile', `${esc(rel)}<small>${list.length}</small>`);
    box.appendChild(heading);
    for (const h of list.slice(0, 200)) {
      const d = el('div', 'shit', `<b>${h.line}:${h.col || 1}</b>${esc(h.text)}`);
      d.title = `${rel}:${h.line}:${h.col || 1}`;
      d.onclick = () => openFile(path, { line: h.line, col: h.col || 1 });
      box.appendChild(d);
    }
  }
  if (result.truncated) box.appendChild(el('div', 'search-limit-note', 'Showing the first 1,000 matches. Refine your query to see more precise results.'));
}
$('#sq').oninput = () => { clearTimeout(searchTimer); searchTimer = setTimeout(runSearch, 300); };
$('#sq').onkeydown = (e) => { if (e.key === 'Enter') runSearch(); };
$('#sc-case').onclick = (e) => { sOpt.c = !sOpt.c; e.currentTarget.classList.toggle('on', sOpt.c); runSearch(); };
$('#sc-re').onclick = (e) => { sOpt.r = !sOpt.r; e.currentTarget.classList.toggle('on', sOpt.r); runSearch(); };
let pendingReplace = null;
const previewBox = $('#replace-preview');
function clearReplacePreview() {
  pendingReplace = null;
  previewBox.style.display = 'none';
  previewBox.replaceChildren();
}
function relPath(path) {
  const root = String(S.root || '').replace(/[\\/]+$/, '');
  return pathMatchesPrefix(path, root, S.os === 'windows') ? path.slice(root.length).replace(/^[\\/]+/, '') : path;
}
async function previewReplace() {
  const query = $('#sq').value;
  const replacement = $('#srq').value;
  if (!S.root) return toast('Open a project folder first', 'err');
  if (!query) return toast('Enter text to find first', 'err');
  // The preview must reflect disk contents, not stale unsaved editor buffers.
  for (const t of S.tabs) if (t.path && isDirty(t) && !(await saveTab(t))) return;
  clearReplacePreview();
  previewBox.style.display = 'block';
  previewBox.textContent = 'Preparing replacement preview…';
  try {
    const result = await invoke('preview_replace_in_files', {
      root: S.root, query, replacement, caseSensitive: sOpt.c, useRegex: sOpt.r,
    });
    pendingReplace = { query, replacement, caseSensitive: sOpt.c, useRegex: sOpt.r, result };
    previewBox.replaceChildren();
    const summary = el('div', 'replace-preview-summary', `${result.replacements} replacement(s) in ${result.files_changed} file(s)`);
    previewBox.appendChild(summary);
    if (!result.files.length) {
      previewBox.appendChild(el('div', 'empty', 'No matching files to change.'));
      return;
    }
    for (const file of result.files) {
      const item = el('div', 'replace-preview-file');
      item.appendChild(el('div', 'replace-preview-path', `${relPath(file.path)} · ${file.replacements} match(es)`));
      const before = el('pre', 'replace-preview-before');
      before.textContent = file.before || '(empty matching line)';
      const after = el('pre', 'replace-preview-after');
      after.textContent = file.after || '(replacement result is empty)';
      item.append(el('div', 'replace-preview-label', 'Before'), before, el('div', 'replace-preview-label', 'After'), after);
      previewBox.appendChild(item);
    }
    if (result.truncated) previewBox.appendChild(el('div', 'replace-preview-note', 'Preview limited to the first 200 matching files. The apply action will process the full project.'));
    const actions = el('div', 'replace-preview-actions');
    const cancel = el('button', '', 'Cancel');
    cancel.onclick = clearReplacePreview;
    const apply = el('button', 'primary', 'Apply replacement');
    apply.onclick = applyReplacement;
    actions.append(cancel, apply);
    previewBox.appendChild(actions);
  } catch (e) {
    previewBox.replaceChildren(el('div', 'empty', `Preview failed: ${String(e)}`));
  }
}
async function applyReplacement() {
  if (!pendingReplace || !S.root) return;
  const plan = pendingReplace;
  if (plan.query !== $('#sq').value || plan.replacement !== $('#srq').value || plan.caseSensitive !== sOpt.c || plan.useRegex !== sOpt.r) {
    clearReplacePreview();
    return toast('Search settings changed. Create a new preview first.', 'err');
  }
  // Save open buffers first so the on-disk replacement never silently loses editor changes.
  for (const t of S.tabs) if (t.path && isDirty(t) && !(await saveTab(t))) return;
  const confirm = await askChoice(`Apply ${plan.result.replacements} replacement(s) across ${plan.result.files_changed} file(s)?`, ['Cancel', 'Apply changes']);
  if (confirm !== 1) return;
  try {
    const result = await invoke('replace_in_files', {
      root: S.root, query: plan.query, replacement: plan.replacement,
      caseSensitive: plan.caseSensitive, useRegex: plan.useRegex,
    });
    for (const t of S.tabs) {
      if (!t.path || !pathMatchesPrefix(t.path, S.root, S.os === 'windows')) continue;
      try {
        const content = await invoke('read_file', { path: t.path });
        const st = editor.makeState(content, t.path);
        t.state = st;
        t.clean = st.doc;
        if (t === S.active) editor.setState(st);
        if (S.lsp && lspVersions.has(t.path)) {
          const version = (lspVersions.get(t.path) || 1) + 1;
          lspVersions.set(t.path, version);
          await S.lsp.changeDocument(t.path, content, version).catch((e) => console.warn('LSP sync after replace failed:', e));
        }
      } catch { /* file may have been removed externally */ }
    }
    renderTabs();
    S.files = null;
    clearReplacePreview();
    await tree.refresh();
    await refreshGit();
    await runSearch();
    toast(`Replaced ${result.replacements} match(es) in ${result.files_changed} file(s)`);
  } catch (e) { toast(`Replace failed: ${e}`, 'err'); }
}
$('#sr-all').onclick = previewReplace;
$('#sq').addEventListener('input', clearReplacePreview);
$('#srq').addEventListener('input', clearReplacePreview);


function showView(v) {
  S.view = v;
  app.classList.remove('no-side');
  for (const b of document.querySelectorAll('.abtn[data-view]')) b.classList.toggle('active', b.dataset.view === v);
  $('#view-explorer').style.display = v === 'explorer' ? 'flex' : 'none';
  $('#view-search').style.display = v === 'search' ? 'flex' : 'none';
  $('#view-git').style.display = v === 'source-control' ? 'flex' : 'none';
  $('#view-packages').style.display = v === 'packages' ? 'flex' : 'none';
  $('#view-problems').style.display = v === 'problems' ? 'flex' : 'none';
  if (v === 'search') { $('#sq').focus(); $('#sq').select(); }
  if (v === 'source-control') refreshGit();
  if (v === 'packages') $('#pkg-name').focus();
  if (v === 'problems') renderProblems();
  fitSoon();
}
for (const b of document.querySelectorAll('.abtn[data-view]')) {
  b.onclick = () => {
    if (S.view === b.dataset.view && !app.classList.contains('no-side')) toggleSidebar();
    else showView(b.dataset.view);
  };
}
function toggleSidebar() {
  const closed = app.classList.toggle('no-side');
  for (const b of document.querySelectorAll('.abtn[data-view]')) {
    b.classList.toggle('active', !closed && b.dataset.view === S.view);
    b.setAttribute('aria-pressed', String(!closed && b.dataset.view === S.view));
  }
  requestAnimationFrame(() => { fitSoon(); saveSessionSoon(); });
}

// ───────────── source control (Git) ─────────────
function gitRelativePath(path) {
  return String(path || '').replace(/\\/g, '/');
}
function gitStatusLabel(file) {
  if (file.untracked) return 'U';
  if (file.index_status === 'D' || file.worktree_status === 'D') return 'D';
  if (file.index_status === 'A' || file.worktree_status === 'A') return 'A';
  if (file.index_status === 'R' || file.worktree_status === 'R') return 'R';
  if (file.index_status !== ' ' || file.worktree_status !== ' ') return 'M';
  return 'M';
}
async function refreshGit() {
  const list = $('#git-files');
  const hint = $('#git-root-hint');
  const commitBox = $('#git-commit-box');
  if (!S.root) {
    hint.textContent = 'Open a project folder to view Git changes.';
    commitBox.hidden = true;
    list.innerHTML = '<div class="empty">No project folder open.</div>';
    S.gitFiles = [];
    return;
  }
  hint.textContent = `Repository · ${basename(S.root)}`;
  try {
    S.gitFiles = await invoke('git_status', { root: S.root });
    commitBox.hidden = false;
    renderGitFiles();
  } catch (e) {
    S.gitFiles = [];
    commitBox.hidden = true;
    list.innerHTML = `<div class="empty">${esc(e)}<br><br>Install Git and initialize or open a Git repository to use Source Control.</div>`;
  }
}
function renderGitFiles() {
  const list = $('#git-files');
  const files = S.gitFiles || [];
  if (!files.length) {
    list.innerHTML = '<div class="git-clean">✓ Working tree clean</div>';
    return;
  }
  const staged = files.filter((f) => f.staged && !f.untracked);
  const changes = files.filter((f) => !f.staged || f.untracked || f.worktree_status !== ' ');
  list.innerHTML = '';
  for (const [label, group, isStaged] of [['Staged Changes', staged, true], ['Changes', changes, false]]) {
    if (!group.length) continue;
    const head = el('div', 'git-group-head', `${esc(label)} <span>${group.length}</span>`);
    list.appendChild(head);
    for (const file of group) {
      const row = el('div', 'git-row');
      const status = gitStatusLabel(file);
      row.innerHTML = `<span class="git-status ${status.toLowerCase()}">${esc(status)}</span><span class="git-path" title="${esc(file.path)}">${esc(file.path)}</span><button class="git-action" title="${isStaged ? 'Unstage' : 'Stage'} file">${isStaged ? '−' : '+'}</button>`;
      row.querySelector('.git-path').onclick = () => showGitDiff(file, isStaged);
      row.querySelector('.git-status').title = `Index: ${file.index_status}, Working tree: ${file.worktree_status}`;
      row.querySelector('.git-action').onclick = async (e) => {
        e.stopPropagation();
        try {
          await invoke(isStaged ? 'git_unstage' : 'git_stage', { root: S.root, path: gitRelativePath(file.path) });
          await refreshGit();
        } catch (err) { toast(`Git action failed: ${err}`, 'err'); }
      };
      row.ondblclick = () => openFile(joinPath(S.root, file.path, S.os));
      list.appendChild(row);
    }
  }
}
async function showGitDiff(file, staged) {
  const box = $('#git-diff');
  box.innerHTML = '<div class="empty">Loading diff…</div>';
  try {
    let diff = await invoke('git_diff', { root: S.root, path: gitRelativePath(file.path), staged });
    if (!diff.trim() && file.untracked) {
      try {
        const content = await invoke('read_file', { path: joinPath(S.root, file.path, S.os) });
        diff = `New file: ${file.path}\n\n${content.split('\n').map((line) => `+${line}`).join('\n')}\n`;
      } catch {
        diff = `Untracked file: ${file.path}\n\nStage this file to include it in the next commit.\n`;
      }
    }
    if (!diff.trim()) diff = 'No textual diff available for this file.';
    const pre = el('pre', 'git-diff-text');
    pre.textContent = diff;
    box.replaceChildren(pre);
    for (const line of pre.textContent.split('\n')) {
      // Color the lines with lightweight classes, without interpreting Git output as HTML.
    }
    pre.innerHTML = diff.split('\n').map((line) => {
      const cls = line.startsWith('+') && !line.startsWith('+++') ? 'add' : line.startsWith('-') && !line.startsWith('---') ? 'del' : line.startsWith('@@') ? 'hunk' : '';
      return `<span class="${cls}">${esc(line) || ' '}</span>`;
    }).join('\n');
  } catch (e) { box.innerHTML = `<div class="empty">${esc(e)}</div>`; }
}
$('#git-refresh').onclick = refreshGit;
$('#git-commit').onclick = async () => {
  if (!S.root) return;
  const message = $('#git-message').value.trim();
  if (!message) return toast('Enter a commit message first', 'err');
  try {
    const output = await invoke('git_commit', { root: S.root, message });
    $('#git-message').value = '';
    toast(output.split('\n').find(Boolean) || 'Commit created');
    await refreshGit();
  } catch (e) { toast(`Commit failed: ${e}`, 'err'); }
};

// ───────────── terminal panel ─────────────
function showPanel(on) {
  const show = on == null ? app.classList.contains('panel-hidden') : on;
  debugMode = false;
  if (debugView) debugView.hidden = true;
  $('#pbody').style.display = '';
  app.classList.toggle('panel-hidden', !show);
  if (show) {
    if (!hasTerminals()) newTerminal(S.root);
    else { fitSoon(); focusActive(); }
  } else editor.focus();
  saveSessionSoon();
}
let fitRaf = 0;
function fitSoon() { cancelAnimationFrame(fitRaf); fitRaf = requestAnimationFrame(fitActive); }

// ───────────── Python debugger UI ─────────────
function ensureDebugView() {
  if (debugView) return debugView;
  debugView = document.createElement('section');
  debugView.id = 'debugger-view';
  debugView.hidden = true;
  debugView.innerHTML = `
    <div class="debug-toolbar">
      <span id="debug-state" class="debug-state">Idle</span>
      <button id="debug-start" class="primary">▶ Start Debugging</button>
      <button id="debug-breakpoint" title="Toggle breakpoint on current line">● Breakpoint</button>
      <button id="debug-continue" title="Continue (F5)" disabled>▶ Continue</button>
      <button id="debug-over" title="Step over" disabled>↷ Over</button>
      <button id="debug-into" title="Step into" disabled>↓ Into</button>
      <button id="debug-out" title="Step out" disabled>↑ Out</button>
      <button id="debug-pause" title="Pause execution" disabled>Ⅱ Pause</button>
      <button id="debug-stop" title="Stop debugging" disabled>■ Stop</button>
    </div>
    <div class="debug-content">
      <div class="debug-column"><div class="debug-heading">BREAKPOINTS</div><div id="debug-breakpoints" class="debug-list"><div class="debug-empty">No breakpoints. Open a Python file and toggle one.</div></div></div>
      <div class="debug-column"><div class="debug-heading">CALL STACK</div><div id="debug-stack" class="debug-list"><div class="debug-empty">Start debugging to inspect frames.</div></div></div>
      <div class="debug-column"><div class="debug-heading">VARIABLES</div><div id="debug-variables" class="debug-list"><div class="debug-empty">Variables appear when execution pauses.</div></div></div>
      <div class="debug-column debug-output-column"><div class="debug-heading">DEBUG CONSOLE</div><pre id="debug-output" class="debug-output"></pre></div>
    </div>`;
  $('#panel').appendChild(debugView);
  $('#debug-start').onclick = startPythonDebug;
  $('#debug-breakpoint').onclick = toggleCurrentBreakpoint;
  $('#debug-continue').onclick = () => debugAction(() => debugWorkflow?.continue());
  $('#debug-over').onclick = () => debugAction(() => debugWorkflow?.stepOver());
  $('#debug-into').onclick = () => debugAction(() => debugWorkflow?.stepInto());
  $('#debug-out').onclick = () => debugAction(() => debugWorkflow?.stepOut());
  $('#debug-pause').onclick = pausePythonDebug;
  $('#debug-stop').onclick = stopPythonDebug;
  renderDebugBreakpoints();
  return debugView;
}

function openDebuggerPanel() {
  ensureDebugView();
  debugMode = true;
  app.classList.remove('panel-hidden');
  $('#pbody').style.display = 'none';
  debugView.hidden = false;
  $('#debug-state').textContent = debugWorkflow?.state || 'Idle';
  saveSessionSoon();
}

function setDebugState(state, detail = '') {
  const label = $('#debug-state');
  if (label) label.textContent = detail ? `${state}: ${detail}` : state;
  const running = ['running', 'launching', 'configuring', 'initializing', 'initialized'].includes(state);
  const stopped = state === 'stopped';
  const active = !!dapClient && state !== 'idle';
  for (const id of ['debug-continue', 'debug-over', 'debug-into', 'debug-out']) $(`#${id}`).disabled = !stopped;
  $('#debug-pause').disabled = !running;
  $('#debug-stop').disabled = !active;
  $('#debug-start').disabled = debugBusy || active;
  $('#debug-breakpoint').disabled = debugBusy;
  if (stopped) refreshDebugInspection().catch((error) => appendDebugOutput(`Inspection failed: ${error.message}\n`));
  if (['terminated', 'exited'].includes(state)) {
    $('#debug-stack').innerHTML = '<div class="debug-empty">Program has finished.</div>';
    $('#debug-variables').innerHTML = '<div class="debug-empty">No paused variables.</div>';
  }
}

function appendDebugOutput(text) {
  const output = $('#debug-output');
  if (!output) return;
  output.textContent = (output.textContent + String(text)).slice(-30000);
  output.scrollTop = output.scrollHeight;
}

function renderDebugBreakpoints() {
  const box = $('#debug-breakpoints');
  if (!box) return;
  const entries = [...debugBreakpoints.entries()].filter(([, lines]) => lines.size);
  if (!entries.length) { box.innerHTML = '<div class="debug-empty">No breakpoints set.</div>'; return; }
  box.innerHTML = '';
  for (const [path, lines] of entries) {
    for (const line of [...lines].sort((a, b) => a - b)) {
      const row = document.createElement('button');
      row.className = 'debug-item'; row.textContent = `● ${basename(path)} : ${line}`; row.title = path;
      row.onclick = async () => { await openFile(path, { line, col: 1 }); };
      box.appendChild(row);
    }
  }
}

async function toggleCurrentBreakpoint() {
  const tab = S.active;
  if (!tab || !tab.path || !tab.name.toLowerCase().endsWith('.py')) return toast('Open and save a Python (.py) file first.', 'err');
  const line = editor.view.state.doc.lineAt(editor.view.state.selection.main.head).number;
  const lines = debugBreakpoints.get(tab.path) || new Set();
  if (lines.has(line)) lines.delete(line); else lines.add(line);
  if (lines.size) debugBreakpoints.set(tab.path, lines); else debugBreakpoints.delete(tab.path);
  renderDebugBreakpoints();
  if (debugWorkflow && ['running', 'stopped', 'configuring'].includes(debugWorkflow.state)) {
    try { await debugWorkflow.setBreakpoints(tab.path, [...(debugBreakpoints.get(tab.path) || [])]); }
    catch (error) { appendDebugOutput(`Could not update breakpoints: ${error.message}\n`); }
  }
}

async function refreshDebugInspection() {
  if (!debugWorkflow || debugWorkflow.state !== 'stopped') return;
  const stackBox = $('#debug-stack'); const varsBox = $('#debug-variables');
  const frames = await debugWorkflow.stackTrace();
  stackBox.innerHTML = '';
  if (!frames.length) stackBox.innerHTML = '<div class="debug-empty">No stack frames reported.</div>';
  for (const frame of frames) {
    const button = document.createElement('button'); button.className = 'debug-item';
    const source = frame.source?.path || frame.source?.name || 'unknown source';
    button.textContent = `${frame.name || '(anonymous)'} — ${basename(source)}:${frame.line || 1}`;
    button.title = source;
    button.onclick = async () => {
      if (frame.source?.path) await openFile(frame.source.path, { line: frame.line || 1, col: frame.column || 1 });
    };
    stackBox.appendChild(button);
  }
  varsBox.innerHTML = '';
  const top = frames[0];
  if (!top) { varsBox.innerHTML = '<div class="debug-empty">No variables available.</div>'; return; }
  const scopes = await debugWorkflow.scopes(top.id);
  const scope = scopes.find((item) => item.expensive === false) || scopes[0];
  if (!scope) { varsBox.innerHTML = '<div class="debug-empty">No scopes available.</div>'; return; }
  const variables = await debugWorkflow.variables(scope.variablesReference);
  if (!variables.length) { varsBox.innerHTML = '<div class="debug-empty">No variables in this scope.</div>'; return; }
  for (const variable of variables.slice(0, 200)) {
    const row = document.createElement('div'); row.className = 'debug-variable';
    const name = document.createElement('span'); name.className = 'debug-var-name'; name.textContent = variable.name || '(unnamed)';
    const value = document.createElement('span'); value.className = 'debug-var-value'; value.textContent = variable.value ?? ''; value.title = variable.type || '';
    row.append(name, value); varsBox.appendChild(row);
  }
}

async function debugAction(action) {
  try { if (typeof action === 'function') await action(); }
  catch (error) { appendDebugOutput(`Debugger error: ${error.message || error}\n`); toast(`Debugger: ${error.message || error}`, 'err'); }
}

async function pausePythonDebug() {
  await debugAction(async () => {
    if (!debugWorkflow) return;
    const threads = await debugWorkflow.threads();
    if (!threads.length) throw new Error('The adapter has not reported a debuggable thread yet');
    await debugWorkflow.pause(threads[0].id);
  });
}

async function startPythonDebug() {
  if (debugBusy || dapClient) return;
  let tab = S.active;
  if (!tab) return toast('Open a Python file before starting the debugger.', 'err');
  if (!tab.name.toLowerCase().endsWith('.py')) return toast('The integrated debugger currently supports Python files only.', 'err');
  if (!S.root) return toast('Open a project folder before debugging.', 'err');
  if (!tab.path || isDirty(tab)) { if (!(await saveTab(tab))) return; }
  tab = S.active;
  if (!tab?.path || !pathWithinRoot(tab.path, S.root)) return toast('Save the Python file inside the opened project folder before debugging.', 'err');
  const consent = await askChoice(`LiteCode will launch Python code from:\n${tab.path}\n\nOnly continue if you trust this file. The program will run on your computer.`, ['Run and Debug', 'Cancel'], 1);
  if (consent !== 0) return;
  debugBusy = true;
  openDebuggerPanel();
  $('#debug-output').textContent = '';
  appendDebugOutput(`Starting Python debugger for ${tab.path}\n`);
  setDebugState('starting');
  try {
    dapClient = new DapClient({ root: S.root, onStatus: (message, kind) => { appendDebugOutput(`${message}\n`); if (kind === 'err') toast(message, 'err'); } });
    await dapClient.start();
    debugWorkflow = new PythonDebugWorkflow(dapClient, {
      onState: ({ state, detail }) => setDebugState(state, detail),
      onOutput: ({ output }) => appendDebugOutput(output),
    });
    await debugWorkflow.initialize();
    await debugWorkflow.launch({ program: tab.path, cwd: dirname(tab.path), stopOnEntry: true });
    await debugWorkflow.waitForInitializedEvent();
    for (const [path, lines] of debugBreakpoints) if (pathWithinRoot(path, S.root)) await debugWorkflow.setBreakpoints(path, [...lines]);
    await debugWorkflow.configurationDone();
    appendDebugOutput('Debug session started. Execution will stop at configured breakpoints.\n');
  } catch (error) {
    appendDebugOutput(`Failed to start debugging: ${error.message || error}\n`);
    toast(`Could not start debugger: ${error.message || error}`, 'err');
    await stopPythonDebug(true);
  } finally {
    debugBusy = false;
    if (debugWorkflow) setDebugState(debugWorkflow.state);
  }
}

async function stopPythonDebug(silent = false) {
  const workflow = debugWorkflow; const client = dapClient;
  debugWorkflow = null; dapClient = null;
  try { if (workflow) await workflow.stop(); }
  catch (error) { appendDebugOutput(`Debug stop warning: ${error.message || error}\n`); }
  try { if (client) await client.close(); }
  catch (error) { appendDebugOutput(`Adapter stop warning: ${error.message || error}\n`); }
  setDebugState('idle');
  if (!silent) appendDebugOutput('Debug session stopped.\n');
}

$('#btn-debug').onclick = () => { openDebuggerPanel(); if (!dapClient) $('#debug-start').focus(); };

// ───────────── run + live server ─────────────
async function runCurrent() {
  const t = S.active;
  if (!t) return toast('Open a file to run it');
  if (!t.path) { if (!(await saveTab(t))) return; }
  else if (isDirty(t)) { if (!(await saveTab(t))) return; }
  const r = buildRun(t.path, S.os, settings.pythonCmd);
  if (!r) return toast(`No runner for .${t.name.split('.').pop()} files`, 'err');
  if (r.live) return goLive(true);
  showPanel(true);
  await runInTerminal(r.cmd, dirname(t.path));
}

async function runConfiguredTask() {
  if (!S.root) return toast('Open a project folder before running a task.', 'err');
  const configPath = joinPath(S.root, '.litecode/tasks.json', S.os);
  let raw;
  try { raw = await invoke('read_file', { path: configPath }); }
  catch { return toast('No .litecode/tasks.json found in this project.', 'err'); }
  let tasks;
  try { tasks = parseTaskConfig(raw); }
  catch (error) { return toast(`Invalid task config: ${error.message}`, 'err'); }
  if (!tasks.length) return toast('No valid tasks found in .litecode/tasks.json.', 'err');
  const choice = await askChoice('Choose a project task. Review the command carefully before confirming.', [...tasks.map((t) => t.label), 'Cancel']);
  if (choice < 0 || choice >= tasks.length) return;
  const task = tasks[choice];
  const valid = validateTask(task, S.root);
  if (!valid.ok) return toast(valid.error, 'err');
  const confirm = await askChoice(`Run this project-defined command?

${task.command}

Working directory: ${valid.cwd}`, ['Cancel', 'Run task'], 0);
  if (confirm !== 1) return;
  showPanel(true);
  try { await runInTerminal(task.command, valid.cwd); }
  catch (error) { toast(`Could not start task: ${String(error)}`, 'err'); }
}

function previewUrl() {
  if (!S.live) return '';
  let rel = '/';
  const a = S.active;
  if (a && a.path && S.root && /\.html?$/i.test(a.path) && a.path.startsWith(S.root)) {
    rel = a.path.slice(S.root.length).replace(/\\/g, '/');
    if (!rel.startsWith('/')) rel = '/' + rel;
  }
  return `http://127.0.0.1:${S.live.port}${encodeURI(rel)}`;
}

async function saveDirtyFilesForLive() {
  for (const t of S.tabs) {
    if (t.path && isDirty(t) && S.root && (t.path === S.root || t.path.startsWith(S.root + '/') || t.path.startsWith(S.root + '\\'))) {
      if (!(await saveTab(t))) return false;
    }
  }
  return true;
}

async function startLive() {
  if (!S.root) { toast('Open a folder first — the Live Server serves that folder', 'err'); return false; }
  if (!(await saveDirtyFilesForLive())) return false;
  try { S.live = { port: await invoke('live_start', { root: S.root }) }; }
  catch (e) { toast(`Live Server failed: ${e}`, 'err'); return false; }
  return true;
}
async function stopLive() {
  await invoke('live_stop');
  S.live = null;
  app.classList.remove('preview-on');
  $('#pv-frame').src = 'about:blank';
  updateStatus();
}
function showPreview() {
  if (!S.live) return;
  const url = previewUrl();
  $('#pv-url').value = url;
  $('#pv-frame').src = url;
  app.classList.add('preview-on');
}
async function goLive(navigate = false) {
  if (!S.live && !(await startLive())) return;
  if (navigate || !app.classList.contains('preview-on')) showPreview();
  updateStatus();
}
async function toggleLive() {
  if (S.live) await stopLive();
  else await goLive(true);
}
function reloadPreview() {
  const frame = $('#pv-frame');
  const value = $('#pv-url').value.trim();
  if (!value) return showPreview();
  const fresh = new URL(value, location.href);
  fresh.searchParams.set('__lc_reload', String(Date.now()));
  frame.src = fresh.toString();
}
$('#pv-reload').onclick = async () => {
  if (!(await saveDirtyFilesForLive())) return;
  reloadPreview();
};
$('#pv-current').onclick = async () => { if (!(await saveDirtyFilesForLive())) return; showPreview(); };
$('#pv-close').onclick = () => app.classList.remove('preview-on');
$('#pv-ext').onclick = () => invoke('open_external', { url: $('#pv-url').value }).catch((e) => toast(String(e), 'err'));

// ───────────── settings + theme ─────────────
function applySettings() {
  document.documentElement.dataset.theme = settings.theme;
  document.documentElement.style.setProperty('--fs', settings.fontSize + 'px');
  document.documentElement.style.setProperty('--cursor-motion', settings.smoothCursor ? '65ms' : '0ms');
  editor.reconfigure();
  restyle();
  updateStatus();
  saveSettings();
}
const setNumber = async (key, label, min, max) => {
  const v = await askInput(label, String(settings[key]));
  const n = parseInt(v, 10);
  if (!Number.isFinite(n) || n < min || n > max) return v && toast(`Enter a number between ${min} and ${max}`, 'err');
  settings[key] = n;
  applySettings();
};
const toggleTheme = () => { settings.theme = settings.theme === 'dark' ? 'light' : 'dark'; applySettings(); };
const zoom = (d) => { settings.fontSize = Math.min(32, Math.max(9, settings.fontSize + d)); applySettings(); };

// A real, discoverable preferences surface. Keep the command palette as a fast path,
// but don't force users to memorize commands for everyday editor settings.
function openSettings(section = 'editor') {
  const overlay = $('#settings-overlay');
  $('#setting-font-size').value = String(settings.fontSize);
  $('#setting-font-output').value = `${settings.fontSize}px`;
  $('#setting-tab-size').value = String(settings.tabSize);
  $('#setting-wrap').checked = !!settings.wordWrap;
  $('#setting-autosave').checked = !!settings.autoSave;
  $('#setting-cursor-blink').checked = settings.cursorBlink !== false;
  $('#setting-smooth-cursor').checked = settings.smoothCursor !== false;
  $('#setting-theme').value = settings.theme;
  $('#setting-python').value = settings.pythonCmd || '';
  const selectSection = (name) => {
    document.querySelectorAll('[data-settings-tab]').forEach((b) => b.classList.toggle('selected', b.dataset.settingsTab === name));
    document.querySelectorAll('[data-settings-page]').forEach((p) => { p.hidden = p.dataset.settingsPage !== name; });
  };
  selectSection(section);
  overlay.classList.add('open');
  $('#setting-font-size').focus();
}
function closeSettings() { $('#settings-overlay').classList.remove('open'); if (S.active) editor.focus(); }
$('#btn-settings').onclick = () => openSettings();
$('#settings-close').onclick = closeSettings;
$('#settings-done').onclick = closeSettings;
$('#settings-overlay').addEventListener('mousedown', (e) => { if (e.target === $('#settings-overlay')) closeSettings(); });
document.querySelectorAll('[data-settings-tab]').forEach((b) => b.onclick = () => {
  document.querySelectorAll('[data-settings-tab]').forEach((x) => x.classList.toggle('selected', x === b));
  document.querySelectorAll('[data-settings-page]').forEach((p) => { p.hidden = p.dataset.settingsPage !== b.dataset.settingsTab; });
});
$('#setting-font-size').oninput = (e) => { settings.fontSize = Number(e.target.value); $('#setting-font-output').value = `${settings.fontSize}px`; applySettings(); };
$('#setting-tab-size').onchange = (e) => { settings.tabSize = Number(e.target.value); applySettings(); };
$('#setting-wrap').onchange = (e) => { settings.wordWrap = e.target.checked; applySettings(); };
$('#setting-autosave').onchange = (e) => { settings.autoSave = e.target.checked; applySettings(); toast(`Auto save ${settings.autoSave ? 'on' : 'off'}`); };
$('#setting-cursor-blink').onchange = (e) => { settings.cursorBlink = e.target.checked; applySettings(); };
$('#setting-smooth-cursor').onchange = (e) => { settings.smoothCursor = e.target.checked; applySettings(); };
$('#setting-theme').onchange = (e) => { settings.theme = e.target.value; applySettings(); };
$('#setting-theme-toggle').onclick = toggleTheme;
$('#setting-python').onchange = (e) => { settings.pythonCmd = e.target.value.trim(); applySettings(); };

// ───────────── package management ─────────────
async function installPackage() {
  if (!S.root) return toast('Open a project folder before installing packages.', 'err');
  const manager = $('#pkg-manager').value;
  let command;
  try { command = buildPackageCommand(manager, $('#pkg-name').value); }
  catch (e) { return toast(String(e.message || e), 'err'); }
  const ok = await askChoice(`Run this command in ${basename(S.root)}?\n\n${command}`, ['Cancel', 'Run install'], 0);
  if (ok !== 1) return;
  showPanel(true);
  try { await runInTerminal(command, S.root); toast(`Started ${manager} install`); }
  catch (e) { const message = String(e?.message || e); toast(`Could not start package installation: ${message}${isLikelyNetworkFailure(message) || navigator.onLine === false ? '. You may be offline; local editing and other local tools remain available.' : ''}`, 'err'); }
}

async function installProjectDependencies() {
  if (!S.root) return toast('Open a project folder before installing dependencies.', 'err');
  const manager = $('#pkg-manager').value;
  let command;
  try { command = buildDependencyCommand(manager); }
  catch (e) { return toast(String(e.message || e), 'err'); }
  const ok = await askChoice(`Run project dependency installation in ${basename(S.root)}?\n\n${command}`, ['Cancel', 'Run install'], 0);
  if (ok !== 1) return;
  showPanel(true);
  try { await runInTerminal(command, S.root); toast(`Started ${manager} dependency installation`); }
  catch (e) { const message = String(e?.message || e); toast(`Could not start dependency installation: ${message}${isLikelyNetworkFailure(message) || navigator.onLine === false ? '. You may be offline; local editing and other local tools remain available.' : ''}`, 'err'); }
}
$('#pkg-install').onclick = installPackage;
$('#pkg-install-project').onclick = installProjectDependencies;
$('#pkg-name').addEventListener('keydown', (e) => { if (e.key === 'Enter') installPackage(); });
$('#pkg-clear').onclick = () => { $('#pkg-name').value = ''; $('#pkg-name').focus(); };

async function startLanguageServer() {
  if (!S.root) return toast('Open a project folder first.', 'err');
  if (S.lsp) { await S.lsp.dispose(); S.lsp = null; lspVersions.clear(); lspDiagnostics.clear(); editor.setDiagnostics([]); }
  const client = new LspClient({
    root: S.root,
    onStatus: (message, kind) => { if (message) toast(message, kind === 'err' ? 'err' : ''); },
    onDiagnostics: (uri, diagnostics, language) => {
      const path = pathFromFileUri(uri);
      if (!path) return;
      const key = S.os === 'windows' ? path.toLowerCase() : path;
      // Match paths case-insensitively on Windows while preserving the tab's exact path.
      const tab = S.tabs.find((item) => item.path && (S.os === 'windows' ? item.path.toLowerCase() === key : item.path === path));
      const exactPath = tab?.path || path;
      const list = Array.isArray(diagnostics) ? diagnostics : [];
      lspDiagnostics.set(exactPath, list);
      if (S.active?.path === exactPath) editor.setDiagnostics(list);
      renderProblems();
      const count = list.filter((d) => d.severity === 1).length;
      const warnings = list.filter((d) => d.severity === 2).length;
      const file = basename(exactPath) || language;
      if (count || warnings) toast(`${file}: ${count} error(s), ${warnings} warning(s)`, count ? 'err' : '');
    },
  });
  S.lsp = client;
  try {
    const path = S.active?.path || '';
    const ext = path.split('.').pop().toLowerCase();
    const language = ext === 'py' ? 'python' : ['js','mjs','cjs','jsx','ts','tsx'].includes(ext) ? (['ts','tsx'].includes(ext) ? 'typescript' : 'javascript') : null;
    if (!language) return toast('Open a Python, JavaScript, or TypeScript file, then start the language server.', 'err');
    await client.start(language);
    for (const tab of S.tabs) {
      if (tab.path && pathWithinRoot(tab.path, S.root)) {
        const text = stateOf(tab).doc.toString();
        const v = lspVersions.get(tab.path) || 1;
        lspVersions.set(tab.path, v);
        await client.openDocument(tab.path, text, v);
      }
    }
    toast('Language server is connected. Diagnostics will appear as the server reports them.');
  } catch (error) {
    await client.dispose();
    if (S.lsp === client) S.lsp = null;
    const detail = String(error?.message || error);
    const offlineNote = navigator.onLine === false
      ? ' You appear to be offline; LiteCode editing, saving, terminal, Git, and local run features are still available. Language servers must already be installed locally.'
      : ' Language servers must be installed locally (pylsp for Python or typescript-language-server for JS/TS); installing them may require internet.';
    toast(`Could not start language server: ${detail}.${offlineNote}`, 'err');
  }
}

function pathFromFileUri(uri) {
  if (typeof uri !== 'string' || !uri.startsWith('file://')) return null;
  try {
    let path = decodeURIComponent(uri.slice('file://'.length));
    if (S.os === 'windows' && /^\/[A-Za-z]:\//.test(path)) path = path.slice(1);
    return path.replace(/\//g, S.os === 'windows' ? '\\' : '/');
  } catch { return null; }
}

async function showLspHover() {
  if (!S.lsp || !S.active?.path) return toast('Start a language server and open a supported file first.', 'err');
  try {
    const state = editor.view.state;
    const result = await S.lsp.hover(S.active.path, state, state.selection.main.head);
    if (!result) return toast('No hover information for this position.');
    await askChoice(`Language Server: Hover information\n\n${result.slice(0, 3000)}`, ['Close'], -1);
  } catch (error) { toast(`Hover failed: ${error.message || error}`, 'err'); }
}

async function goToDefinition() {
  if (!S.lsp || !S.active?.path) return toast('Start a language server and open a supported file first.', 'err');
  try {
    const state = editor.view.state;
    const target = await S.lsp.definition(S.active.path, state, state.selection.main.head);
    if (!target) return toast('No definition found for this position.');
    const path = pathFromFileUri(target.uri);
    if (!path) return toast('The language server returned an unsupported file URI.', 'err');
    await openFile(path, { line: target.line, col: target.col });
  } catch (error) { toast(`Go to Definition failed: ${error.message || error}`, 'err'); }
}


async function formatDocumentWithLsp() {
  const tab = S.active;
  if (!tab?.path) return toast('Open a saved file before formatting.', 'err');
  if (!S.lsp) return toast('Start a language server first. Formatting uses a locally installed language server.', 'err');
  try {
    const state = editor.view.state;
    const edits = await S.lsp.formatDocument(tab.path, state, { tabSize: settings.tabSize || 4, insertSpaces: true });
    if (!edits.length) return toast('The language server returned no formatting changes.');
    const changes = getCurrentTextEdits(edits, state.doc);
    if (!changes) return toast('Formatting returned unsafe or unsupported edits; no changes were applied.', 'err');
    editor.view.dispatch({ changes });
    toast(`Formatted document (${changes.length} edit${changes.length === 1 ? '' : 's'}).`);
  } catch (error) {
    const message = String(error?.message || error);
    if (/method not found|method not supported|unsupported/i.test(message)) {
      toast('This language server does not support document formatting. Install/configure a formatter for it.', 'err');
    } else {
      toast(`Format Document failed: ${message}`, 'err');
    }
  }
}

async function requestCodeActions() {
  const tab = S.active;
  if (!S.lsp || !tab?.path) return toast('Start a language server and open a supported saved file first.', 'err');
  try {
    const state = editor.view.state;
    const pos = state.selection.main.head;
    const diagnostics = lspDiagnostics.get(tab.path) || [];
    const line = state.doc.lineAt(pos).number - 1;
    const nearby = diagnostics.filter((d) => d?.range?.start && d?.range?.end && line >= d.range.start.line && line <= d.range.end.line);
    const actions = await S.lsp.codeActions(tab.path, state, pos, nearby);
    if (!actions.length) return toast('No Quick Fixes or Code Actions are available here.');
    const labels = actions.map((action) => String(action.title || action.command?.title || 'Apply Code Action').slice(0, 120));
    const chosen = await askChoice(`Code Actions at cursor\n\n${labels.map((label, i) => `${i + 1}. ${label}`).join('\n')}`, [...labels, 'Cancel'], labels.length);
    if (chosen < 0 || chosen >= actions.length) return;
    const action = actions[chosen];
    if (action.edit) {
      const changes = getCurrentDocumentEdits(action.edit, tab.path, state.doc);
      if (!changes) return toast('This action edits other files or uses unsupported edit operations; nothing was changed.', 'err');
      if (changes.length) editor.view.dispatch({ changes });
    }
    if (action.command) await S.lsp.executeCommand(tab.path, action.command);
    if (!action.edit && !action.command) return toast('This action did not include an applicable edit or command.');
    toast(`Applied: ${labels[chosen]}`);
  } catch (error) { toast(`Code Action failed: ${error.message || error}`, 'err'); }
}

async function stopLanguageServer() {
  if (!S.lsp) return toast('No language server is running.');
  await S.lsp.dispose();
  S.lsp = null;
  lspVersions.clear();
  toast('Language server stopped.');
}

function navigateDiagnostic(direction) {
  if (!S.active?.path) return toast('Open a saved file to navigate diagnostics.');
  const diagnostics = lspDiagnostics.get(S.active.path) || [];
  if (!diagnostics.length) return toast('No language-server diagnostics for this file.');
  const current = editor.view.state.selection.main.head;
  const positions = diagnostics.filter((d) => d?.range?.start).map((d) => ({
    pos: editor.view.state.doc.line(Math.min(editor.view.state.doc.lines, Math.max(1, d.range.start.line + 1))).from + Math.max(0, Number(d.range.start.character) || 0),
    line: d.range.start.line + 1,
    col: (Number(d.range.start.character) || 0) + 1,
  })).sort((a, b) => a.pos - b.pos);
  if (!positions.length) return toast('No navigable diagnostics for this file.');
  const next = direction > 0 ? positions.find((item) => item.pos > current) || positions[0] : [...positions].reverse().find((item) => item.pos < current) || positions[positions.length - 1];
  editor.goTo(next.line, next.col);
}

const problemSeverity = (level) => ({ 1: 'Error', 2: 'Warning', 3: 'Information', 4: 'Hint' })[level] || 'Information';
function renderProblems() {
  const list = $('#problems-list');
  if (!list) return;
  const query = $('#problems-query')?.value || '';
  const severity = $('#problems-severity')?.value || 'all';
  const rows = collectProblems(lspDiagnostics, { root: S.root, severity, query });
  const all = collectProblems(lspDiagnostics, { root: S.root });
  const errors = all.filter((item) => item.severity === 1).length;
  const warnings = all.filter((item) => item.severity === 2).length;
  const count = $('#problem-count');
  count.textContent = String(all.length > 99 ? '99+' : all.length);
  count.hidden = all.length === 0;
  count.title = `${errors} error(s), ${warnings} warning(s), ${all.length} total problem(s)`;
  $('#problems-summary').textContent = all.length
    ? `${all.length} problem(s) · ${errors} error(s) · ${warnings} warning(s)${rows.length !== all.length ? ` · ${rows.length} shown` : ''}`
    : (S.lsp ? 'No diagnostics reported yet.' : 'No diagnostics yet. Start a language server for a supported file.');
  list.replaceChildren();
  if (!rows.length) {
    const empty = el('div', 'empty problems-empty', all.length ? 'No problems match the current filters.' : 'Problems from the language server will appear here.');
    list.appendChild(empty);
    return;
  }
  for (const item of rows) {
    const row = el('button', `problem-row problem-severity-${item.severity}`);
    row.type = 'button';
    row.title = `${item.path}:${item.line}:${item.column}\n${item.message}${item.code ? ` (${item.code})` : ''}`;
    const file = basename(item.path);
    const location = `${item.line}:${item.column}`;
    row.innerHTML = `<span class="problem-icon" aria-label="${esc(problemSeverity(item.severity))}">${item.severity === 1 ? '●' : item.severity === 2 ? '▲' : item.severity === 4 ? '◆' : '●'}</span><span class="problem-content"><span class="problem-message">${esc(item.message)}</span><span class="problem-meta">${esc(file)} · ${esc(location)}${item.code ? ` · ${esc(item.code)}` : ''}</span></span>`;
    row.onclick = async () => {
      try {
        if (!S.tabs.some((tab) => tab.path === item.path)) await openFile(item.path, { line: item.line, col: item.column });
        else activate(S.tabs.find((tab) => tab.path === item.path), { line: item.line, col: item.column });
        editor.focus();
      } catch (error) { toast(`Could not open problem location: ${error.message || error}`, 'err'); }
    };
    list.appendChild(row);
  }
}
$('#problems-query').addEventListener('input', renderProblems);
$('#problems-severity').addEventListener('change', renderProblems);
$('#problems-refresh').onclick = renderProblems;

// ───────────── commands + palette ─────────────
const commands = [
  { label: 'File: New File', key: 'Ctrl+N', run: newUntitled },
  { label: 'File: Open File…', key: 'Ctrl+O', run: openFiles },
  { label: 'File: Open Folder…', key: 'Ctrl+Shift+O', run: pickFolder },
  { label: 'File: Save', key: 'Ctrl+S', run: () => S.active && saveTab(S.active) },
  { label: 'File: Save As…', key: 'Ctrl+Shift+S', run: () => S.active && saveTab(S.active, true) },
  { label: 'File: Save All', run: async () => { for (const t of S.tabs) if (isDirty(t)) await saveTab(t); } },
  { label: 'File: Close Tab', key: 'Ctrl+W', run: () => S.active && closeTab(S.active) },
  { label: 'File: Toggle Auto Save', run: () => { settings.autoSave = !settings.autoSave; applySettings(); toast(`Auto save ${settings.autoSave ? 'on' : 'off'}`); } },
  { label: 'Language Server: Start / Restart for Project', run: startLanguageServer },
  { label: 'Language Server: Stop', run: stopLanguageServer },
  { label: 'Language Server: Hover Information', run: showLspHover },
  { label: 'Language Server: Go to Definition', key: 'F12', run: goToDefinition },
  { label: 'Language Server: Quick Fix / Code Actions', key: 'Ctrl+.', run: requestCodeActions },
  { label: 'Format: Format Document', key: 'Shift+Alt+F', run: formatDocumentWithLsp },
  { label: 'Problems: Go to Next Diagnostic', key: 'F8', run: () => navigateDiagnostic(1) },
  { label: 'Problems: Go to Previous Diagnostic', key: 'Shift+F8', run: () => navigateDiagnostic(-1) },
  { label: 'View: Problems', run: () => showView('problems') },
  { label: 'Problems: Clear Filter', run: () => { $('#problems-query').value = ''; $('#problems-severity').value = 'all'; renderProblems(); } },
  { label: 'Run: Run Current File', key: 'F5', run: runCurrent },
  { label: 'Debug: Start / Open Python Debugger', key: 'F6', run: () => { openDebuggerPanel(); if (!dapClient) startPythonDebug(); } },
  { label: 'Debug: Toggle Breakpoint', run: toggleCurrentBreakpoint },
  { label: 'Debug: Stop', run: stopPythonDebug },
  { label: 'Run: Run Task…', run: runConfiguredTask },
  { label: 'Run: Stop', run: stopActive },
  { label: 'Live Server: Start / Stop', key: 'Ctrl+Alt+L', run: toggleLive },
  { label: 'Live Server: Show Current File in Preview', run: () => goLive(true) },
  { label: 'Terminal: Toggle Panel', key: 'Ctrl+`', run: () => showPanel() },
  { label: 'Terminal: New Terminal', key: 'Ctrl+Shift+`', run: () => { showPanel(true); newTerminal(S.root); } },
  { label: 'Terminal: Close Terminal', run: () => closeTerminal() },
  { label: 'View: Toggle Sidebar', key: 'Ctrl+B', run: toggleSidebar },
  { label: 'View: Explorer', key: 'Ctrl+Shift+E', run: () => showView('explorer') },
  { label: 'View: Search in Files', key: 'Ctrl+Shift+F', run: () => showView('search') },
  { label: 'View: Source Control', key: 'Ctrl+Shift+G', run: () => showView('source-control') },
  { label: 'View: Packages & Dependencies', run: () => showView('packages') },
  { label: 'Packages: Install Package…', run: () => installPackage() },
  { label: 'Packages: Install Project Dependencies', run: () => installProjectDependencies() },
  { label: 'Git: Refresh Changes', run: refreshGit },
  { label: 'View: Toggle Light / Dark Theme', run: toggleTheme },
  { label: 'Preferences: Open Settings', key: 'Ctrl+,', run: () => openSettings() },
  { label: 'View: Zoom In', key: 'Ctrl+=', run: () => zoom(1) },
  { label: 'View: Zoom Out', key: 'Ctrl+-', run: () => zoom(-1) },
  { label: 'Preferences: Set Font Size…', run: () => setNumber('fontSize', 'Font size', 9, 32) },
  { label: 'Preferences: Set Tab Size…', run: () => setNumber('tabSize', 'Spaces per tab', 1, 8) },
  { label: 'Preferences: Toggle Word Wrap', run: () => { settings.wordWrap = !settings.wordWrap; applySettings(); } },
  {
    label: 'Preferences: Set Python Command…',
    run: async () => {
      const v = await askInput('Python command', settings.pythonCmd || (S.os === 'windows' ? 'python' : 'python3'), 'For example: python, python3 or py');
      if (v) { settings.pythonCmd = v; applySettings(); }
    },
  },
  { label: 'Go to Line…', key: 'Ctrl+G', run: () => quickOpen(':') },
];

async function quickOpen(initial = '') {
  if (S.root && !S.files) {
    try { S.files = await invoke('list_files', { root: S.root }); } catch { S.files = []; }
  }
  const provider = (q) => {
    if (q.startsWith('>')) {
      return fuzzy(commands, q.slice(1), (c) => c.label).map((c) => ({ label: c.label, detail: c.key || '', run: c.run }));
    }
    if (q.startsWith(':')) {
      const n = parseInt(q.slice(1), 10);
      if (!Number.isFinite(n) || !S.active) return [{ label: 'Type a line number', detail: '', run: () => {} }];
      return [{ label: `Go to line ${n}`, detail: '', run: () => editor.goTo(n) }];
    }
    const list = S.files || S.tabs.filter((t) => t.path).map((t) => t.path);
    return fuzzy(list, q, (f) => f).map((f) => ({
      label: basename(f),
      detail: dirname(f.replace(/\\/g, '/')),
      run: () => openFile(S.files ? joinPath(S.root, f, S.os) : f),
    }));
  };
  openPalette(provider, initial);
}

// ───────────── keyboard ─────────────
// Use the physical key (e.code) for letters so shortcuts also work with an Arabic layout.
function keyOf(e) {
  if (e.code && e.code.startsWith('Key')) return e.code.slice(3).toLowerCase();
  const map = { Backquote: '`', Equal: '=', Minus: '-', NumpadAdd: '=', NumpadSubtract: '-' };
  return map[e.code] || e.key.toLowerCase();
}
addEventListener('keydown', (e) => {
  const ctrl = e.ctrlKey || e.metaKey;
  const k = keyOf(e);
  const inTerm = !!e.target.closest && !!e.target.closest('.xterm');
  if (inTerm && !(e.shiftKey || e.altKey || (/^f\d+$/.test(k)) || k === '`')) return;
  const go = (fn) => { e.preventDefault(); e.stopPropagation(); fn(); };

  if (e.key === 'F5') { if (dapClient && debugMode) return go(() => debugAction(() => debugWorkflow?.continue())); return go(runCurrent); }
  if (e.key === 'F6') return go(() => { openDebuggerPanel(); startPythonDebug(); });
  if (e.key === 'F12') return go(goToDefinition);
  if (ctrl && !e.altKey && e.code === 'Period') return go(requestCodeActions);
  if (e.key === 'F8') return go(() => navigateDiagnostic(e.shiftKey ? -1 : 1));
  if (e.key === 'F1') return go(() => quickOpen('>'));
  if (!ctrl) return;
  if (k === ',' && !e.altKey) return go(() => openSettings());
  if (k === 's') return go(() => S.active && saveTab(S.active, e.shiftKey));
  if (k === 'p') return go(() => quickOpen(e.shiftKey ? '>' : ''));
  if (k === 'n' && !e.shiftKey) return go(newUntitled);
  if (k === 'o') return go(e.shiftKey ? pickFolder : openFiles);
  if (k === 'w') return go(() => S.active && closeTab(S.active));
  if (k === 'b') return go(toggleSidebar);
  if (k === '`') return go(() => (e.shiftKey ? (showPanel(true), newTerminal(S.root)) : showPanel()));
  if (k === 'e' && e.shiftKey) return go(() => showView('explorer'));
  if (k === 'f' && e.shiftKey) return go(() => showView('search'));
  if (k === 'g' && e.shiftKey) return go(() => showView('source-control'));
  if (k === 'l' && e.altKey) return go(toggleLive);
  if (e.key === 'Tab') return go(() => cycleTab(e.shiftKey ? -1 : 1));
  if (k === '=') return go(() => zoom(1));
  if (k === '-') return go(() => zoom(-1));
  if (k === 'g' && !e.altKey) return go(() => quickOpen(':'));
}, true);

addEventListener('contextmenu', (e) => { if (!e.target.closest('.cm-editor, .xterm, input')) e.preventDefault(); });
document.addEventListener('modal-closed', () => { if (S.active) editor.focus(); });

// ───────────── layout (resizers) ─────────────
drag($('#rs'), (e) => { app.style.setProperty('--sw', Math.min(600, Math.max(160, e.clientX - 46)) + 'px'); });
drag($('#hrs'), (e) => {
  const h = innerHeight - e.clientY - 24;
  app.style.setProperty('--ph', Math.min(innerHeight - 160, Math.max(90, h)) + 'px');
});
drag($('#prs'), (e) => {
  const r = $('#work').getBoundingClientRect();
  app.style.setProperty('--pw', Math.min(r.width - 200, Math.max(180, r.right - e.clientX)) + 'px');
});
document.addEventListener('layout-changed', () => { fitSoon(); saveSessionSoon(); });

// ───────────── buttons ─────────────
$('#btn-run').onclick = runCurrent;
$('#btn-live').onclick = toggleLive;
$('#st-live').onclick = toggleLive;
document.addEventListener('keydown', (e) => { if (e.key === 'Escape' && $('#settings-overlay').classList.contains('open')) closeSettings(); });
$('#w-open').onclick = pickFolder;
$('#t-newfile').onclick = () => (S.root ? newFileIn(tree.selectedDir()) : pickFolder());
$('#t-newfolder').onclick = () => (S.root ? newFolderIn(tree.selectedDir()) : pickFolder());
$('#t-refresh').onclick = () => { S.files = null; tree.refresh(); };
$('#p-new').onclick = () => newTerminal(S.root);
$('#p-stop').onclick = stopActive;
$('#p-kill').onclick = () => closeTerminal();
$('#p-hide').onclick = () => showPanel(false);
$('#tabs').addEventListener('dblclick', (e) => { if (e.target === $('#tabs')) newUntitled(); });
async function newFileIn(dir) {
  const name = await askInput('New file', '', 'Name, or folder/name to create folders too');
  if (!name) return;
  const path = joinPath(dir, name, S.os);
  try { await invoke('create_file', { path }); } catch (e) { return toast(String(e), 'err'); }
  S.files = null;
  await tree.refresh();
  openFile(path);
}
async function newFolderIn(dir) {
  const name = await askInput('New folder');
  if (!name) return;
  try { await invoke('create_dir', { path: joinPath(dir, name, S.os) }); } catch (e) { return toast(String(e), 'err'); }
  S.files = null;
  tree.refresh();
}

// ───────────── session ─────────────
function saveSessionSoon() { clearTimeout(sessionTimer); sessionTimer = setTimeout(saveSessionNow, 350); }
function buildSessionSnapshot() {
  const cs = getComputedStyle(app);
  // Persist both the current buffer and its clean baseline. This lets us recover
  // unsaved edits without writing them over the user's files on startup.
  const tabs = S.tabs.map((t) => {
    const st = stateOf(t);
    return {
      path: t.path || null,
      name: t.name,
      content: st.doc.toString(),
      cleanContent: t.clean.toString(),
      cursor: st.selection.main.head,
    };
  });
  return {
    version: 2,
    savedAt: Date.now(),
    root: S.root,
    tabs,
    files: S.tabs.filter((t) => t.path).map((t) => t.path),
    active: S.active && S.active.path,
    activeName: S.active && S.active.name,
    expanded: tree.expanded(),
    sw: app.style.getPropertyValue('--sw') || cs.getPropertyValue('--sw'),
    ph: app.style.getPropertyValue('--ph'),
    pw: app.style.getPropertyValue('--pw'),
    panel: !app.classList.contains('panel-hidden'),
    view: S.view,
    untitled: S.untitled,
  };
}
function saveSessionNow() { saveSession(buildSessionSnapshot()); }
function saveRecoveryNow() { saveRecoverySnapshot(buildSessionSnapshot()); }

// refresh the tree + file index when coming back to the window (files may have changed in the terminal)
let focusTimer = 0;
addEventListener('focus', () => {
  clearTimeout(focusTimer);
  focusTimer = setTimeout(() => { S.files = null; if (S.root) tree.refresh(); }, 250);
});

// ───────────── close guard ─────────────
getCurrentWindow().onCloseRequested(async (e) => {
  const dirty = S.tabs.filter(isDirty);
  if (dirty.length) {
    e.preventDefault();
    const c = await askChoice(`${dirty.length} file(s) have unsaved changes.`, ['Save all', 'Discard', 'Cancel'], 1);
    if (c === -1 || c === 2) return;
    if (c === 0) {
      for (const t of dirty) {
        if (!(await saveTab(t))) return;
      }
      if (S.tabs.some(isDirty)) return;
    } else {
      // Discard means discard: don't resurrect these buffers on next launch.
      for (const t of dirty) {
        t.state = editor.makeState(t.clean.toString(), t.path || t.name);
        if (t === S.active) editor.setState(t.state);
      }
    }
    recoveryWriter.dispose();
    clearRecoverySnapshot();
    saveSessionNow();
    if (S.lsp) await S.lsp.dispose();
  await getCurrentWindow().destroy();
  } else { recoveryWriter.dispose(); clearRecoverySnapshot(); saveSessionNow(); }
});

// ───────────── boot ─────────────
(async function boot() {
  S.os = await invoke('os_name');
  applySettings();
  await initTerminals({ tabs: $('#ptabs'), body: $('#pbody'), onAllClosed: () => showPanel(false) });
  ensureDebugView();
  app.classList.add('panel-hidden');

  const storedSession = loadSession();
  const recovery = loadRecoverySnapshot();
  const recovered = shouldRecover(storedSession, recovery);
  const ses = recovered ? recovery : storedSession;
  if (recovered) toast('Recovered your latest local editing session after an unexpected shutdown.', 'info');
  if (ses.sw) app.style.setProperty('--sw', ses.sw);
  if (ses.ph) app.style.setProperty('--ph', ses.ph);
  if (ses.pw) app.style.setProperty('--pw', ses.pw);
  tree.setExpanded(ses.expanded);
  if (Number.isInteger(ses.untitled) && ses.untitled > 0) S.untitled = ses.untitled;
  if (ses.root) await openFolder(ses.root); else await tree.refresh();

  // Version 2 stores full editor buffers. Older sessions are still supported.
  if (Array.isArray(ses.tabs)) {
    for (const saved of ses.tabs) {
      if (!saved || typeof saved.content !== 'string') continue;
      let tab = null;
      if (typeof saved.path === 'string' && saved.path) {
        await openFile(saved.path);
        tab = S.tabs.find((t) => t.path === saved.path);
        if (!tab) continue; // The file no longer exists or cannot be read.
      } else {
        const name = typeof saved.name === 'string' && saved.name ? saved.name : `untitled-${S.untitled++}`;
        const state = editor.makeState('', name);
        tab = { path: null, name, state, clean: state.doc };
        S.tabs.push(tab);
      }
      const cleanText = typeof saved.cleanContent === 'string' ? saved.cleanContent : tab.clean.toString();
      tab.clean = editor.makeState(cleanText, tab.path || tab.name).doc;
      tab.state = editor.makeState(saved.content, tab.path || tab.name);
      if (Number.isInteger(saved.cursor)) {
        const pos = Math.max(0, Math.min(saved.cursor, tab.state.doc.length));
        tab.state = tab.state.update({ selection: { anchor: pos } }).state;
      }
      if (tab === S.active) editor.setState(tab.state);
    }
  } else {
    for (const f of ses.files || []) await openFile(f);
  }
  const a = S.tabs.find((t) => t.path === ses.active) || S.tabs.find((t) => !t.path && t.name === ses.activeName);
  if (a) activate(a);
  if (ses.view === 'search') showView('search');
  if (ses.view === 'source-control') showView('source-control');
  if (ses.view === 'packages') showView('packages');
  if (ses.panel) showPanel(true);
  renderTabs();
  renderRecentProjects();
  updateStatus();
})();
