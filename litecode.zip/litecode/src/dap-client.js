import { invoke } from '@tauri-apps/api/core';
import { listen } from '@tauri-apps/api/event';
import { DapSession } from './dap-session.js';

/** Tauri bridge for the bundled-in-runtime Python debugpy adapter launcher. */
export class DapClient {
  constructor({ root, python = null, requestTimeoutMs, onStatus = () => {}, onStderr = () => {}, onEvent = () => {}, onAdapterRequest = () => {} } = {}) {
    if (typeof root !== 'string' || !root.trim()) throw new TypeError('A project root is required');
    this.root = root;
    this.python = typeof python === 'string' && python.trim() ? python.trim() : null;
    this.requestTimeoutMs = requestTimeoutMs;
    this.onStderr = onStderr;
    this.onStatus = onStatus;
    this.onEvent = onEvent;
    this.onAdapterRequest = onAdapterRequest;
    this.id = null;
    this.session = null;
    this.disposers = [];
    this.closed = false;
  }

  async start() {
    if (this.id !== null) return this;
    if (this.closed) throw new Error('DAP client is closed');
    const id = await invoke('dap_start', { root: this.root, python: this.python });
    this.id = id;
    this.session = new DapSession({
      sendBytes: (message) => invoke('dap_send', { id, message }),
      ...(this.requestTimeoutMs === undefined ? {} : { requestTimeoutMs: this.requestTimeoutMs }),
    });
    this.session.on('event', (message) => this.onEvent(message));
    this.session.on('adapterRequest', (message) => this.#handleAdapterRequest(message));
    this.session.on('requestTimeout', ({ command, timeoutMs }) => this.onStatus(`Debugger request '${command}' timed out after ${Math.round(timeoutMs / 1000)} s`, 'err'));
    this.session.on('close', (error) => this.onStatus(error.message, 'info'));

    try {
      this.disposers.push(await listen(`dap-message-${id}`, (event) => this.session?.receive(event.payload)));
      this.disposers.push(await listen(`dap-stderr-${id}`, (event) => {
        const text = String(event.payload || '');
        if (text.trim()) this.onStderr(text.slice(0, 2000));
      }));
      this.disposers.push(await listen(`dap-exit-${id}`, (event) => {
        // Fires when the adapter's output stream ends: crash, kill, or normal exit.
        this.session?.close(String(event.payload || 'Debug adapter process exited'));
      }));
      this.disposers.push(await listen(`dap-error-${id}`, (event) => {
        const message = String(event.payload || 'Debug adapter transport failed');
        this.onStatus(message, 'err');
        this.session?.close(message);
      }));
    } catch (error) {
      await this.stop();
      throw error;
    }
    this.onStatus('Python debug adapter process started.', 'ok');
    return this;
  }

  // Reverse requests (runInTerminal, startDebugging, ...) are not supported: answer with an
  // error instead of leaving the adapter waiting forever.
  #handleAdapterRequest(message) {
    let handled = false;
    try { handled = this.onAdapterRequest(message) === true; } catch { /* fall through to default reply */ }
    if (handled || !this.session) return;
    const reason = message.command === 'runInTerminal'
      ? 'LiteCode shows program output in the debug console; runInTerminal is not supported'
      : `Unsupported request '${message.command}'`;
    this.session.respond(message, { success: false, message: reason }).catch(() => {});
  }

  request(command, args = {}) {
    if (!this.session || this.closed) return Promise.reject(new Error('Start the debug adapter first'));
    return this.session.request(command, args);
  }

  on(name, listener) {
    if (!this.session) throw new Error('Start the debug adapter before subscribing to DAP events');
    return this.session.on(name, listener);
  }

  async stop() {
    const id = this.id;
    this.id = null;
    this.session?.close('DAP client stopped');
    this.session = null;
    for (const dispose of this.disposers.splice(0)) {
      try { dispose(); } catch { /* Ignore stale event-listener cleanup errors. */ }
    }
    if (id !== null) {
      try { await invoke('dap_stop', { id }); }
      finally { this.onStatus('Debug adapter stopped', 'info'); }
    }
  }

  async close() {
    await this.stop();
    this.closed = true;
  }
}
