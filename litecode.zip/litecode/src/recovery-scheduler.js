/** Coalesce frequent editor changes into periodic recovery writes. */
export function createRecoveryScheduler(save, delay = 700, timers = globalThis) {
  if (typeof save !== 'function') throw new TypeError('save must be a function');
  if (!Number.isFinite(delay) || delay < 0) throw new RangeError('delay must be a non-negative number');
  let timer = null;
  let disposed = false;

  function schedule() {
    if (disposed || timer !== null) return;
    timer = timers.setTimeout(() => {
      timer = null;
      if (!disposed) save();
    }, delay);
  }

  function flush() {
    if (disposed) return false;
    if (timer !== null) {
      timers.clearTimeout(timer);
      timer = null;
    }
    save();
    return true;
  }

  function cancel() {
    if (timer !== null) {
      timers.clearTimeout(timer);
      timer = null;
    }
  }

  function dispose() {
    cancel();
    disposed = true;
  }

  return { schedule, flush, cancel, dispose };
}
