import { basename, dirname, posixQuote, cmdQuote } from './run.js';

const MAX_ARGS_LENGTH = 4000;

/**
 * Splits an argument string like a shell would, without running a shell.
 * Windows mode keeps backslashes literal (paths) except directly before a double quote.
 */
export function parseArgsString(input, { windows = false } = {}) {
  const text = String(input ?? '');
  if (text.length > MAX_ARGS_LENGTH) throw new RangeError('Arguments are too long');
  const args = []; let current = ''; let quote = null; let started = false;
  for (let i = 0; i < text.length; i++) {
    const c = text[i];
    if (quote === "'") { if (c === "'") quote = null; else current += c; continue; }
    if (c === '\\') {
      const next = text[i + 1];
      if (windows ? next === '"' : (next !== undefined && (quote === '"' ? '"\\$`'.includes(next) : true))) { current += next; i++; started = true; continue; }
      current += c; started = true; continue;
    }
    if (quote === '"') { if (c === '"') quote = null; else current += c; continue; }
    if (c === '"' || (c === "'" && !windows)) { quote = c; started = true; continue; }
    if (/\s/.test(c)) { if (started) { args.push(current); current = ''; started = false; } continue; }
    current += c; started = true;
  }
  if (quote) throw new SyntaxError('Unterminated quote in arguments');
  if (started) args.push(current);
  return args;
}

export function formatArgsString(args, { windows = false } = {}) {
  return (Array.isArray(args) ? args : []).map((arg) => {
    const s = String(arg);
    if (s && /^[\w@%+=:,./\\-]+$/.test(s)) return s;
    return windows ? `"${s.replace(/"/g, '\\"')}"` : posixQuote(s);
  }).join(' ');
}

const within = (path, root, windows) => {
  const norm = (v) => String(v).replace(/\\/g, '/').replace(/\/+$/, '');
  const a = windows ? norm(path).toLowerCase() : norm(path);
  const b = windows ? norm(root).toLowerCase() : norm(root);
  return a === b || a.startsWith(`${b}/`);
};

/**
 * Validates a user-edited run configuration and returns a normalized copy.
 * Both the script and the working directory must stay inside the opened project.
 */
export function normalizeRunConfig(input, { root, os = 'linux' } = {}) {
  const windows = os === 'windows';
  if (!input || typeof input !== 'object') throw new TypeError('A run configuration is required');
  if (typeof root !== 'string' || !root) throw new Error('Open a project folder first');
  const program = String(input.program || '').trim();
  if (!program) throw new Error('Choose a Python file to run');
  if (!/\.pyw?$/i.test(program)) throw new Error('The selected file is not a Python (.py) file');
  if (!within(program, root, windows)) throw new Error('The Python file must be inside the opened project folder');
  const cwd = String(input.cwd || '').trim() || dirname(program);
  if (!within(cwd, root, windows)) throw new Error('The working directory must be inside the opened project folder');
  const args = Array.isArray(input.args) ? input.args.map(String) : parseArgsString(input.args ?? '', { windows });
  if (args.some((a) => a.includes('\0'))) throw new Error('Arguments cannot contain NUL characters');
  return {
    program, cwd, args,
    stopOnEntry: input.stopOnEntry === true,
    breakOnUncaught: input.breakOnUncaught !== false,
  };
}

/** Terminal command for a normal (non-debug) Python run using the same configuration. */
export function buildPythonRunCommand(config, os, python) {
  const win = os === 'windows';
  const q = win ? cmdQuote : posixQuote;
  const py = python || (win ? 'python' : 'python3');
  const cd = win ? `cd /d ${q(config.cwd)}` : `cd ${q(config.cwd)}`;
  const parts = [q(py), q(config.program), ...config.args.map(q)];
  return `${cd} && ${win ? 'cls' : 'clear'} && ${parts.join(' ')}`;
}

export const defaultRunConfigFor = (program) => ({ program, cwd: dirname(program), args: [], stopOnEntry: false, breakOnUncaught: true, name: basename(program) });

const KEY = 'litecode.runConfigs';
export function loadRunConfigs(storage = globalThis.localStorage) {
  try {
    const parsed = JSON.parse(storage.getItem(KEY) || '{}');
    return parsed && typeof parsed === 'object' && !Array.isArray(parsed) ? parsed : {};
  } catch { return {}; }
}
export function saveRunConfig(program, config, storage = globalThis.localStorage) {
  try {
    const all = loadRunConfigs(storage);
    delete all[program];
    all[program] = { cwd: config.cwd, args: config.args, stopOnEntry: !!config.stopOnEntry, breakOnUncaught: config.breakOnUncaught !== false };
    const keys = Object.keys(all);
    for (const old of keys.slice(0, Math.max(0, keys.length - 50))) delete all[old];
    storage.setItem(KEY, JSON.stringify(all));
    return true;
  } catch { return false; }
}
