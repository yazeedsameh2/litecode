// Small, transport-independent helpers for Language Server Protocol (LSP) JSON-RPC.
// LSP uses HTTP-like headers over stdio, not newline-delimited JSON.
export function encodeLspMessage(message) {
  const body = JSON.stringify(message);
  const bytes = new TextEncoder().encode(body);
  const header = `Content-Length: ${bytes.length}\r\n\r\n`;
  return { header, body, byteLength: bytes.length };
}

export function decodeLspFrame(buffer) {
  const marker = buffer.indexOf("\r\n\r\n");
  if (marker < 0) return null;
  const headers = buffer.slice(0, marker).split("\r\n");
  const line = headers.find((x) => /^content-length\s*:/i.test(x));
  if (!line) throw new Error("LSP frame is missing Content-Length");
  const length = Number(line.split(":").slice(1).join(":").trim());
  if (!Number.isSafeInteger(length) || length < 0 || length > 8_000_000) {
    throw new Error("LSP Content-Length is invalid or exceeds 8 MB");
  }
  const bodyStart = marker + 4;
  const bodyBytes = new TextEncoder().encode(buffer.slice(bodyStart));
  if (bodyBytes.length < length) return null;
  const json = new TextDecoder().decode(bodyBytes.slice(0, length));
  return { message: JSON.parse(json), remaining: new TextDecoder().decode(bodyBytes.slice(length)) };
}

export function lspLanguageId(path) {
  const ext = String(path || "").split(".").pop().toLowerCase();
  if (ext === "py") return "python";
  if (["js", "mjs", "cjs"].includes(ext)) return "javascript";
  if (["ts", "tsx"].includes(ext)) return "typescript";
  if (ext === "jsx") return "javascriptreact";
  return null;
}

export function initializeParams(rootUri, processId = null) {
  return {
    processId,
    rootUri,
    capabilities: {
      textDocument: {
        completion: { completionItem: { snippetSupport: true, documentationFormat: ["markdown", "plaintext"] } },
        publishDiagnostics: { relatedInformation: true },
        definition: { dynamicRegistration: false },
        codeAction: {
          dynamicRegistration: false,
          codeActionLiteralSupport: { codeActionKind: { valueSet: ["quickfix", "refactor", "refactor.extract", "refactor.inline", "refactor.rewrite", "source", "source.organizeImports"] } },
          resolveSupport: { properties: ["edit", "command"] },
        },
        hover: { contentFormat: ["markdown", "plaintext"] },
      },
      workspace: { workspaceFolders: true, configuration: true },
    },
    workspaceFolders: rootUri ? [{ uri: rootUri, name: rootUri.split("/").pop() || "workspace" }] : null,
  };
}


export function normalizeCompletionItems(result) {
  const items = Array.isArray(result) ? result : (result?.items || []);
  const kindNames = { 1: 'text', 2: 'method', 3: 'function', 4: 'function', 5: 'class', 6: 'variable', 7: 'class', 8: 'type', 9: 'property', 10: 'variable', 14: 'keyword', 15: 'snippet' };
  return items.slice(0, 100).map((item) => {
    const documentation = typeof item.documentation === 'string' ? item.documentation : item.documentation?.value;
    return {
      label: String(item.label || ''),
      type: kindNames[item.kind] || 'text',
      detail: [item.detail, documentation].filter(Boolean).join(' — ').slice(0, 500),
      apply: item.textEdit?.newText || item.insertText || item.label,
      boost: item.sortText ? -Math.min(item.sortText.charCodeAt(0) || 0, 100) : 0,
    };
  }).filter((item) => item.label);
}
