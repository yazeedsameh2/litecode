// Debugger + unified Python run UI. All debug logic lives in DebugController (tested against a fake
// adapter); this module only renders state and wires editor, terminal and panel together.
import { DapClient } from './dap-client.js';
import { DebugController } from './debug-controller.js';
import { BreakpointStore } from './debug-breakpoints.js';
import { splitErrorSegments, resolveErrorPath } from './python-errors.js';
import { normalizeRunConfig, buildPythonRunCommand, formatArgsString, loadRunConfigs, saveRunConfig } from './run-config.js';
import { dirname, basename } from './run.js';

const sameLines = (a, b) => a.length === b.length && a.every((v, i) => v === b[i]);
const isPython = (path) => /\.pyw?$/i.test(path || '');

export function createDebugUI(ctx) {
  const { S, app, $, toast, askChoice, askRunConfig, editor, openFile, saveTab, isDirty, pathWithinRoot, openDialog } = ctx;
  const windows = () => S.os === 'windows';
  const store = new BreakpointStore({ caseInsensitive: /windows/i.test(globalThis.navigator?.userAgent || '') });
  let view = null; let visible = false; let busy = false; let currentLocation = null; let locSeq = 0; let lastRunCwd = null;
  let controller = null;

  const normPath = (p) => (windows() ? String(p).replace(/\\/g, '/').toLowerCase() : String(p));
  const samePath = (a, b) => !!a && !!b && normPath(a) === normPath(b);
  // The adapter may report a path with different case/separators on Windows; reuse the open tab's path.
  const canonicalPath = (path) => S.tabs.find((t) => t.path && samePath(t.path, path))?.path || path;

  // ───────────── editor decorations ─────────────
  function applyEditorDecorations() {
    const tab = S.active;
    if (!tab || !tab.path) { editor.setBreakpoints([], []); editor.setExecutionLine(null); return; }
    if (!sameLines(editor.getBreakpointLines(), store.lines(tab.path)) || store.unverified(tab.path).length) editor.setBreakpoints(store.lines(tab.path), store.unverified(tab.path));
    const loc = currentLocation;
    if (loc && samePath(loc.path, tab.path)) editor.setExecutionLine(loc.line, loc.kind); else editor.setExecutionLine(null);
  }

  store.subscribe((event) => {
    ctx.saveSessionSoon();
    renderBreakpointList();
    const tab = S.active;
    if (!tab?.path) return;
    if (event.type !== 'change' || samePath(event.path, tab.path)) {
      // Repaint when the store differs from the gutter (list removal, adapter adjustment, restore).
      if (!sameLines(editor.getBreakpointLines(), store.lines(tab.path)) || event.type === 'verification') editor.setBreakpoints(store.lines(tab.path), store.unverified(tab.path));
    }
  });

  function toggleBreakpointAt(line) {
    const tab = S.active;
    if (!tab) return;
    if (!tab.path) return toast('Save the file before setting breakpoints.', 'err');
    if (!isPython(tab.path)) return toast('Breakpoints are supported for Python files only.', 'err');
    try { store.toggle(tab.path, line); } catch (error) { toast(String(error.message || error), 'err'); }
  }
  const toggleBreakpointAtCursor = () => toggleBreakpointAt(editor.currentLine());
  function onBreakpointsMoved(lines) {
    const tab = S.active;
    if (tab?.path) store.setLines(tab.path, lines); // fires `change` -> synced to a running session
  }

  // ───────────── console ─────────────
  function appendOutput(category, text) {
    ensureView();
    const out = $('#debug-output');
    const nearBottom = out.scrollHeight - out.scrollTop - out.clientHeight < 40;
    for (const segment of splitErrorSegments(String(text))) {
      const node = document.createElement(segment.link ? 'a' : 'span');
      node.textContent = segment.text;
      if (category === 'stderr') node.classList.add('debug-out-stderr');
      else if (category === 'adapter') node.classList.add('debug-out-adapter');
      if (segment.link) {
        node.className += ' debug-link'; node.title = 'Open in editor';
        node.onclick = () => openErrorLocation(segment.link, currentConfigCwd());
      }
      out.appendChild(node);
    }
    while (out.childNodes.length > 5000) out.removeChild(out.firstChild);
    if (nearBottom) out.scrollTop = out.scrollHeight;
  }
  const currentConfigCwd = () => controller?.config?.cwd || lastRunCwd || S.root;
  const clearConsole = () => { ensureView(); $('#debug-output').textContent = ''; };

  async function openErrorLocation(link, cwd = lastRunCwd || S.root) {
    const path = resolveErrorPath(link.path, cwd);
    if (!path) return toast(`Cannot resolve ${link.path}`, 'err');
    await openFile(canonicalPath(path), { line: link.line, col: link.column || 1 });
  }

  // ───────────── controller ─────────────
  function ensureController() {
    if (controller) return controller;
    controller = new DebugController({
      store,
      isPathAllowed: (path) => !!S.root && pathWithinRoot(path, S.root),
      createClient: async ({ python, onStatus, onStderr }) => {
        const client = new DapClient({ root: S.root, python, onStatus, onStderr });
        try { await client.start(); } catch (error) { await client.close().catch(() => {}); throw error; }
        return client;
      },
      onState: ({ state, detail }) => applyState(state, detail),
      onOutput: ({ category, text }) => appendOutput(category, text),
      onStopped: () => { if (!visible) openPanel(); renderStack(); },
      onLocation: (loc) => showLocation(loc),
      onScopes: (payload) => renderScopes(payload),
    });
    return controller;
  }

  async function showLocation(loc) {
    currentLocation = loc;
    const seq = ++locSeq;
    if (loc) {
      await openFile(canonicalPath(loc.path), { line: loc.line, col: loc.column }).catch(() => {});
      if (seq !== locSeq) return;
    }
    applyEditorDecorations();
    highlightSelectedFrame();
  }

  // ───────────── panel ─────────────
  function ensureView() {
    if (view) return view;
    view = document.createElement('section');
    view.id = 'debugger-view';
    view.hidden = true;
    view.innerHTML = `
      <div class="debug-toolbar">
        <span id="debug-state" class="debug-state">Idle</span>
        <button id="debug-start" class="primary" title="Start debugging the active Python file (F6)">▶ Start Debugging</button>
        <button id="debug-restart" title="Restart with the same configuration (Ctrl+Shift+F5)" disabled>↻ Restart</button>
        <button id="debug-config" title="Run / Debug configuration… (Ctrl+Alt+R)">⚙ Configure…</button>
        <span class="debug-sep"></span>
        <button id="debug-breakpoint" title="Toggle breakpoint on current line (F9)">● Breakpoint</button>
        <button id="debug-continue" title="Continue (F5)" disabled>▶ Continue</button>
        <button id="debug-over" title="Step over (F10)" disabled>↷ Over</button>
        <button id="debug-into" title="Step into (F11)" disabled>↓ Into</button>
        <button id="debug-out" title="Step out (Shift+F11)" disabled>↑ Out</button>
        <button id="debug-pause" title="Pause execution" disabled>Ⅱ Pause</button>
        <button id="debug-stop" title="Stop debugging (Shift+F5)" disabled>■ Stop</button>
      </div>
      <div class="debug-content">
        <div class="debug-column"><div class="debug-heading">BREAKPOINTS <button id="debug-clear-bps" class="debug-item" style="display:inline;width:auto;padding:0 4px" title="Remove all breakpoints">✕ all</button></div><div id="debug-breakpoints" class="debug-list"></div></div>
        <div class="debug-column"><div class="debug-heading">CALL STACK</div><div id="debug-stack" class="debug-list"><div class="debug-empty">Start debugging to inspect frames.</div></div></div>
        <div class="debug-column"><div class="debug-heading">VARIABLES</div><div id="debug-variables" class="debug-list"><div class="debug-empty">Variables appear when execution pauses.</div></div></div>
        <div class="debug-column debug-output-column"><div class="debug-heading">DEBUG CONSOLE</div><pre id="debug-output" class="debug-output"></pre>
          <div class="debug-eval-row"><input id="debug-eval" type="text" spellcheck="false" placeholder="Evaluate expression while paused…" disabled /></div></div>
      </div>`;
    $('#panel').appendChild(view);
    $('#debug-start').onclick = () => quickDebug();
    $('#debug-restart').onclick = () => restart();
    $('#debug-config').onclick = () => configure();
    $('#debug-breakpoint').onclick = toggleBreakpointAtCursor;
    $('#debug-continue').onclick = () => action(() => controller.continue());
    $('#debug-over').onclick = () => action(() => controller.stepOver());
    $('#debug-into').onclick = () => action(() => controller.stepInto());
    $('#debug-out').onclick = () => action(() => controller.stepOut());
    $('#debug-pause').onclick = () => action(() => controller.pause());
    $('#debug-stop').onclick = () => stop();
    $('#debug-clear-bps').onclick = () => store.clear();
    $('#debug-eval').onkeydown = async (e) => {
      if (e.key !== 'Enter') return;
      e.stopPropagation();
      const expr = e.target.value.trim();
      if (!expr) return;
      e.target.value = '';
      appendOutput('adapter', `> ${expr}\n`);
      try { const r = await controller.evaluate(expr); appendOutput('console', `${r.result ?? ''}\n`); }
      catch (error) { appendOutput('stderr', `${error.message || error}\n`); }
    };
    renderBreakpointList();
    applyState(controller?.state || 'idle', '');
    return view;
  }

  function openPanel() {
    ensureView();
    visible = true;
    app.classList.remove('panel-hidden');
    $('#pbody').style.display = 'none';
    view.hidden = false;
    ctx.saveSessionSoon();
  }
  function hidePanel() { visible = false; if (view) view.hidden = true; }
  const isVisible = () => visible;

  const LABELS = { idle: 'Idle', starting: 'Starting…', running: 'Running', stopped: 'Paused', stopping: 'Stopping…', finished: 'Finished', disconnected: 'Disconnected' };
  function applyState(state, detail = '') {
    if (!view) return;
    const label = LABELS[state] || state;
    $('#debug-state').textContent = detail && state !== 'starting' ? `${label}: ${detail}` : label;
    const stopped = state === 'stopped'; const running = state === 'running';
    const active = ['starting', 'running', 'stopped'].includes(state);
    for (const id of ['debug-continue', 'debug-over', 'debug-into', 'debug-out']) $(`#${id}`).disabled = !stopped;
    $('#debug-pause').disabled = !running;
    $('#debug-stop').disabled = !active;
    $('#debug-start').disabled = busy || active || state === 'stopping';
    $('#debug-restart').disabled = !controller?.config || state === 'starting' || state === 'stopping';
    $('#debug-config').disabled = state === 'stopping';
    $('#debug-eval').disabled = !stopped;
    if (running || state === 'starting') {
      $('#debug-stack').innerHTML = `<div class="debug-empty">${running ? 'Program is running…' : 'Starting…'}</div>`;
      $('#debug-variables').innerHTML = '<div class="debug-empty">Variables appear when execution pauses.</div>';
    } else if (['finished', 'idle', 'disconnected'].includes(state)) {
      const message = state === 'disconnected' ? 'Debug connection lost. Use Restart to try again.' : state === 'finished' ? 'Program has finished.' : 'Start debugging to inspect frames.';
      $('#debug-stack').innerHTML = `<div class="debug-empty">${message}</div>`;
      $('#debug-variables').innerHTML = '<div class="debug-empty">No paused variables.</div>';
    }
    const status = $('#st-debug'); if (status) { status.hidden = !active; status.textContent = `🐞 ${label}`; }
  }

  function renderBreakpointList() {
    if (!view) return;
    const box = $('#debug-breakpoints'); box.innerHTML = '';
    const entries = store.entries();
    if (!entries.length) { box.innerHTML = '<div class="debug-empty">No breakpoints. Click the gutter next to a line number in a Python file, or press F9.</div>'; return; }
    for (const [path, lines] of entries) {
      const unverified = new Set(store.unverified(path));
      for (const line of lines) {
        const row = document.createElement('button'); row.className = 'debug-item';
        row.textContent = `${unverified.has(line) ? '○' : '●'} ${basename(path)} : ${line}`;
        row.title = unverified.has(line) ? `${path}\nNot bound by the debugger` : path;
        row.onclick = () => openFile(canonicalPath(path), { line, col: 1 });
        row.oncontextmenu = (e) => { e.preventDefault(); store.toggle(path, line); };
        box.appendChild(row);
      }
    }
  }

  function renderStack() {
    if (!view || !controller) return;
    const box = $('#debug-stack'); box.innerHTML = '';
    const frames = controller.frames;
    if (!frames.length) { box.innerHTML = '<div class="debug-empty">No stack frames reported.</div>'; return; }
    for (const frame of frames) {
      const button = document.createElement('button'); button.className = 'debug-item'; button.dataset.frameId = String(frame.id);
      const source = frame.source?.path || frame.source?.name || 'unknown source';
      button.textContent = `${frame.name || '(anonymous)'} — ${basename(source)}:${frame.line || 1}`;
      button.title = source;
      button.onclick = () => action(() => controller.selectFrame(frame.id));
      box.appendChild(button);
    }
    highlightSelectedFrame();
  }
  function highlightSelectedFrame() {
    if (!view) return;
    const id = String(controller?.selectedFrameId ?? '');
    for (const b of $('#debug-stack').querySelectorAll('.debug-item')) b.classList.toggle('selected', b.dataset.frameId === id);
  }

  function renderVariableRows(container, variables, depth = 0) {
    for (const variable of variables) {
      const wrap = document.createElement('div');
      const row = document.createElement('div'); row.className = 'debug-variable';
      const left = document.createElement('span');
      const twisty = document.createElement('span'); twisty.className = 'debug-var-twisty';
      const name = document.createElement('span'); name.className = 'debug-var-name'; name.textContent = variable.name || '(unnamed)';
      const value = document.createElement('span'); value.className = 'debug-var-value'; value.textContent = variable.value ?? ''; value.title = variable.type || '';
      const expandable = Number(variable.variablesReference) > 0 && depth < 6;
      twisty.textContent = expandable ? '▸' : '';
      left.append(twisty, name); row.append(left, value); wrap.append(row);
      if (expandable) {
        let box = null;
        const toggle = async () => {
          if (box) { box.remove(); box = null; twisty.textContent = '▸'; return; }
          twisty.textContent = '…';
          try {
            const children = await controller.expand(variable.variablesReference);
            box = document.createElement('div'); box.className = 'debug-children';
            renderVariableRows(box, children, depth + 1);
            wrap.append(box); twisty.textContent = '▾';
          } catch (error) { twisty.textContent = '▸'; appendOutput('stderr', `Could not expand ${variable.name}: ${error.message || error}\n`); }
        };
        twisty.onclick = toggle; name.onclick = toggle;
      }
      container.appendChild(wrap);
    }
  }

  function renderScopes({ scopes }) {
    if (!view) return;
    highlightSelectedFrame();
    const box = $('#debug-variables'); box.innerHTML = '';
    if (!scopes.length) { box.innerHTML = '<div class="debug-empty">No scopes available.</div>'; return; }
    for (const scope of scopes) {
      const title = document.createElement('div'); title.className = 'debug-scope-title';
      const body = document.createElement('div');
      let open = scope.variables !== null;
      const paint = async () => {
        title.textContent = `${open ? '▾' : '▸'} ${scope.name}`;
        body.innerHTML = '';
        if (!open) return;
        try {
          const variables = scope.variables ?? await controller.expand(scope.variablesReference);
          if (!variables.length) body.innerHTML = '<div class="debug-empty">No variables in this scope.</div>';
          else renderVariableRows(body, variables);
        } catch (error) { body.innerHTML = ''; appendOutput('stderr', `Could not load ${scope.name}: ${error.message || error}\n`); }
      };
      title.onclick = () => { open = !open; paint(); };
      box.append(title, body);
      paint();
    }
  }

  async function action(fn) {
    try { await fn(); }
    catch (error) { appendOutput('stderr', `Debugger: ${error.message || error}\n`); toast(`Debugger: ${error.message || error}`, 'err'); }
  }

  // ───────────── run / debug configuration ─────────────
  const initialConfigFor = (tab) => {
    const saved = loadRunConfigs()[tab.path] || {};
    return {
      program: tab.path, cwd: saved.cwd || dirname(tab.path), args: formatArgsString(saved.args || [], { windows: windows() }),
      stopOnEntry: !!saved.stopOnEntry, breakOnUncaught: saved.breakOnUncaught !== false,
    };
  };
  const normalize = (values) => normalizeRunConfig(values, { root: S.root, os: S.os });

  async function prepareActivePython(actionName) {
    const tab = S.active;
    if (!tab) { toast('Open a Python file first.', 'err'); return null; }
    if (!isPython(tab.name)) { toast(`${actionName} supports Python (.py) files here.`, 'err'); return null; }
    if (!S.root) { toast('Open a project folder first.', 'err'); return null; }
    if (!tab.path || isDirty(tab)) { if (!(await saveTab(tab))) return null; }
    if (!S.active?.path) return null;
    return S.active;
  }

  async function chooseFile(current) {
    const result = await openDialog({ multiple: false, directory: false, defaultPath: current || S.root || undefined, filters: [{ name: 'Python', extensions: ['py', 'pyw'] }] });
    return typeof result === 'string' ? result : null;
  }
  async function chooseDir(current) {
    const result = await openDialog({ multiple: false, directory: true, defaultPath: current || S.root || undefined });
    return typeof result === 'string' ? result : null;
  }

  /** The unified Run / Debug dialog (Ctrl+Alt+R). */
  async function configure() {
    const tab = await prepareActivePython('Run / Debug');
    if (!tab) return;
    const values = await askRunConfig({
      initial: initialConfigFor(tab), browseFile: chooseFile, browseDir: chooseDir,
      validate: (v) => { try { normalize(v); return null; } catch (error) { return error.message || String(error); } },
    });
    if (!values) return;
    const config = normalize(values);
    saveRunConfig(config.program, config);
    if (values.action === 'debug') await debug(config); else await run(config);
  }

  /** Normal run in the integrated terminal using the remembered (or default) configuration. */
  async function run(config) {
    lastRunCwd = config.cwd;
    await ctx.runInTerminalPanel(buildPythonRunCommand(config, S.os, ctx.getPythonCmd()), config.cwd);
  }
  async function quickRun() {
    const tab = await prepareActivePython('Run');
    if (!tab) return;
    try { await run(normalize(initialConfigFor(tab))); } catch (error) { toast(error.message || String(error), 'err'); }
  }
  async function quickDebug() {
    if (busy || controller?.active) { openPanel(); return; }
    const tab = await prepareActivePython('Debug');
    if (!tab) return;
    try { await debug(normalize(initialConfigFor(tab))); } catch (error) { toast(error.message || String(error), 'err'); }
  }

  async function confirmOtherDirtyFiles(config) {
    const others = S.tabs.filter((t) => t.path && t.path !== config.program && isDirty(t) && isPython(t.path) && pathWithinRoot(t.path, S.root));
    if (!others.length) return true;
    const choice = await askChoice(`${others.length} other Python file(s) have unsaved changes. The debugger runs the versions saved on disk.`, ['Save all and debug', 'Debug without saving', 'Cancel'], 2);
    if (choice === 0) { for (const t of others) if (!(await saveTab(t))) return false; return true; }
    return choice === 1;
  }

  /** Starts a debug session. Requires an explicit confirmation: it executes the user's Python code. */
  async function debug(config) {
    if (busy || ensureController().active) { openPanel(); return; }
    const argsText = config.args.length ? formatArgsString(config.args, { windows: windows() }) : '(none)';
    const consent = await askChoice(`LiteCode will run this Python program under the debugger:\n${config.program}\n\nWorking directory: ${config.cwd}\nArguments: ${argsText}\n\nOnly continue if you trust this code. It runs on your computer.`, ['Run and Debug', 'Cancel'], 1);
    if (consent !== 0) return;
    if (!(await confirmOtherDirtyFiles(config))) return;
    saveRunConfig(config.program, config);
    lastRunCwd = config.cwd;
    busy = true; openPanel(); clearConsole(); applyState('starting');
    appendOutput('adapter', `Starting Python debugger for ${config.program}\n`);
    try { await controller.start({ ...config, python: ctx.getPythonCmd() || null }); }
    catch (error) { toast(`Could not start debugger: ${error.message || error}`, 'err'); }
    finally { busy = false; applyState(controller.state, controller.detail); }
  }

  async function restart() {
    if (busy || !controller?.config) return;
    busy = true; clearConsole();
    try { await controller.restart(); } catch (error) { toast(`Could not restart debugger: ${error.message || error}`, 'err'); }
    finally { busy = false; applyState(controller.state, controller.detail); }
  }
  async function stop() { if (controller) await action(() => controller.stop()); }

  /** Called when the app is closing: stop the session and kill the adapter process. */
  async function shutdown() { try { await controller?.dispose(); } catch { /* closing anyway */ } }

  return {
    ensureView, openPanel, hidePanel, isVisible, configure, quickRun, quickDebug, restart, stop, shutdown,
    toggleBreakpointAt, toggleBreakpointAtCursor, onBreakpointsMoved, applyEditorDecorations,
    onTabActivated: applyEditorDecorations,
    get active() { return !!controller?.active; },
    get paused() { return controller?.state === 'stopped'; },
    continue: () => action(() => controller.continue()),
    stepOver: () => action(() => controller.stepOver()),
    stepInto: () => action(() => controller.stepInto()),
    stepOut: () => action(() => controller.stepOut()),
    pause: () => action(() => controller.pause()),
    openErrorLocation: (link) => openErrorLocation(link, lastRunCwd || S.root),
    onPathRenamed: (from, to) => { store.rename(from, to); },
    serializeBreakpoints: () => store.serialize(),
    restoreBreakpoints: (data) => store.restore(data),
  };
}
