import { EditorState, Compartment } from '@codemirror/state';
import {
  EditorView, keymap, lineNumbers, highlightActiveLineGutter, highlightSpecialChars,
  drawSelection, dropCursor, rectangularSelection, highlightActiveLine,
} from '@codemirror/view';
import { defaultKeymap, history, historyKeymap, indentWithTab } from '@codemirror/commands';
import {
  syntaxHighlighting, HighlightStyle, indentOnInput, bracketMatching, foldGutter, foldKeymap, indentUnit,
} from '@codemirror/language';
import {
  autocompletion, closeBrackets, closeBracketsKeymap, completionKeymap, completeFromList, snippetCompletion,
} from '@codemirror/autocomplete';
import { searchKeymap, highlightSelectionMatches } from '@codemirror/search';
import { tags as t } from '@lezer/highlight';
import { python, pythonLanguage } from '@codemirror/lang-python';
import { javascript } from '@codemirror/lang-javascript';
import { html } from '@codemirror/lang-html';
import { css } from '@codemirror/lang-css';
import { json } from '@codemirror/lang-json';
import { markdown } from '@codemirror/lang-markdown';
import { cpp } from '@codemirror/lang-cpp';
import { java } from '@codemirror/lang-java';
import { rust } from '@codemirror/lang-rust';
import { sql } from '@codemirror/lang-sql';
import { xml } from '@codemirror/lang-xml';
import { yaml } from '@codemirror/lang-yaml';
import { abbreviationTracker } from '@emmetio/codemirror6-plugin';
import { settings } from './state.js';

const pySnippets = completeFromList([
  snippetCompletion('def ${name}(${args}):\n\t${}', { label: 'def', detail: 'function', type: 'keyword' }),
  snippetCompletion('class ${Name}:\n\tdef __init__(self${}):\n\t\t${}', { label: 'class', detail: 'class', type: 'keyword' }),
  snippetCompletion('for ${i} in ${items}:\n\t${}', { label: 'for', detail: 'loop', type: 'keyword' }),
  snippetCompletion('while ${cond}:\n\t${}', { label: 'while', detail: 'loop', type: 'keyword' }),
  snippetCompletion('if ${cond}:\n\t${}', { label: 'if', detail: 'condition', type: 'keyword' }),
  snippetCompletion('if __name__ == "__main__":\n\t${}', { label: 'main', detail: 'entry point', type: 'keyword' }),
  snippetCompletion('try:\n\t${}\nexcept ${Exception} as ${e}:\n\t${}', { label: 'try', detail: 'try / except', type: 'keyword' }),
  snippetCompletion('with open(${path}) as ${f}:\n\t${}', { label: 'with', detail: 'open file', type: 'keyword' }),
  snippetCompletion('print(${})', { label: 'print', detail: 'builtin', type: 'function' }),
]);

const emmet = () => { try { return abbreviationTracker(); } catch { return []; } };

const LANGS = {
  py: ['Python', () => [python(), pythonLanguage.data.of({ autocomplete: pySnippets })]],
  js: ['JavaScript', () => javascript()],
  mjs: ['JavaScript', () => javascript()],
  cjs: ['JavaScript', () => javascript()],
  jsx: ['JavaScript React', () => javascript({ jsx: true })],
  ts: ['TypeScript', () => javascript({ typescript: true })],
  tsx: ['TypeScript React', () => javascript({ typescript: true, jsx: true })],
  html: ['HTML', () => [html(), emmet()]],
  htm: ['HTML', () => [html(), emmet()]],
  css: ['CSS', () => [css(), emmet()]],
  json: ['JSON', () => json()],
  md: ['Markdown', () => markdown()],
  c: ['C', () => cpp()],
  h: ['C', () => cpp()],
  cpp: ['C++', () => cpp()],
  cc: ['C++', () => cpp()],
  hpp: ['C++', () => cpp()],
  java: ['Java', () => java()],
  rs: ['Rust', () => rust()],
  sql: ['SQL', () => sql()],
  xml: ['XML', () => xml()],
  svg: ['SVG', () => xml()],
  yml: ['YAML', () => yaml()],
  yaml: ['YAML', () => yaml()],
};

export function langInfo(path) {
  const ext = (path || '').split('.').pop().toLowerCase();
  return LANGS[ext] || ['Plain Text', () => []];
}

const highlight = HighlightStyle.define([
  { tag: [t.keyword, t.controlKeyword, t.moduleKeyword, t.definitionKeyword], color: 'var(--syn-keyword)' },
  { tag: [t.function(t.variableName), t.function(t.propertyName), t.labelName], color: 'var(--syn-function)' },
  { tag: [t.number, t.bool, t.null, t.atom, t.self], color: 'var(--syn-number)' },
  { tag: [t.string, t.special(t.string), t.regexp, t.character], color: 'var(--syn-string)' },
  { tag: [t.comment, t.lineComment, t.blockComment], color: 'var(--syn-comment)', fontStyle: 'italic' },
  { tag: [t.typeName, t.className, t.namespace], color: 'var(--syn-type)' },
  { tag: [t.operator, t.operatorKeyword], color: 'var(--syn-operator)' },
  { tag: [t.propertyName, t.attributeName], color: 'var(--syn-property)' },
  { tag: [t.tagName], color: 'var(--syn-tag)' },
  { tag: [t.punctuation, t.separator, t.bracket], color: 'var(--syn-punct)' },
  { tag: [t.heading], color: 'var(--syn-function)', fontWeight: 'bold' },
  { tag: [t.emphasis], fontStyle: 'italic' },
  { tag: [t.strong], fontWeight: 'bold' },
  { tag: [t.link, t.url], color: 'var(--syn-operator)', textDecoration: 'underline' },
  { tag: [t.invalid], color: 'var(--syn-invalid)' },
]);

const theme = EditorView.theme({
  '&': { height: '100%', color: 'var(--fg)', backgroundColor: 'var(--editor-bg)' },
  '&.cm-focused': { outline: 'none' },
  '.cm-scroller': { fontFamily: 'var(--mono)', lineHeight: '1.6' },
  '.cm-content': { caretColor: 'var(--caret)', padding: '6px 0' },
  '.cm-cursor, .cm-dropCursor': { borderLeftColor: 'var(--caret)', borderLeftWidth: '2px' },
  '&.cm-focused > .cm-scroller > .cm-selectionLayer .cm-selectionBackground, .cm-selectionBackground, .cm-content ::selection':
    { backgroundColor: 'var(--selection) !important' },
  '.cm-gutters': { backgroundColor: 'var(--editor-bg)', color: 'var(--gutter-fg)', border: 'none' },
  '.cm-lineNumbers .cm-gutterElement': { padding: '0 10px 0 14px' },
  '.cm-activeLine': { backgroundColor: 'var(--active-line)' },
  '.cm-activeLineGutter': { backgroundColor: 'transparent', color: 'var(--fg)' },
  '.cm-foldPlaceholder': { backgroundColor: 'var(--hover)', border: 'none', color: 'var(--fg2)' },
  '.cm-tooltip': { backgroundColor: 'var(--panel-bg)', border: '1px solid var(--border)', color: 'var(--fg)', borderRadius: '8px', overflow: 'hidden' },
  '.cm-tooltip-autocomplete > ul': { fontFamily: 'var(--mono)', fontSize: '13px' },
  '.cm-tooltip-autocomplete > ul > li[aria-selected]': { backgroundColor: 'var(--accent-soft)', color: 'var(--fg)' },
  '.cm-panels': { backgroundColor: 'var(--panel-bg)', color: 'var(--fg)', borderColor: 'var(--border)' },
  '.cm-panels input, .cm-panels button': { fontFamily: 'var(--ui)' },
  '.cm-textfield': { backgroundColor: 'var(--editor-bg)', border: '1px solid var(--border)', color: 'var(--fg)', borderRadius: '5px' },
  '.cm-button': { backgroundImage: 'none', backgroundColor: 'var(--hover)', border: '1px solid var(--border)', color: 'var(--fg)', borderRadius: '5px' },
  '.cm-searchMatch': { backgroundColor: 'var(--match)' },
  '.cm-searchMatch.cm-searchMatch-selected': { backgroundColor: 'var(--match-sel)' },
  '.cm-selectionMatch': { backgroundColor: 'var(--accent-soft)' },
  '&.cm-focused .cm-matchingBracket, &.cm-focused .cm-nonmatchingBracket': { backgroundColor: 'var(--bracket)', outline: '1px solid var(--accent)' },
});

const wrapC = new Compartment();
const tabC = new Compartment();
const darkC = new Compartment();
const langC = new Compartment();

const wrapExt = () => (settings.wordWrap ? EditorView.lineWrapping : []);
const tabExt = () => [EditorState.tabSize.of(settings.tabSize), indentUnit.of(' '.repeat(settings.tabSize))];
const darkExt = () => EditorView.darkTheme.of(settings.theme === 'dark');

export function reconfigEffects() {
  return [wrapC.reconfigure(wrapExt()), tabC.reconfigure(tabExt()), darkC.reconfigure(darkExt())];
}

export function createEditor(parent, { onChange, onSelection }) {
  const base = () => [
    lineNumbers(),
    highlightActiveLineGutter(),
    highlightSpecialChars(),
    history(),
    foldGutter(),
    drawSelection(),
    dropCursor(),
    EditorState.allowMultipleSelections.of(true),
    indentOnInput(),
    syntaxHighlighting(highlight),
    bracketMatching(),
    closeBrackets(),
    autocompletion(),
    rectangularSelection(),
    highlightActiveLine(),
    highlightSelectionMatches(),
    keymap.of([
      ...closeBracketsKeymap, ...defaultKeymap, ...searchKeymap,
      ...historyKeymap, ...foldKeymap, ...completionKeymap, indentWithTab,
    ]),
    theme,
  ];

  const view = new EditorView({ parent, state: EditorState.create({ doc: '' }) });

  function makeState(text, path) {
    return EditorState.create({
      doc: text,
      extensions: [
        base(),
        langC.of(langInfo(path)[1]()),
        wrapC.of(wrapExt()),
        tabC.of(tabExt()),
        darkC.of(darkExt()),
        EditorView.updateListener.of((u) => {
          if (u.docChanged) onChange(u);
          if (u.selectionSet || u.docChanged) onSelection(u.state);
        }),
      ],
    });
  }

  return {
    view,
    makeState,
    setState(s) {
      view.setState(s.update({ effects: reconfigEffects() }).state);
      onSelection(view.state);
    },
    reconfigure() { try { view.dispatch({ effects: reconfigEffects() }); } catch { /* blank state */ } },
    setLanguage(path) { view.dispatch({ effects: langC.reconfigure(langInfo(path)[1]()) }); },
    goTo(line, col = 1) {
      const doc = view.state.doc;
      const ln = doc.line(Math.min(Math.max(1, line), doc.lines));
      const pos = Math.min(ln.from + col - 1, ln.to);
      view.dispatch({ selection: { anchor: pos }, effects: EditorView.scrollIntoView(pos, { y: 'center' }) });
      view.focus();
    },
    focus() { view.focus(); },
  };
}
