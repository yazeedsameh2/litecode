import { EditorState, Compartment, StateEffect, StateField, RangeSet } from '@codemirror/state';
import {
  EditorView, keymap, lineNumbers, highlightActiveLineGutter, highlightSpecialChars,
  drawSelection, dropCursor, rectangularSelection, highlightActiveLine, Decoration, gutter, GutterMarker,
} from '@codemirror/view';
import { defaultKeymap, history, historyKeymap, indentWithTab } from '@codemirror/commands';
import {
  syntaxHighlighting, HighlightStyle, indentOnInput, bracketMatching, foldGutter, foldKeymap, indentUnit,
} from '@codemirror/language';
import {
  autocompletion, closeBrackets, closeBracketsKeymap, completionKeymap, snippetCompletion,
} from '@codemirror/autocomplete';
import { searchKeymap, highlightSelectionMatches } from '@codemirror/search';
import { tags as t } from '@lezer/highlight';
import { python } from '@codemirror/lang-python';
import { javascript } from '@codemirror/lang-javascript';
import { html, htmlCompletionSource } from '@codemirror/lang-html';
import { css } from '@codemirror/lang-css';
import { json } from '@codemirror/lang-json';
import { markdown } from '@codemirror/lang-markdown';
import { cpp } from '@codemirror/lang-cpp';
import { java } from '@codemirror/lang-java';
import { rust } from '@codemirror/lang-rust';
import { sql } from '@codemirror/lang-sql';
import { xml } from '@codemirror/lang-xml';
import { yaml } from '@codemirror/lang-yaml';
import { abbreviationTracker } from '@emmetio/codemirror6-plugin';
import { settings } from './state.js';
import { matchHtmlTagPrefix, buildHtmlTagInsertion } from './completion-utils.js';
import { mapDiagnosticsToRanges } from './lsp-diagnostics.js';
import { remapBreakpointLines } from './breakpoint-mapping.js';

const makeSnippets = (items) => items.map(([label, apply, detail, type = 'keyword']) =>
  snippetCompletion(apply, { label, detail, type })
);

const pyCompletions = makeSnippets([
  ['def', 'def ${name}(${args}):\n\t${}', 'Define a function'],
  ['class', 'class ${Name}:\n\tdef __init__(self${}):\n\t\t${}', 'Define a class'],
  ['for', 'for ${item} in ${items}:\n\t${}', 'For loop'],
  ['while', 'while ${condition}:\n\t${}', 'While loop'],
  ['if', 'if ${condition}:\n\t${}', 'If statement'],
  ['elif', 'elif ${condition}:\n\t${}', 'Else-if statement'],
  ['else', 'else:\n\t${}', 'Else statement'],
  ['main', 'if __name__ == "__main__":\n\t${}', 'Main entry point'],
  ['try', 'try:\n\t${}\nexcept ${Exception} as ${error}:\n\t${}', 'Try / except'],
  ['with', 'with open(${path}, ${mode}) as ${file}:\n\t${}', 'Open a file safely'],
  ['print', 'print(${})', 'Print output', 'function'],
  ['lambda', 'lambda ${args}: ${expression}', 'Lambda expression'],
  ['property', '@property\ndef ${name}(self):\n\treturn self._${name}', 'Property getter'],
]);

const jsCompletions = makeSnippets([
  ['function', 'function ${name}(${args}) {\n  ${}\n}', 'Function declaration'],
  ['arrow', 'const ${name} = (${args}) => {\n  ${}\n};', 'Arrow function'],
  ['async', 'async function ${name}(${args}) {\n  ${}\n}', 'Async function'],
  ['try', 'try {\n  ${}\n} catch (${error}) {\n  ${}\n}', 'Try / catch'],
  ['log', 'console.log(${})', 'Console output', 'function'],
  ['im', 'import ${name} from "${module}";', 'ES module import'],
  ['class', 'class ${Name} {\n  constructor(${args}) {\n    ${}\n  }\n}', 'Class declaration'],
  ['promise', 'new Promise((resolve, reject) => {\n  ${}\n})', 'Promise'],
]);

const htmlCompletions = makeSnippets([
  ['html5', '<!doctype html>\n<html lang="en">\n<head>\n  <meta charset="UTF-8">\n  <meta name="viewport" content="width=device-width, initial-scale=1.0">\n  <title>${Title}</title>\n</head>\n<body>\n  ${}\n</body>\n</html>', 'HTML document'],
  ['link:css', '<link rel="stylesheet" href="style.css">', 'Stylesheet link'],
  ['script:src', '<script src="script.js" defer></script>', 'Script file'],
  ['meta:vp', '<meta name="viewport" content="width=device-width, initial-scale=1.0">', 'Viewport meta'],
  ['div.class', '<div class="${className}">${}</div>', 'Div with class'],
  ['button', '<button type="button">${Label}</button>', 'Button element'],
  ['form', '<form action="${}" method="post">\n  ${}\n</form>', 'Form element'],
]);

const cssCompletions = makeSnippets([
  ['flex-center', 'display: flex;\njustify-content: center;\nalign-items: center;', 'Center with flexbox', 'text'],
  ['grid-center', 'display: grid;\nplace-items: center;', 'Center with grid', 'text'],
  ['media', '@media (${condition}) {\n  ${}\n}', 'Media query'],
  ['keyframes', '@keyframes ${name} {\n  from { ${} }\n  to { }\n}', 'Animation keyframes'],
  ['var', 'var(--${name})', 'CSS custom property', 'text'],
]);

const sqlCompletions = makeSnippets([
  ['select', 'SELECT ${columns}\nFROM ${table}\nWHERE ${condition};', 'Select query'],
  ['insert', 'INSERT INTO ${table} (${columns})\nVALUES (${values});', 'Insert query'],
  ['update', 'UPDATE ${table}\nSET ${column} = ${value}\nWHERE ${condition};', 'Update query'],
  ['create-table', 'CREATE TABLE ${table} (\n  id INTEGER PRIMARY KEY,\n  ${column} TEXT NOT NULL\n);', 'Create table'],
]);

const languageWords = {
  py: 'and as assert async await break class continue def del elif else except False finally for from global if import in is lambda None nonlocal not or pass raise return True try while with yield abs all any ascii bin bool breakpoint bytearray bytes callable chr classmethod compile complex delattr dict dir divmod enumerate eval exec filter float format frozenset getattr hasattr hash help hex id input int isinstance issubclass iter len list map max memoryview min next object oct open ord pow print property range repr reversed round set setattr slice sorted staticmethod str sum super tuple type vars zip',
  js: 'async await break case catch class const continue debugger default delete do else export extends false finally for from function get if import in instanceof let new null of return set static super switch this throw true try typeof undefined var void while with yield Array Date Error Function JSON Map Math Number Object Promise Proxy Reflect RegExp Set String Symbol WeakMap WeakSet console document window fetch setTimeout setInterval clearTimeout clearInterval parseInt parseFloat isNaN',
  mjs: 'async await break case catch class const continue debugger default delete do else export extends false finally for from function get if import in instanceof let new null of return set static super switch this throw true try typeof undefined var void while with yield Array Date Error Function JSON Map Math Number Object Promise Proxy Reflect RegExp Set String Symbol WeakMap WeakSet console document window fetch setTimeout setInterval clearTimeout clearInterval parseInt parseFloat isNaN',
  cjs: 'async await break case catch class const continue debugger default delete do else export extends false finally for from function get if import in instanceof let new null of return set static super switch this throw true try typeof undefined var void while with yield Array Date Error Function JSON Map Math Number Object Promise Proxy Reflect RegExp Set String Symbol WeakMap WeakSet console document window fetch setTimeout setInterval clearTimeout clearInterval parseInt parseFloat isNaN',
  ts: 'async await break case catch class const continue debugger default delete do else export extends false finally for from function get if import in instanceof interface let new null of return set static super switch this throw true try type typeof undefined var void while with yield Array Date Error Function JSON Map Math Number Object Promise Proxy Reflect RegExp Set String Symbol WeakMap WeakSet console document window fetch Promise Partial Pick Omit Record Readonly Required',
  tsx: 'async await break case catch class const continue debugger default delete do else export extends false finally for from function get if import in instanceof interface let new null of return set static super switch this throw true try type typeof undefined var void while with yield Array Date Error Function JSON Map Math Number Object Promise Proxy Reflect RegExp Set String Symbol WeakMap WeakSet console document window fetch Promise Partial Pick Omit Record Readonly Required',
  html: 'html head body title meta link script style div span main header footer nav section article aside h1 h2 h3 h4 p a img picture source video audio canvas form label input textarea select option button ul ol li table thead tbody tr th td strong em small pre code blockquote details summary dialog template iframe br hr figure figcaption',
  htm: 'html head body title meta link script style div span main header footer nav section article aside h1 h2 h3 h4 p a img picture source video audio canvas form label input textarea select option button ul ol li table thead tbody tr th td strong em small pre code blockquote details summary dialog template iframe br hr figure figcaption',
  css: 'align-content align-items align-self animation appearance background background-color border border-radius bottom box-shadow box-sizing color column-gap cursor display fill flex flex-basis flex-direction flex-flow flex-grow flex-shrink flex-wrap float font font-family font-size font-style font-weight gap grid grid-area grid-template-columns grid-template-rows height justify-content left letter-spacing line-height margin max-height max-width min-height min-width opacity overflow padding position right text-align text-decoration text-overflow top transform transition user-select vertical-align visibility white-space width z-index',
  json: 'true false null', md: 'TODO NOTE WARNING',
  c: 'auto break case char const continue default do double else enum extern float for goto if inline int long register restrict return short signed sizeof static struct switch typedef union unsigned void volatile while printf scanf malloc calloc realloc free NULL size_t',
  h: 'auto break case char const continue default do double else enum extern float for goto if inline int long register restrict return short signed sizeof static struct switch typedef union unsigned void volatile while printf scanf malloc calloc realloc free NULL size_t',
  cpp: 'alignas alignof and asm auto bool break case catch char class const constexpr const_cast continue decltype default delete do double dynamic_cast else enum explicit export extern false float for friend goto if inline int int long mutable namespace new noexcept not nullptr operator or private protected public register reinterpret_cast return short signed sizeof static static_assert static_cast struct switch template this thread_local throw true try typedef typeid typename union unsigned using virtual void volatile wchar_t while cout cin cerr endl string vector map unordered_map optional unique_ptr shared_ptr make_unique make_shared std',
  cc: 'alignas alignof and asm auto bool break case catch char class const constexpr const_cast continue decltype default delete do double dynamic_cast else enum explicit export extern false float for friend goto if inline int int long mutable namespace new noexcept not nullptr operator or private protected public register reinterpret_cast return short signed sizeof static static_assert static_cast struct switch template this thread_local throw true try typedef typeid typename union unsigned using virtual void volatile wchar_t while cout cin cerr endl string vector map unordered_map optional unique_ptr shared_ptr make_unique make_shared std',
  hpp: 'alignas alignof and asm auto bool break case catch char class const constexpr const_cast continue decltype default delete do double dynamic_cast else enum explicit export extern false float for friend goto if inline int int long mutable namespace new noexcept not nullptr operator or private protected public register reinterpret_cast return short signed sizeof static static_assert static_cast struct switch template this thread_local throw true try typedef typeid typename union unsigned using virtual void volatile wchar_t while cout cin cerr endl string vector map unordered_map optional unique_ptr shared_ptr make_unique make_shared std',
  java: 'abstract assert boolean break byte case catch char class const continue default do double else enum extends final finally float for if implements import instanceof int interface long native new package private protected public return short static strictfp super switch synchronized this throw throws transient try void volatile while String System out println main Scanner List ArrayList Map HashMap Set Optional var',
  rs: 'as async await break const continue crate dyn else enum extern false fn for if impl in let loop match mod move mut pub ref return Self self static struct super trait true type unsafe use where while Vec String Option Result Some None Ok Err println eprintln format vec',
  sql: 'SELECT FROM WHERE JOIN INNER LEFT RIGHT FULL OUTER ON AS AND OR NOT NULL IS IN BETWEEN LIKE ORDER BY GROUP HAVING LIMIT OFFSET INSERT INTO VALUES UPDATE SET DELETE CREATE TABLE ALTER DROP INDEX PRIMARY KEY FOREIGN REFERENCES UNIQUE DEFAULT COUNT SUM AVG MIN MAX DISTINCT CASE WHEN THEN ELSE END ASC DESC',
  xml: 'xml version encoding', svg: 'svg xmlns viewBox width height fill stroke path circle rect line polygon polyline g defs linearGradient radialGradient stop text',
  yml: 'true false null yes no', yaml: 'true false null yes no',
};

function localWordOptions(context) {
  const seen = new Set();
  const options = [];
  const text = context.state.doc.toString();
  const re = /[A-Za-z_$][\w$-]{1,}/g;
  let match;
  let scanned = 0;
  while ((match = re.exec(text)) && scanned++ < 4000 && options.length < 250) {
    const label = match[0];
    if (seen.has(label) || label.length < 2) continue;
    seen.add(label);
    options.push({ label, type: 'variable', detail: 'Current file' });
  }
  return options;
}

function completionExtension(path, getLspCompletions) {
  const ext = (path || '').split('.').pop().toLowerCase();
  const wordSet = languageWords[ext] || (ext === 'jsx' ? languageWords.js : ext === 'tsx' ? languageWords.ts : '');
  const words = wordSet.split(/\s+/).filter(Boolean);
  const plainOptions = words.map((label) => ({ label, type: /^[A-Z]/.test(label) ? 'type' : 'keyword', detail: 'Built-in / language symbol' }));
  const isHtml = ['html', 'htm'].includes(ext);
  // Let CodeMirror's native HTML source handle tags, attributes, and closing tags.
  // The local source below is reserved for snippets and symbols so it cannot
  // shadow the context-aware HTML completion source.
  const list = isHtml ? [...plainOptions, ...htmlCompletions] : [...plainOptions];
  if (ext === 'py') list.push(...pyCompletions);
  if (['js', 'mjs', 'cjs', 'jsx', 'ts', 'tsx'].includes(ext)) list.push(...jsCompletions);
  if (ext === 'css') list.push(...cssCompletions);
  if (ext === 'sql') list.push(...sqlCompletions);

  // Use one predictable source instead of merging two CompletionResults with
  // potentially different `from` offsets. The previous merge could cause the
  // completion popup to open without a reliably filtered/visible option list.
  const source = (context) => {
    const word = context.matchBefore(/[\w$-]+/);
    if (!word && !context.explicit) return null;
    const from = word ? word.from : context.pos;
    const prefix = word ? word.text.toLowerCase() : '';
    const seen = new Set();
    const options = [];
    const candidates = [...list, ...localWordOptions(context)];
    for (const option of candidates) {
      const key = option.label.toLowerCase();
      if (seen.has(key) || (prefix && !key.startsWith(prefix))) continue;
      seen.add(key);
      options.push(option);
      if (options.length >= 250) break;
    }
    if (!options.length) return null;
    return { from, options, validFor: /^[\w$-]*$/ };
  };
  // For HTML tag names, provide an explicit insertion handler. CodeMirror's
  // native HTML source remains enabled for attributes/contextual suggestions,
  // while this source guarantees that accepting a tag also inserts its close.
  const htmlTagSource = isHtml ? (context) => {
    const before = context.state.sliceDoc(Math.max(0, context.pos - 80), context.pos);
    const matched = matchHtmlTagPrefix(before);
    if (!matched) return null;
    const typed = matched.typed;
    const from = context.pos - typed.length;
    const options = ['a','article','aside','body','button','code','div','footer','form','h1','h2','h3','h4','header','html','label','li','main','nav','ol','option','p','script','section','select','span','strong','style','table','tbody','td','textarea','th','thead','title','tr','ul'].filter((tag) => tag.startsWith(typed.toLowerCase())).map((label) => ({
      label, type: 'type', detail: 'HTML element',
      apply(view, completion, start, end) {
        const insertion = buildHtmlTagInsertion(completion.label);
        view.dispatch({ changes: { from: start, to: end, insert: insertion.text }, selection: { anchor: start + insertion.cursorOffset } });
      },
    }));
    return options.length ? { from, options, validFor: /^[A-Za-z][\w:-]*$/ } : null;
  } : null;
  const lspSource = getLspCompletions ? async (context) => {
    try {
      const options = await getLspCompletions(context, path);
      if (!options?.length) return null;
      const word = context.matchBefore(/[\w$]+/);
      return { from: word ? word.from : context.pos, options, validFor: /^[\w$]*$/ };
    } catch (error) {
      console.debug('LSP completion unavailable:', error);
      return null;
    }
  } : null;
  const sources = isHtml ? [htmlTagSource, htmlCompletionSource, lspSource, source] : [lspSource, source];
  return [autocompletion({ override: sources.filter(Boolean), activateOnTyping: true, maxRenderedOptions: 80, icons: true, closeOnBlur: true })];
}

const emmet = () => { try { return abbreviationTracker(); } catch { return []; } };

const LANGS = {
  py: ['Python', () => python()],
  js: ['JavaScript', () => javascript()],
  mjs: ['JavaScript', () => javascript()],
  cjs: ['JavaScript', () => javascript()],
  jsx: ['JavaScript React', () => javascript({ jsx: true })],
  ts: ['TypeScript', () => javascript({ typescript: true })],
  tsx: ['TypeScript React', () => javascript({ typescript: true, jsx: true })],
  html: ['HTML', () => [html(), emmet()]],
  htm: ['HTML', () => [html(), emmet()]],
  css: ['CSS', () => [css(), emmet()]],
  json: ['JSON', () => json()],
  md: ['Markdown', () => markdown()],
  c: ['C', () => cpp()],
  h: ['C', () => cpp()],
  cpp: ['C++', () => cpp()],
  cc: ['C++', () => cpp()],
  hpp: ['C++', () => cpp()],
  java: ['Java', () => java()],
  rs: ['Rust', () => rust()],
  sql: ['SQL', () => sql()],
  xml: ['XML', () => xml()],
  svg: ['SVG', () => xml()],
  yml: ['YAML', () => yaml()],
  yaml: ['YAML', () => yaml()],
};

export function langInfo(path) {
  const ext = (path || '').split('.').pop().toLowerCase();
  return LANGS[ext] || ['Plain Text', () => []];
}

const highlight = HighlightStyle.define([
  { tag: [t.keyword, t.controlKeyword, t.moduleKeyword, t.definitionKeyword], color: 'var(--syn-keyword)' },
  { tag: [t.function(t.variableName), t.function(t.propertyName), t.labelName], color: 'var(--syn-function)' },
  { tag: [t.number, t.bool, t.null, t.atom, t.self], color: 'var(--syn-number)' },
  { tag: [t.string, t.special(t.string), t.regexp, t.character], color: 'var(--syn-string)' },
  { tag: [t.comment, t.lineComment, t.blockComment], color: 'var(--syn-comment)', fontStyle: 'italic' },
  { tag: [t.typeName, t.className, t.namespace], color: 'var(--syn-type)' },
  { tag: [t.operator, t.operatorKeyword], color: 'var(--syn-operator)' },
  { tag: [t.propertyName, t.attributeName], color: 'var(--syn-property)' },
  { tag: [t.tagName], color: 'var(--syn-tag)' },
  { tag: [t.punctuation, t.separator, t.bracket], color: 'var(--syn-punct)' },
  { tag: [t.heading], color: 'var(--syn-function)', fontWeight: 'bold' },
  { tag: [t.emphasis], fontStyle: 'italic' },
  { tag: [t.strong], fontWeight: 'bold' },
  { tag: [t.link, t.url], color: 'var(--syn-operator)', textDecoration: 'underline' },
  { tag: [t.invalid], color: 'var(--syn-invalid)' },
]);

const theme = EditorView.theme({
  '&': { height: '100%', color: 'var(--fg)', backgroundColor: 'var(--editor-bg)' },
  '&.cm-focused': { outline: 'none' },
  '.cm-scroller': { fontFamily: 'var(--mono)', lineHeight: '1.6' },
  // drawSelection() renders a CodeMirror cursor, so keep the native caret hidden
  // and disable blinking on the cursor *layer* (the element CodeMirror animates).
  '.cm-content': { caretColor: 'transparent', padding: '6px 0' },
  '.cm-cursor, .cm-dropCursor': { borderLeftColor: 'var(--caret)', borderLeftWidth: '2px' },
  '&.cm-focused > .cm-scroller > .cm-selectionLayer .cm-selectionBackground, .cm-selectionBackground, .cm-content ::selection':
    { backgroundColor: 'var(--selection) !important' },
  '.cm-gutters': { backgroundColor: 'var(--editor-bg)', color: 'var(--gutter-fg)', border: 'none' },
  '.cm-lineNumbers .cm-gutterElement': { padding: '0 10px 0 14px' },
  '.cm-activeLine': { backgroundColor: 'var(--active-line)' },
  '.cm-activeLineGutter': { backgroundColor: 'transparent', color: 'var(--fg)' },
  '.cm-foldPlaceholder': { backgroundColor: 'var(--hover)', border: 'none', color: 'var(--fg2)' },
  '.cm-tooltip': { backgroundColor: 'var(--panel-bg)', border: '1px solid var(--border)', color: 'var(--fg)', borderRadius: '8px', overflow: 'hidden' },
  '.cm-tooltip-autocomplete > ul': { fontFamily: 'var(--mono)', fontSize: '13px' },
  '.cm-tooltip-autocomplete > ul > li[aria-selected]': { backgroundColor: 'var(--accent-soft)', color: 'var(--fg)' },
  '.cm-panels': { backgroundColor: 'var(--panel-bg)', color: 'var(--fg)', borderColor: 'var(--border)' },
  '.cm-panels input, .cm-panels button': { fontFamily: 'var(--ui)' },
  '.cm-textfield': { backgroundColor: 'var(--editor-bg)', border: '1px solid var(--border)', color: 'var(--fg)', borderRadius: '5px' },
  '.cm-button': { backgroundImage: 'none', backgroundColor: 'var(--hover)', border: '1px solid var(--border)', color: 'var(--fg)', borderRadius: '5px' },
  '.cm-searchMatch': { backgroundColor: 'var(--match)' },
  '.cm-searchMatch.cm-searchMatch-selected': { backgroundColor: 'var(--match-sel)' },
  '.cm-selectionMatch': { backgroundColor: 'var(--accent-soft)' },
  '&.cm-focused .cm-matchingBracket, &.cm-focused .cm-nonmatchingBracket': { backgroundColor: 'var(--bracket)', outline: '1px solid var(--accent)' },
});

const setLspDiagnosticsEffect = StateEffect.define();
const lspDiagnosticsField = StateField.define({
  create: () => Decoration.none,
  update(decorations, tr) {
    decorations = decorations.map(tr.changes);
    for (const effect of tr.effects) {
      if (!effect.is(setLspDiagnosticsEffect)) continue;
      const diagnostics = mapDiagnosticsToRanges(tr.state.doc.toString(), effect.value);
      const ranges = [];
      const lineDecorations = new Map();
      for (const item of diagnostics) {
        const severity = item.severity === 1 ? 'error' : item.severity === 2 ? 'warning' : 'info';
        const title = `${item.message}${item.code ? ` (${item.code})` : ''}`;
        const attrs = { class: `lc-diagnostic-${severity}`, attributes: { title } };
        const previous = lineDecorations.get(item.lineFrom);
        if (!previous || item.severity < previous.severity) lineDecorations.set(item.lineFrom, { severity, severityNumber: item.severity, lineFrom: item.lineFrom });
        if (item.to > item.from) ranges.push(Decoration.mark(attrs).range(item.from, item.to));
      }
      for (const item of lineDecorations.values()) ranges.push(Decoration.line({ class: `lc-diagnostic-line-${item.severity}` }).range(item.lineFrom));
      decorations = Decoration.set(ranges);
    }
    return decorations;
  },
  provide: (field) => EditorView.decorations.from(field),
});

// ───────────── debugger: breakpoint gutter + execution line ─────────────
// Breakpoints are stored as 1-based line numbers per editor state and re-mapped through every edit
// (see breakpoint-mapping.js). The BreakpointStore in main.js remains the source of truth; the
// field only mirrors it for the active file and reports user-driven moves back.
const setBreakpointsEffect = StateEffect.define();   // { lines: number[], unverified: number[] }
const setExecutionEffect = StateEffect.define();     // { line: number, kind: 'stop' | 'frame' | 'exception' } | null

const breakpointField = StateField.define({
  create: () => ({ lines: [], unverified: [] }),
  update(value, tr) {
    for (const effect of tr.effects) {
      if (effect.is(setBreakpointsEffect)) {
        const max = tr.state.doc.lines;
        const lines = [...new Set(effect.value.lines)].filter((n) => Number.isSafeInteger(n) && n >= 1 && n <= max).sort((a, b) => a - b);
        value = { lines, unverified: effect.value.unverified.filter((n) => lines.includes(n)) };
        return value;
      }
    }
    if (!tr.docChanged || !value.lines.length) return value;
    const map = (lines) => remapBreakpointLines(lines, tr.startState.doc, tr.state.doc, (pos, assoc) => tr.changes.mapPos(pos, assoc));
    const lines = map(value.lines);
    // Unverified flags follow the same movement; recompute them one by one.
    const unverified = value.unverified.length ? map(value.unverified).filter((n) => lines.includes(n)) : [];
    return { lines, unverified };
  },
});

const executionField = StateField.define({
  create: () => null,
  update(value, tr) {
    for (const effect of tr.effects) if (effect.is(setExecutionEffect)) return effect.value;
    if (value && tr.docChanged) {
      const [line] = remapBreakpointLines([value.line], tr.startState.doc, tr.state.doc, (pos, assoc) => tr.changes.mapPos(pos, assoc));
      return line ? { ...value, line } : null;
    }
    return value;
  },
  provide: (field) => EditorView.decorations.compute([field], (state) => {
    const exec = state.field(field);
    if (!exec || exec.line < 1 || exec.line > state.doc.lines) return Decoration.none;
    return Decoration.set([Decoration.line({ class: `lc-exec-line lc-exec-${exec.kind}` }).range(state.doc.line(exec.line).from)]);
  }),
});

class DebugLineMarker extends GutterMarker {
  constructor(breakpoint, unverified, exec) { super(); this.breakpoint = breakpoint; this.unverified = unverified; this.exec = exec; }
  eq(other) { return other.breakpoint === this.breakpoint && other.unverified === this.unverified && other.exec === this.exec; }
  toDOM() {
    const box = document.createElement('span');
    box.className = 'lc-dbg-marker';
    if (this.breakpoint) {
      const dot = document.createElement('span');
      dot.className = `lc-bp${this.unverified ? ' lc-bp-unverified' : ''}`;
      dot.title = this.unverified ? 'Breakpoint not bound by the debugger (line has no executable code)' : 'Breakpoint';
      box.appendChild(dot);
    }
    if (this.exec) {
      const arrow = document.createElement('span');
      arrow.className = `lc-exec-arrow lc-exec-arrow-${this.exec}`;
      arrow.textContent = '➤';
      box.appendChild(arrow);
    }
    return box;
  }
}

function debugGutter(onToggle) {
  return gutter({
    class: 'cm-breakpoint-gutter',
    markers: (view) => {
      const bp = view.state.field(breakpointField, false) || { lines: [], unverified: [] };
      const exec = view.state.field(executionField, false);
      const lines = new Set(bp.lines);
      if (exec) lines.add(exec.line);
      const doc = view.state.doc;
      const ranges = [...lines].filter((n) => n >= 1 && n <= doc.lines).sort((a, b) => a - b).map((n) => {
        const marker = new DebugLineMarker(bp.lines.includes(n), bp.unverified.includes(n), exec && exec.line === n ? exec.kind : '');
        return marker.range(doc.line(n).from);
      });
      return RangeSet.of(ranges);
    },
    initialSpacer: () => new DebugLineMarker(true, false, ''),
    domEventHandlers: {
      mousedown(view, block) {
        onToggle(view.state.doc.lineAt(block.from).number);
        return true;
      },
    },
  });
}

const wrapC = new Compartment();
const tabC = new Compartment();
const darkC = new Compartment();
const langC = new Compartment();
const cursorC = new Compartment();

const wrapExt = () => (settings.wordWrap ? EditorView.lineWrapping : []);
const tabExt = () => [EditorState.tabSize.of(settings.tabSize), indentUnit.of(' '.repeat(settings.tabSize))];
const darkExt = () => EditorView.darkTheme.of(settings.theme === 'dark');
const cursorExt = () => EditorView.cursorBlinkRate.of(settings.cursorBlink === false ? 0 : 560);

export function reconfigEffects() {
  return [wrapC.reconfigure(wrapExt()), tabC.reconfigure(tabExt()), darkC.reconfigure(darkExt()), cursorC.reconfigure(cursorExt())];
}

export function createEditor(parent, { onChange, onSelection, getLspCompletions, onToggleBreakpoint = () => {}, onBreakpointsMoved = () => {} }) {
  const base = () => [
    debugGutter((line) => onToggleBreakpoint(line)),
    lineNumbers(),
    highlightActiveLineGutter(),
    highlightSpecialChars(),
    history(),
    foldGutter(),
    drawSelection(),
    dropCursor(),
    EditorState.allowMultipleSelections.of(true),
    indentOnInput(),
    syntaxHighlighting(highlight),
    bracketMatching(),
    closeBrackets(),
    rectangularSelection(),
    highlightActiveLine(),
    highlightSelectionMatches(),
    keymap.of([
      ...closeBracketsKeymap, ...defaultKeymap, ...searchKeymap,
      ...historyKeymap, ...foldKeymap, ...completionKeymap, indentWithTab,
    ]),
    theme,
  ];

  const view = new EditorView({ parent, state: EditorState.create({ doc: '' }) });

  function makeState(text, path) {
    return EditorState.create({
      doc: text,
      extensions: [
        base(),
        lspDiagnosticsField,
        breakpointField,
        executionField,
        langC.of([langInfo(path)[1](), completionExtension(path, getLspCompletions)]),
        wrapC.of(wrapExt()),
        tabC.of(tabExt()),
        darkC.of(darkExt()),
        cursorC.of(cursorExt()),
        EditorView.updateListener.of((u) => {
          if (u.docChanged) {
            onChange(u);
            // Report breakpoints that moved because of the user's edit (not programmatic updates).
            const before = u.startState.field(breakpointField).lines;
            const after = u.state.field(breakpointField).lines;
            const programmatic = u.transactions.some((tr) => tr.effects.some((e) => e.is(setBreakpointsEffect)));
            if (!programmatic && (before.length !== after.length || before.some((n, i) => n !== after[i]))) onBreakpointsMoved(after);
          }
          if (u.selectionSet || u.docChanged) onSelection(u.state);
        }),
      ],
    });
  }

  return {
    view,
    makeState,
    setState(s) {
      view.setState(s.update({ effects: reconfigEffects() }).state);
      onSelection(view.state);
    },
    reconfigure() { try { view.dispatch({ effects: reconfigEffects() }); } catch { /* blank state */ } },
    setLanguage(path) { view.dispatch({ effects: langC.reconfigure([langInfo(path)[1](), completionExtension(path, getLspCompletions)]) }); },
    setDiagnostics(diagnostics = []) { if (!view.state.field(lspDiagnosticsField, false)) return; view.dispatch({ effects: setLspDiagnosticsEffect.of(Array.isArray(diagnostics) ? diagnostics : []) }); },
    /** Mirrors breakpoints for the active file into the gutter (does not notify onBreakpointsMoved). */
    setBreakpoints(lines = [], unverified = []) {
      if (!view.state.field(breakpointField, false)) return;
      view.dispatch({ effects: setBreakpointsEffect.of({ lines, unverified }) });
    },
    /** Highlights the line where execution is paused; pass null to clear. */
    setExecutionLine(line, kind = 'stop') {
      if (!view.state.field(executionField, false)) return;
      view.dispatch({ effects: setExecutionEffect.of(Number.isSafeInteger(line) && line > 0 ? { line, kind } : null) });
    },
    getBreakpointLines() { return [...(view.state.field(breakpointField, false)?.lines || [])]; },
    currentLine() { return view.state.doc.lineAt(view.state.selection.main.head).number; },
    goTo(line, col = 1) {
      const doc = view.state.doc;
      const ln = doc.line(Math.min(Math.max(1, line), doc.lines));
      const pos = Math.min(ln.from + col - 1, ln.to);
      view.dispatch({ selection: { anchor: pos }, effects: EditorView.scrollIntoView(pos, { y: 'center' }) });
      view.focus();
    },
    focus() { view.focus(); },
  };
}
