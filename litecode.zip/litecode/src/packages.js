/** Conservative package-manager command builders. Package names are never treated as shell snippets. */
export const PACKAGE_MANAGERS = Object.freeze({
  npm: Object.freeze({ install: 'npm install', add: (name) => `npm install ${name}` }),
  pnpm: Object.freeze({ install: 'pnpm install', add: (name) => `pnpm add ${name}` }),
  yarn: Object.freeze({ install: 'yarn install', add: (name) => `yarn add ${name}` }),
  bun: Object.freeze({ install: 'bun install', add: (name) => `bun add ${name}` }),
  pip: Object.freeze({ install: 'python -m pip install -r requirements.txt', add: (name) => `python -m pip install ${name}` }),
  uv: Object.freeze({ install: 'uv sync', add: (name) => `uv add ${name}` }),
  cargo: Object.freeze({ install: 'cargo build', add: (name) => `cargo add ${name}` }),
  composer: Object.freeze({ install: 'composer install', add: (name) => `composer require ${name}` }),
  gem: Object.freeze({ install: 'bundle install', add: (name) => `gem install ${name}` }),
});

export function validatePackageName(raw) {
  const name = String(raw ?? '').trim();
  if (!name || name.length > 180 || name.startsWith('-') || name.includes('..') || name.includes('//') || !/^[A-Za-z0-9@._/-]+$/.test(name)) return null;
  if (name.split('/').some((part) => !part || part.startsWith('-'))) return null;
  return name;
}

export function buildPackageCommand(manager, rawName) {
  const spec = PACKAGE_MANAGERS[manager];
  if (!spec) throw new Error('Unsupported package manager');
  const name = validatePackageName(rawName);
  if (!name) throw new Error('Invalid package name');
  return spec.add(name);
}

export function buildDependencyCommand(manager) {
  const spec = PACKAGE_MANAGERS[manager];
  if (!spec) throw new Error('Unsupported package manager');
  return spec.install;
}
