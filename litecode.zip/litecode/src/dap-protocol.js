// Transport-independent helpers for the Debug Adapter Protocol (DAP).
// DAP messages use Content-Length framing over a byte stream, just like LSP,
// but the parser operates on bytes so split UTF-8 characters are safe.
const MAX_FRAME_BYTES = 8 * 1024 * 1024;
const HEADER_END = new Uint8Array([13, 10, 13, 10]);
const decoder = new TextDecoder();
const encoder = new TextEncoder();

function findHeaderEnd(bytes) {
  outer: for (let i = 0; i <= bytes.length - 4; i++) {
    for (let j = 0; j < 4; j++) if (bytes[i + j] !== HEADER_END[j]) continue outer;
    return i;
  }
  return -1;
}

function concatBytes(a, b) {
  const result = new Uint8Array(a.length + b.length);
  result.set(a, 0); result.set(b, a.length);
  return result;
}

export function encodeDapMessage(message) {
  const body = encoder.encode(JSON.stringify(message));
  if (body.length > MAX_FRAME_BYTES) throw new RangeError('DAP message exceeds 8 MB');
  const header = encoder.encode(`Content-Length: ${body.length}\r\n\r\n`);
  return concatBytes(header, body);
}

/** Incremental parser for arbitrary chunks from a DAP adapter's stdout. */
export class DapMessageParser {
  #buffer = new Uint8Array(0);
  #maxFrameBytes;
  constructor({ maxFrameBytes = MAX_FRAME_BYTES } = {}) {
    if (!Number.isSafeInteger(maxFrameBytes) || maxFrameBytes < 1 || maxFrameBytes > MAX_FRAME_BYTES) {
      throw new RangeError('maxFrameBytes must be between 1 byte and 8 MB');
    }
    this.#maxFrameBytes = maxFrameBytes;
  }
  push(chunk) {
    const bytes = chunk instanceof Uint8Array ? chunk : encoder.encode(String(chunk));
    this.#buffer = concatBytes(this.#buffer, bytes);
    const messages = [];
    while (true) {
      const boundary = findHeaderEnd(this.#buffer);
      if (boundary < 0) {
        if (this.#buffer.length > 16 * 1024) throw new Error('DAP header exceeds 16 KB');
        break;
      }
      const headerText = decoder.decode(this.#buffer.slice(0, boundary));
      const lengthHeaders = headerText.split('\r\n').filter((line) => /^content-length\s*:/i.test(line));
      if (lengthHeaders.length !== 1) throw new Error('DAP frame must contain exactly one Content-Length header');
      const rawLength = lengthHeaders[0].slice(lengthHeaders[0].indexOf(':') + 1).trim();
      if (!/^\d+$/.test(rawLength)) throw new Error('DAP Content-Length is invalid');
      const length = Number(rawLength);
      if (!Number.isSafeInteger(length) || length > this.#maxFrameBytes) throw new Error('DAP Content-Length exceeds configured limit');
      const bodyStart = boundary + 4;
      const frameEnd = bodyStart + length;
      if (this.#buffer.length < frameEnd) break;
      const body = decoder.decode(this.#buffer.slice(bodyStart, frameEnd));
      let message;
      try { message = JSON.parse(body); } catch { throw new Error('DAP frame body is not valid JSON'); }
      if (!message || typeof message !== 'object' || Array.isArray(message) || message.type == null) {
        throw new Error('DAP message must be a JSON object with a type');
      }
      messages.push(message);
      this.#buffer = this.#buffer.slice(frameEnd);
    }
    return messages;
  }
  reset() { this.#buffer = new Uint8Array(0); }
  get bufferedBytes() { return this.#buffer.length; }
}

export function createDapRequest(command, args = {}, seq = 1) {
  if (typeof command !== 'string' || !/^[A-Za-z][A-Za-z0-9-]{0,99}$/.test(command)) throw new TypeError('Invalid DAP command');
  if (!Number.isSafeInteger(seq) || seq < 1) throw new RangeError('DAP sequence must be a positive safe integer');
  if (!args || typeof args !== 'object' || Array.isArray(args)) throw new TypeError('DAP arguments must be an object');
  return { seq, type: 'request', command, arguments: args };
}

export function isDapResponse(message, requestSeq) {
  return !!message && message.type === 'response' && Number.isSafeInteger(message.request_seq) &&
    message.request_seq === requestSeq && typeof message.success === 'boolean';
}

export function normalizeDapBreakpoint(breakpoint) {
  if (!breakpoint || typeof breakpoint !== 'object') return null;
  const line = Number(breakpoint.line);
  const column = breakpoint.column == null ? null : Number(breakpoint.column);
  if (!Number.isSafeInteger(line) || line < 1) return null;
  if (column !== null && (!Number.isSafeInteger(column) || column < 1)) return null;
  return {
    verified: breakpoint.verified === true,
    line,
    ...(column === null ? {} : { column }),
    ...(typeof breakpoint.message === 'string' ? { message: breakpoint.message.slice(0, 1000) } : {}),
    ...(typeof breakpoint.id === 'number' && Number.isSafeInteger(breakpoint.id) ? { id: breakpoint.id } : {}),
  };
}
