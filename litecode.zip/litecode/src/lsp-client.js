import { invoke } from '@tauri-apps/api/core';
import { listen } from '@tauri-apps/api/event';
import { lspLanguageId, initializeParams, normalizeCompletionItems } from './lsp-protocol.js';

const fileUri = (path) => {
  let p = String(path).replace(/\\/g, '/');
  if (/^[A-Za-z]:\//.test(p)) p = `/${p}`;
  return `file://${encodeURI(p).replace(/#/g, '%23').replace(/\?/g, '%3F')}`;
};

export class LspClient {
  constructor({ root, onDiagnostics = () => {}, onStatus = () => {} }) {
    this.root = root;
    this.onDiagnostics = onDiagnostics;
    this.onStatus = onStatus;
    this.servers = new Map();
    this.nextRequestId = 1;
    this.disposers = [];
    this.closed = false;
  }

  async start(language) {
    if (this.servers.has(language)) return this.servers.get(language);
    const id = await invoke('lsp_start', { language, root: this.root });
    const server = { id, language, pending: new Map(), opened: new Map(), ready: false };
    this.servers.set(language, server);
    const unlisten = await listen(`lsp-message-${id}`, (event) => this.#receive(server, event.payload));
    this.disposers.push(unlisten);
    const unlistenErr = await listen(`lsp-stderr-${id}`, (event) => {
      const message = String(event.payload || '').trim();
      if (message) this.onStatus(`${language} server: ${message.slice(0, 180)}`, 'info');
    });
    this.disposers.push(unlistenErr);
    try {
      const result = await this.request(server, 'initialize', initializeParams(fileUri(this.root)));
      await this.notify(server, 'initialized', {});
      server.ready = true;
      server.capabilities = result?.capabilities || {};
      this.onStatus(`${language} language server connected`, 'ok');
      return server;
    } catch (error) {
      await this.stop(language);
      throw error;
    }
  }

  #receive(server, message) {
    if (message && Object.hasOwn(message, 'id') && (Object.hasOwn(message, 'result') || Object.hasOwn(message, 'error'))) {
      const pending = server.pending.get(message.id);
      if (!pending) return;
      server.pending.delete(message.id);
      if (message.error) pending.reject(new Error(message.error.message || 'Language server request failed'));
      else pending.resolve(message.result);
      return;
    }
    if (message?.method === 'textDocument/publishDiagnostics') {
      this.onDiagnostics(message.params?.uri, message.params?.diagnostics || [], server.language);
      return;
    }
    if (message?.method === 'window/logMessage' || message?.method === 'window/showMessage') {
      const p = message.params || {};
      this.onStatus(String(p.message || ''), p.type === 1 ? 'err' : 'info');
      return;
    }
    // LSP servers can issue requests to the client (not just notifications).
    // Reply to common capability/configuration requests so the server doesn't hang.
    if (message?.method && Object.hasOwn(message, 'id')) {
      this.#handleServerRequest(server, message).catch((error) => console.warn('LSP client-request response failed:', error));
    }
  }

  async #handleServerRequest(server, message) {
    let result = null;
    switch (message.method) {
      case 'workspace/configuration':
        result = (message.params?.items || []).map(() => null);
        break;
      case 'workspace/workspaceFolders':
        result = [{ uri: fileUri(this.root), name: this.root.split(/[\\/]/).filter(Boolean).pop() || 'workspace' }];
        break;
      case 'workspace/applyEdit':
        result = { applied: false, failureReason: 'Workspace edits are not yet supported by LiteCode.' };
        break;
      case 'client/registerCapability':
      case 'client/unregisterCapability':
      case 'window/workDoneProgress/create':
        result = null;
        break;
      default:
        await invoke('lsp_send', { id: server.id, message: { jsonrpc: '2.0', id: message.id, error: { code: -32601, message: `Client request not supported: ${message.method}` } } });
        return;
    }
    await invoke('lsp_send', { id: server.id, message: { jsonrpc: '2.0', id: message.id, result } });
  }

  async request(server, method, params = {}) {
    const id = this.nextRequestId++;
    const response = new Promise((resolve, reject) => {
      const timer = setTimeout(() => {
        server.pending.delete(id);
        reject(new Error(`Language server timed out: ${method}`));
      }, 15000);
      server.pending.set(id, {
        resolve: (value) => { clearTimeout(timer); resolve(value); },
        reject: (error) => { clearTimeout(timer); reject(error); },
      });
    });
    await invoke('lsp_send', { id: server.id, message: { jsonrpc: '2.0', id, method, params } });
    return response;
  }

  notify(server, method, params = {}) {
    return invoke('lsp_send', { id: server.id, message: { jsonrpc: '2.0', method, params } });
  }

  async openDocument(path, text, version = 1) {
    const language = lspLanguageId(path);
    if (!language || !this.root || !path) return false;
    const serverKey = language === 'javascriptreact' ? 'javascript' : language;
    let server = this.servers.get(serverKey);
    if (!server) server = await this.start(serverKey);
    if (!server.ready) return false;
    const uri = fileUri(path);
    server.opened.set(uri, { path, version, text });
    await this.notify(server, 'textDocument/didOpen', { textDocument: { uri, languageId: language, version, text } });
    return true;
  }

  async changeDocument(path, text, version) {
    const language = lspLanguageId(path);
    if (!language) return;
    const server = this.servers.get(language === 'javascriptreact' ? 'javascript' : language);
    if (!server?.ready) return;
    const uri = fileUri(path);
    const current = server.opened.get(uri);
    if (!current) return this.openDocument(path, text, version);
    current.version = version;
    current.text = text;
    await this.notify(server, 'textDocument/didChange', { textDocument: { uri, version }, contentChanges: [{ text }] });
  }

  async closeDocument(path) {
    const language = lspLanguageId(path);
    if (!language) return;
    const server = this.servers.get(language === 'javascriptreact' ? 'javascript' : language);
    if (!server?.ready) return;
    const uri = fileUri(path);
    if (server.opened.has(uri)) {
      server.opened.delete(uri);
      await this.notify(server, 'textDocument/didClose', { textDocument: { uri } }).catch(() => {});
    }
  }

  #serverForPath(path) {
    const language = lspLanguageId(path);
    if (!language) return null;
    const key = language === 'javascriptreact' ? 'javascript' : language;
    const server = this.servers.get(key);
    return server?.ready ? { server, language } : null;
  }

  #position(path, state, pos) {
    const line = state.doc.lineAt(pos);
    return { uri: fileUri(path), position: { line: line.number - 1, character: pos - line.from } };
  }

  async complete(path, state, pos) {
    const target = this.#serverForPath(path);
    if (!target) return null;
    const params = this.#position(path, state, pos);
    const result = await this.request(target.server, 'textDocument/completion', params);
    return normalizeCompletionItems(result);
  }

  async hover(path, state, pos) {
    const target = this.#serverForPath(path);
    if (!target) throw new Error('Start the language server first.');
    const result = await this.request(target.server, 'textDocument/hover', this.#position(path, state, pos));
    const contents = result?.contents;
    if (!contents) return null;
    if (typeof contents === 'string') return contents;
    if (Array.isArray(contents)) return contents.map((part) => typeof part === 'string' ? part : part.value || '').filter(Boolean).join('\n\n');
    return contents.value || '';
  }

  async definition(path, state, pos) {
    const target = this.#serverForPath(path);
    if (!target) throw new Error('Start the language server first.');
    const result = await this.request(target.server, 'textDocument/definition', this.#position(path, state, pos));
    const location = Array.isArray(result) ? result[0] : result;
    if (!location?.uri || !location.range?.start) return null;
    return { uri: location.uri, line: location.range.start.line + 1, col: location.range.start.character + 1 };
  }

  async formatDocument(path, state, options = {}) {
    const target = this.#serverForPath(path);
    if (!target) throw new Error('Start a language server first.');
    const params = {
      textDocument: { uri: fileUri(path) },
      options: { tabSize: Math.max(1, Math.min(8, Number(options.tabSize) || 4)), insertSpaces: options.insertSpaces !== false },
    };
    const result = await this.request(target.server, 'textDocument/formatting', params);
    if (result == null) return [];
    if (!Array.isArray(result)) throw new Error('The language server returned an invalid formatting response.');
    return result;
  }

  async codeActions(path, state, pos, diagnostics = []) {
    const target = this.#serverForPath(path);
    if (!target) throw new Error('Start a language server first.');
    const params = this.#position(path, state, pos);
    const line = state.doc.lineAt(pos);
    params.range = { start: params.position, end: { line: line.number - 1, character: line.length } };
    params.context = { diagnostics: Array.isArray(diagnostics) ? diagnostics : [], only: ['quickfix', 'refactor', 'source'], triggerKind: 1 };
    const result = await this.request(target.server, 'textDocument/codeAction', params);
    return (Array.isArray(result) ? result : []).filter((item) => item && (item.title || item.command?.title)).slice(0, 30);
  }

  async executeCommand(path, command) {
    const target = this.#serverForPath(path);
    if (!target) throw new Error('Start a language server first.');
    if (!command?.command) throw new Error('The language server returned an invalid command.');
    return this.request(target.server, 'workspace/executeCommand', { command: command.command, arguments: command.arguments || [] });
  }

  async stop(language) {
    const server = this.servers.get(language);
    if (!server) return;
    this.servers.delete(language);
    for (const [id, pending] of server.pending) pending.reject(new Error('Language server stopped'));
    server.pending.clear();
    try { await invoke('lsp_stop', { id: server.id }); } catch { /* process may already have exited */ }
  }

  async dispose() {
    this.closed = true;
    for (const dispose of this.disposers.splice(0)) { try { dispose(); } catch { /* ignore */ } }
    await Promise.all([...this.servers.keys()].map((language) => this.stop(language)));
  }
}

export { fileUri };
