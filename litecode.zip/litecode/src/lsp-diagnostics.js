// Convert LSP line/character ranges to clamped UTF-16 document offsets.
// JavaScript string offsets and CodeMirror offsets are both UTF-16 code units.
export function mapDiagnosticsToRanges(text, diagnostics = []) {
  const source = String(text ?? '');
  const lines = source.split('\n');
  const starts = [];
  let offset = 0;
  for (const line of lines) { starts.push(offset); offset += line.length + 1; }
  const clamp = (value, min, max) => Math.min(max, Math.max(min, Number.isFinite(value) ? value : min));
  const result = [];
  for (const diagnostic of Array.isArray(diagnostics) ? diagnostics : []) {
    const range = diagnostic?.range;
    if (!range?.start || !Number.isFinite(range.start.line)) continue;
    const startLine = clamp(Math.trunc(range.start.line), 0, lines.length - 1);
    const startChar = clamp(Math.trunc(range.start.character || 0), 0, lines[startLine].length);
    const from = starts[startLine] + startChar;
    let to = from;
    if (range.end && Number.isFinite(range.end.line)) {
      const endLine = clamp(Math.trunc(range.end.line), startLine, lines.length - 1);
      const endChar = clamp(Math.trunc(range.end.character || 0), 0, lines[endLine].length);
      to = Math.max(from, starts[endLine] + endChar);
    }
    result.push({ from, to, lineFrom: starts[startLine], severity: [1,2,3,4].includes(diagnostic.severity) ? diagnostic.severity : 3, message: String(diagnostic.message || 'Language diagnostic').slice(0, 1000), code: diagnostic.code == null ? '' : String(diagnostic.code).slice(0, 80) });
  }
  return result;
}
