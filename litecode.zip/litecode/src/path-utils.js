/** Path-prefix helpers shared by project operations and their unit tests. */
export function pathMatchesPrefix(path, prefix, caseInsensitive = false) {
  if (typeof path !== 'string' || typeof prefix !== 'string' || !path || !prefix) return false;
  const normalize = (value) => value.replace(/\\/g, '/').replace(/\/+$/, '');
  const candidate = normalize(path);
  const base = normalize(prefix);
  const left = caseInsensitive ? candidate.toLowerCase() : candidate;
  const right = caseInsensitive ? base.toLowerCase() : base;
  return left === right || left.startsWith(`${right}/`);
}

/** Replace a file/folder path prefix without matching sibling names like `src-old`. */
export function replacePathPrefix(path, from, to, caseInsensitive = false) {
  if (!pathMatchesPrefix(path, from, caseInsensitive)) return path;
  if (path.length === from.length) return to;
  return to + path.slice(from.length);
}
