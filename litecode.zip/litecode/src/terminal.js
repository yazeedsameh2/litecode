import { Terminal } from '@xterm/xterm';
import { FitAddon } from '@xterm/addon-fit';
import '@xterm/xterm/css/xterm.css';
import { invoke } from '@tauri-apps/api/core';
import { listen } from '@tauri-apps/api/event';
import { el, esc } from './ui.js';
import { settings } from './state.js';

const terms = new Map(); // id -> { term, fit, host, tab }
const pending = new Map(); // output that arrived before the tab was registered
let tabsEl, bodyEl, active = null, counter = 0, onEmpty = () => {};

const DARK = ['#2a303b', '#ef6a6a', '#7ed19b', '#f0cf84', '#8fc1ff', '#c3a6ff', '#7fd6e6', '#d8dee9',
  '#536074', '#ff8a8a', '#9be8b4', '#ffe29a', '#aed2ff', '#d6c1ff', '#a0e8f4', '#ffffff'];
const LIGHT = ['#2a303b', '#c0324a', '#2f7d3a', '#a9690a', '#1f5fbf', '#7a3fd1', '#0e7a8c', '#5b6270',
  '#6b7384', '#d6264a', '#2f8f55', '#b97a14', '#3a6fd0', '#8d54e0', '#1a8ea1', '#2a303b'];

function xtermTheme() {
  const cs = getComputedStyle(document.documentElement);
  const v = (n) => cs.getPropertyValue(n).trim();
  const p = document.documentElement.dataset.theme === 'light' ? LIGHT : DARK;
  return {
    background: v('--term-bg'), foreground: v('--fg'), cursor: v('--caret'),
    selectionBackground: v('--selection'),
    black: p[0], red: p[1], green: p[2], yellow: p[3], blue: p[4], magenta: p[5], cyan: p[6], white: p[7],
    brightBlack: p[8], brightRed: p[9], brightGreen: p[10], brightYellow: p[11],
    brightBlue: p[12], brightMagenta: p[13], brightCyan: p[14], brightWhite: p[15],
  };
}

const monoFamily = () => getComputedStyle(document.documentElement).getPropertyValue('--mono');

export function fitActive() {
  const t = terms.get(active);
  if (!t || !t.host.offsetParent) return;
  try { t.fit.fit(); } catch { /* hidden */ }
}

export async function initTerminals({ tabs, body, onAllClosed }) {
  tabsEl = tabs;
  bodyEl = body;
  onEmpty = onAllClosed || (() => {});
  await listen('pty-data', (ev) => {
    const { id, data } = ev.payload;
    const t = terms.get(id);
    if (t) t.term.write(data);
    else pending.set(id, (pending.get(id) || '') + data);
  });
  await listen('pty-exit', (ev) => closeTerminal(ev.payload));
  let raf = 0;
  new ResizeObserver(() => { cancelAnimationFrame(raf); raf = requestAnimationFrame(fitActive); }).observe(bodyEl);
}

export const hasTerminals = () => terms.size > 0;

export async function newTerminal(cwd) {
  const host = el('div', 'term');
  bodyEl.appendChild(host);
  const term = new Terminal({
    fontFamily: monoFamily(), fontSize: Math.max(10, settings.fontSize - 1),
    cursorBlink: true, scrollback: 3000, theme: xtermTheme(), allowProposedApi: false,
  });
  const fit = new FitAddon();
  term.loadAddon(fit);
  term.open(host);
  for (const t of terms.values()) t.host.style.display = 'none';
  try { fit.fit(); } catch { /* not visible yet */ }

  const id = await invoke('pty_spawn', { cwd: cwd || null, cols: term.cols || 80, rows: term.rows || 24 });
  const tab = el('div', 'ptab');
  tab.innerHTML = `<span>Terminal ${++counter}</span><span class="x">✕</span>`;
  tab.onclick = (e) => { if (e.target.classList.contains('x')) closeTerminal(id); else activate(id); };
  tabsEl.appendChild(tab);

  terms.set(id, { term, fit, host, tab });
  term.onData((d) => invoke('pty_write', { id, data: d }));
  term.onResize(({ cols, rows }) => invoke('pty_resize', { id, cols, rows }));
  if (pending.has(id)) { term.write(pending.get(id)); pending.delete(id); }
  activate(id);
  return id;
}

export function activate(id) {
  active = id;
  for (const [k, t] of terms) {
    const on = k === id;
    t.host.style.display = on ? 'block' : 'none';
    t.tab.classList.toggle('active', on);
  }
  requestAnimationFrame(() => { fitActive(); terms.get(id)?.term.focus(); });
}

export function closeTerminal(id = active) {
  const t = terms.get(id);
  if (!t) return;
  invoke('pty_kill', { id });
  t.term.dispose();
  t.host.remove();
  t.tab.remove();
  terms.delete(id);
  if (active === id) {
    active = null;
    const next = [...terms.keys()].pop();
    if (next != null) activate(next);
  }
  if (!terms.size) onEmpty();
}

export async function runInTerminal(cmd, cwd) {
  if (active == null || !terms.has(active)) await newTerminal(cwd);
  await invoke('pty_write', { id: active, data: cmd + '\r' });
  terms.get(active)?.term.focus();
}

export function stopActive() {
  if (active != null) invoke('pty_write', { id: active, data: '\x03' });
}

export function focusActive() { terms.get(active)?.term.focus(); }

export function restyle() {
  for (const t of terms.values()) {
    t.term.options.theme = xtermTheme();
    t.term.options.fontSize = Math.max(10, settings.fontSize - 1);
  }
  fitActive();
}
