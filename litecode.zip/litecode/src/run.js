export const sepOf = (p) => (p.includes('\\') && !p.includes('/') ? '\\' : '/');
export function dirname(p) {
  const i = Math.max(p.lastIndexOf('/'), p.lastIndexOf('\\'));
  return i < 0 ? '' : p.slice(0, i);
}
export function basename(p) {
  return p.slice(Math.max(p.lastIndexOf('/'), p.lastIndexOf('\\')) + 1);
}
export function joinPath(base, rel, os) {
  const sep = os === 'windows' ? '\\' : '/';
  const r = os === 'windows' ? rel.replace(/\//g, '\\') : rel;
  return base.replace(/[\\/]+$/, '') + sep + r.replace(/^[\\/]+/, '');
}

// Commands are sent to an interactive shell. Quote every user-controlled path
// as a single argument rather than relying on paths being free of spaces.
const posixQuote = (s) => `'${String(s).replace(/'/g, `'\\''`)}'`;
const cmdQuote = (s) => `"${String(s).replace(/"/g, '""')}"`;

// Returns { cmd } to type in the terminal, { live: true } for web files, or null.
export function buildRun(path, os, python) {
  const win = os === 'windows';
  const f = basename(path);
  const dir = dirname(path);
  const ext = f.includes('.') ? f.split('.').pop().toLowerCase() : '';
  const name = f.replace(/\.[^.]+$/, '');
  const q = win ? cmdQuote : posixQuote;
  const exe = win ? q(`${name}.exe`) : `./${q(name)}`;
  const py = python || (win ? 'python' : 'python3');

  if (ext === 'html' || ext === 'htm') return { live: true };

  const map = {
    py: `${q(py)} ${q(f)}`,
    js: `node ${q(f)}`,
    mjs: `node ${q(f)}`,
    cjs: `node ${q(f)}`,
    java: `java ${q(f)}`,
    c: `gcc ${q(f)} -o ${q(name)} && ${exe}`,
    cpp: `g++ ${q(f)} -o ${q(name)} && ${exe}`,
    cc: `g++ ${q(f)} -o ${q(name)} && ${exe}`,
    rs: `rustc ${q(f)} -o ${q(name)} && ${exe}`,
    go: `go run ${q(f)}`,
    php: `php ${q(f)}`,
    rb: `ruby ${q(f)}`,
    lua: `lua ${q(f)}`,
    pl: `perl ${q(f)}`,
    sh: `bash ${q(f)}`,
    bat: `call ${q(f)}`,
    cmd: `call ${q(f)}`,
    ps1: `powershell -NoProfile -ExecutionPolicy Bypass -File ${q(f)}`,
  };
  const body = map[ext];
  if (!body) return null;
  const cd = win ? `cd /d ${q(dir || '.')}` : `cd ${q(dir || '.')}`;
  const clear = win ? 'cls' : 'clear';
  return { cmd: `${cd} && ${clear} && ${body}` };
}
