// Helpers for showing Python errors and jumping to their source location.
const TRACE_RE = /File "([^"\r\n]+)", line (\d+)/g;
const PYTEST_RE = /((?:[A-Za-z]:[\\/])?[^\s:"'()<>|*?]+\.py):(\d+)(?::(\d+))?/g;

const isOpenable = (path) => !!path && !path.startsWith('<') && !/^\w+:\/\//.test(path);
export const isAbsolutePath = (path) => /^([A-Za-z]:[\\/]|\\\\|\/)/.test(path);

/** Finds clickable error locations in one line of terminal/console text. */
export function findPythonErrorLinks(text) {
  const links = [];
  const taken = [];
  const overlaps = (s, e) => taken.some(([a, b]) => s < b && e > a);
  const add = (start, end, path, line, column) => {
    if (!isOpenable(path) || overlaps(start, end)) return;
    const n = Number(line);
    if (!Number.isSafeInteger(n) || n < 1) return;
    taken.push([start, end]);
    links.push({ start, end, path, line: n, column: column ? Number(column) : 1 });
  };
  for (const m of String(text).matchAll(TRACE_RE)) add(m.index, m.index + m[0].length, m[1], m[2]);
  for (const m of String(text).matchAll(PYTEST_RE)) add(m.index, m.index + m[0].length, m[1], m[2], m[3]);
  return links.sort((a, b) => a.start - b.start);
}

/** Splits text into plain and link segments, for rendering in the debug console. */
export function splitErrorSegments(text) {
  const segments = [];
  for (const line of String(text).split(/(?<=\n)/)) {
    let at = 0;
    for (const link of findPythonErrorLinks(line)) {
      if (link.start > at) segments.push({ text: line.slice(at, link.start) });
      segments.push({ text: line.slice(link.start, link.end), link });
      at = link.end;
    }
    if (at < line.length) segments.push({ text: line.slice(at) });
  }
  return segments;
}

/** Resolves a path found in an error message against the run directory. */
export function resolveErrorPath(path, cwd) {
  if (!isOpenable(path)) return null;
  if (isAbsolutePath(path)) return path;
  if (!cwd) return null;
  const sep = cwd.includes('\\') && !cwd.includes('/') ? '\\' : '/';
  return cwd.replace(/[\\/]+$/, '') + sep + path.replace(/^\.[\\/]/, '').replace(/[\\/]/g, sep);
}

/** Turns adapter stderr/exit information into an actionable message. */
export function describeAdapterFailure(stderr, python) {
  const text = String(stderr || '');
  const exe = python || 'python';
  if (/No module named ['"]?debugpy/i.test(text)) {
    return `debugpy is not installed for "${exe}". Install it with: ${exe} -m pip install debugpy`;
  }
  if (/not recognized as an internal or external command|command not found|No such file or directory/i.test(text)) {
    return `Could not run "${exe}". Check the Python command in Settings.`;
  }
  return text.trim().split(/\r?\n/).slice(-3).join(' ').slice(0, 300);
}

/** Formats a DAP exceptionInfo response as console text. */
export function formatExceptionInfo(info) {
  if (!info || typeof info !== 'object') return '';
  const name = info.details?.typeName || info.exceptionId || 'Exception';
  const message = info.description || info.details?.message || '';
  const lines = [`${name}${message ? `: ${message}` : ''}`];
  if (typeof info.details?.stackTrace === 'string' && info.details.stackTrace.trim()) lines.push(info.details.stackTrace.trimEnd());
  return lines.join('\n') + '\n';
}
