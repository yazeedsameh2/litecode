import { invoke } from '@tauri-apps/api/core';
import { el, esc, showMenu } from './ui.js';

const COLORS = {
  py: '#6aa4d8', js: '#e6c35c', mjs: '#e6c35c', ts: '#4a8fe0', jsx: '#5cc8e6', tsx: '#5cc8e6',
  html: '#e8825f', htm: '#e8825f', css: '#5aa9ee', scss: '#d36fa6', json: '#c9b46a', md: '#8da2bb',
  c: '#7a9fd1', cpp: '#7a9fd1', h: '#7a9fd1', java: '#d9884a', rs: '#d98a6a', sql: '#c68ad9',
  yml: '#b6c36a', yaml: '#b6c36a', xml: '#8fbf8f', svg: '#e0a35c', txt: '#8792a3', sh: '#8fcf8f',
};
export const colorFor = (name) => COLORS[(name.split('.').pop() || '').toLowerCase()] || '#8792a3';

export function createTree(container, h) {
  let root = null;
  let active = null;
  let selDir = null;
  const open = new Set();

  async function nodes(dir, depth) {
    let entries = [];
    try { entries = await invoke('list_dir', { path: dir }); } catch { /* unreadable folder */ }
    const frag = document.createDocumentFragment();
    for (const en of entries) {
      const isOpen = en.is_dir && open.has(en.path);
      const row = el('div', 'trow' + (en.path === active ? ' active' : ''));
      row.dataset.path = en.path;
      row.style.paddingLeft = 8 + depth * 14 + 'px';
      row.innerHTML =
        `<span class="arr">${en.is_dir ? (isOpen ? '▾' : '▸') : ''}</span>` +
        (en.is_dir ? '<span class="fdir"></span>' : `<span class="fi" style="background:${colorFor(en.name)}"></span>`) +
        `<span class="tn">${esc(en.name)}</span>`;
      row.onclick = async () => {
        if (en.is_dir) {
          selDir = en.path;
          if (open.has(en.path)) open.delete(en.path); else open.add(en.path);
          h.onChange?.();
          await refresh();
        } else {
          selDir = dirOf(en.path);
          h.onOpen(en.path);
        }
      };
      row.oncontextmenu = (e) => { e.preventDefault(); menu(e, en); };
      frag.appendChild(row);
      if (isOpen) frag.appendChild(await nodes(en.path, depth + 1));
    }
    return frag;
  }

  const dirOf = (p) => p.slice(0, Math.max(p.lastIndexOf('/'), p.lastIndexOf('\\')));

  function menu(e, en) {
    const dir = en.is_dir ? en.path : dirOf(en.path);
    showMenu(e.clientX, e.clientY, [
      { label: 'New File…', run: () => h.onNewFile(dir) },
      { label: 'New Folder…', run: () => h.onNewFolder(dir) },
      '-',
      { label: 'Open Terminal Here', run: () => h.onTerminalHere(dir) },
      '-',
      { label: 'Rename…', run: () => h.onRename(en.path) },
      { label: 'Delete', run: () => h.onDelete(en.path, en.is_dir) },
    ]);
  }

  async function refresh() {
    const top = container.scrollTop;
    container.innerHTML = '';
    if (!root) {
      const d = el('div', 'empty', 'No folder opened yet.<br><br>');
      const b = el('button', 'primary', 'Open folder');
      b.onclick = () => h.onOpenFolder();
      d.appendChild(b);
      container.appendChild(d);
      return;
    }
    container.appendChild(await nodes(root, 0));
    container.scrollTop = top;
  }

  return {
    refresh,
    setRoot(p) { root = p; selDir = p; open.clear(); return refresh(); },
    getRoot: () => root,
    selectedDir: () => selDir || root,
    setActive(p) {
      active = p;
      for (const r of container.querySelectorAll('.trow')) r.classList.toggle('active', r.dataset.path === p);
    },
    expanded: () => [...open],
    setExpanded(list) { open.clear(); (list || []).forEach((x) => open.add(x)); },
    collapseAll() { open.clear(); return refresh(); },
  };
}
