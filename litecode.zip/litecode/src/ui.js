export const $ = (s, r = document) => r.querySelector(s);
export const el = (tag, cls, html) => {
  const e = document.createElement(tag);
  if (cls) e.className = cls;
  if (html != null) e.innerHTML = html;
  return e;
};
export const esc = (s) =>
  String(s).replace(/[&<>"]/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));

const closed = () => document.dispatchEvent(new Event('modal-closed'));

// ── toast ──
let toastTimer;
export function toast(msg, kind = '') {
  const t = $('#toast');
  t.textContent = msg;
  t.className = 'show ' + kind;
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => (t.className = ''), kind === 'err' ? 4500 : 2200);
}

// ── context menu ──
export function showMenu(x, y, items) {
  const m = $('#ctxmenu');
  m.innerHTML = '';
  for (const it of items) {
    if (it === '-') { m.appendChild(el('div', 'sep')); continue; }
    const d = el('div', 'item', esc(it.label));
    d.onclick = () => { hideMenu(); it.run(); };
    m.appendChild(d);
  }
  m.style.left = '0px';
  m.style.top = '0px';
  m.style.display = 'block';
  const r = m.getBoundingClientRect();
  m.style.left = Math.max(4, Math.min(x, innerWidth - r.width - 4)) + 'px';
  m.style.top = Math.max(4, Math.min(y, innerHeight - r.height - 4)) + 'px';
}
export function hideMenu() { $('#ctxmenu').style.display = 'none'; }
addEventListener('mousedown', (e) => { if (!e.target.closest('#ctxmenu')) hideMenu(); });

// ── modal: input ──
export function askInput(title, value = '', hint = '') {
  return new Promise((res) => {
    const o = $('#modal');
    o.innerHTML = `<div class="box"><div class="mt">${esc(title)}</div><input class="mi" spellcheck="false" /><div class="mh">${esc(hint)}</div></div>`;
    o.style.display = 'flex';
    const i = $('.mi', o);
    i.value = value;
    i.focus();
    i.select();
    const done = (v) => { o.style.display = 'none'; o.innerHTML = ''; closed(); res(v); };
    i.onkeydown = (e) => {
      if (e.key === 'Enter') done(i.value.trim() || null);
      else if (e.key === 'Escape') done(null);
      e.stopPropagation();
    };
    o.onmousedown = (e) => { if (e.target === o) done(null); };
  });
}

// ── modal: choice buttons → resolves with the index (or -1 on Esc) ──
export function askChoice(message, buttons, danger = -1) {
  return new Promise((res) => {
    const o = $('#modal');
    o.innerHTML = `<div class="box"><div class="mt">${esc(message)}</div><div class="btns"></div></div>`;
    o.style.display = 'flex';
    const bar = $('.btns', o);
    const done = (v) => { o.style.display = 'none'; o.innerHTML = ''; closed(); res(v); };
    buttons.forEach((label, i) => {
      const b = el('button', i === danger ? 'danger' : i === 0 ? 'main' : '', esc(label));
      b.onclick = () => done(i);
      bar.appendChild(b);
    });
    bar.firstChild.focus();
    o.onkeydown = (e) => { if (e.key === 'Escape') done(-1); e.stopPropagation(); };
    o.onmousedown = (e) => { if (e.target === o) done(-1); };
  });
}

// ── modal: run configuration → { action: 'run' | 'debug', program, cwd, args, stopOnEntry, breakOnUncaught } or null ──
export function askRunConfig({ title = 'Run / Debug Python', initial, browseFile, browseDir, validate, debugAvailable = true }) {
  return new Promise((res) => {
    const o = $('#modal');
    o.innerHTML = `<div class="box runcfg">
      <div class="mt">${esc(title)}</div>
      <label for="rc-program">Python file</label>
      <div class="rc-row"><input type="text" id="rc-program" spellcheck="false" /><button type="button" class="rc-browse" id="rc-program-browse">Browse…</button></div>
      <label for="rc-cwd">Working directory</label>
      <div class="rc-row"><input type="text" id="rc-cwd" spellcheck="false" /><button type="button" class="rc-browse" id="rc-cwd-browse">Browse…</button></div>
      <label for="rc-args">Arguments (shell-style quoting)</label>
      <div class="rc-row"><input type="text" id="rc-args" spellcheck="false" placeholder="--option value &quot;a file.txt&quot;" /></div>
      <label class="rc-check"><input type="checkbox" id="rc-entry" /> Stop on entry (debug only)</label>
      <label class="rc-check"><input type="checkbox" id="rc-uncaught" /> Break on uncaught exceptions (debug only)</label>
      <div class="rc-error" id="rc-error" role="alert"></div>
      <div class="btns"></div></div>`;
    o.style.display = 'flex';
    const field = (id) => $(`#${id}`, o);
    field('rc-program').value = initial.program || '';
    field('rc-cwd').value = initial.cwd || '';
    field('rc-args').value = initial.args || '';
    field('rc-entry').checked = !!initial.stopOnEntry;
    field('rc-uncaught').checked = initial.breakOnUncaught !== false;
    const done = (v) => { o.style.display = 'none'; o.innerHTML = ''; closed(); res(v); };
    const submit = (action) => {
      const values = {
        action, program: field('rc-program').value.trim(), cwd: field('rc-cwd').value.trim(), args: field('rc-args').value,
        stopOnEntry: field('rc-entry').checked, breakOnUncaught: field('rc-uncaught').checked,
      };
      const error = validate ? validate(values) : null;
      if (error) { field('rc-error').textContent = error; return; }
      done(values);
    };
    field('rc-program-browse').onclick = async () => { const p = await browseFile?.(field('rc-program').value); if (p) { field('rc-program').value = p; if (!field('rc-cwd').value) field('rc-cwd').value = p.replace(/[\\/][^\\/]*$/, ''); } };
    field('rc-cwd-browse').onclick = async () => { const p = await browseDir?.(field('rc-cwd').value); if (p) field('rc-cwd').value = p; };
    const bar = $('.btns', o);
    const run = el('button', 'main', 'Run'); run.onclick = () => submit('run');
    const debug = el('button', '', 'Debug'); debug.onclick = () => submit('debug'); debug.disabled = !debugAvailable;
    const cancel = el('button', '', 'Cancel'); cancel.onclick = () => done(null);
    bar.append(run, debug, cancel);
    o.onkeydown = (e) => {
      if (e.key === 'Escape') done(null);
      else if (e.key === 'Enter' && e.target.tagName === 'INPUT' && e.target.type === 'text') submit('run');
      e.stopPropagation();
    };
    o.onmousedown = (e) => { if (e.target === o) done(null); };
    field('rc-args').focus();
  });
}

// ── fuzzy matching ──
function fscore(t, q) {
  let ti = 0, s = 0, last = -2;
  for (const c of q) {
    const i = t.indexOf(c, ti);
    if (i < 0) return -1;
    s += i === last + 1 ? 0 : 1 + (i - ti) * 0.01;
    last = i;
    ti = i + 1;
  }
  return s + t.length * 0.001;
}
export function fuzzy(list, q, getText, limit = 60) {
  q = q.trim().toLowerCase();
  if (!q) return list.slice(0, limit);
  const out = [];
  for (const it of list) {
    const t = getText(it).toLowerCase();
    let s = fscore(t, q);
    if (s < 0) continue;
    const base = t.slice(t.lastIndexOf('/') + 1);
    if (base.includes(q)) s -= 5;
    out.push([s, it]);
  }
  out.sort((a, b) => a[0] - b[0]);
  return out.slice(0, limit).map((x) => x[1]);
}

// ── palette (quick open / commands) ──
export function openPalette(provider, initial = '', placeholder = 'Go to file…  (> commands, : line number)') {
  const o = $('#palette');
  o.style.display = 'flex';
  o.innerHTML = `<div class="box"><input class="pi" spellcheck="false" placeholder="${esc(placeholder)}" /><div class="pl"></div></div>`;
  const inp = $('.pi', o);
  const list = $('.pl', o);
  let items = [];
  let sel = 0;
  const close = () => { o.style.display = 'none'; o.innerHTML = ''; closed(); };
  const choose = (i) => { const it = items[i]; close(); if (it) it.run(); };
  const render = () => {
    items = provider(inp.value);
    sel = Math.min(sel, Math.max(0, items.length - 1));
    list.innerHTML = '';
    items.forEach((it, i) => {
      const d = el('div', 'pitem' + (i === sel ? ' sel' : ''));
      d.innerHTML = `<span class="pl1">${esc(it.label)}</span><span class="pl2">${esc(it.detail || '')}</span>`;
      d.onmousedown = (e) => { e.preventDefault(); choose(i); };
      list.appendChild(d);
    });
    if (list.children[sel]) list.children[sel].scrollIntoView({ block: 'nearest' });
  };
  inp.value = initial;
  inp.oninput = () => { sel = 0; render(); };
  inp.onkeydown = (e) => {
    if (e.key === 'ArrowDown') { sel = Math.min(sel + 1, items.length - 1); render(); e.preventDefault(); }
    else if (e.key === 'ArrowUp') { sel = Math.max(sel - 1, 0); render(); e.preventDefault(); }
    else if (e.key === 'Enter') choose(sel);
    else if (e.key === 'Escape') close();
    e.stopPropagation();
  };
  o.onmousedown = (e) => { if (e.target === o) close(); };
  render();
  inp.focus();
}

// ── drag resizer ──
export function drag(handle, onMove) {
  handle.addEventListener('mousedown', (e) => {
    e.preventDefault();
    document.body.classList.add('dragging');
    const mv = (ev) => onMove(ev);
    const up = () => {
      removeEventListener('mousemove', mv);
      removeEventListener('mouseup', up);
      document.body.classList.remove('dragging');
      dispatchEvent(new Event('resize'));
      document.dispatchEvent(new Event('layout-changed'));
    };
    addEventListener('mousemove', mv);
    addEventListener('mouseup', up);
  });
}
