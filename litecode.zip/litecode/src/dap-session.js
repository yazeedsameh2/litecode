import { createDapRequest, isDapResponse, normalizeDapBreakpoint } from './dap-protocol.js';

/** Transport-agnostic DAP request/event coordinator. The host supplies sendBytes(). */
export class DapSession {
  #sendBytes;
  #seq = 1;
  #pending = new Map();
  #listeners = new Map();
  #closed = false;
  #maxPending;
  #requestTimeoutMs;

  constructor({ sendBytes, maxPending = 128, requestTimeoutMs = 30000 } = {}) {
    if (typeof sendBytes !== 'function') throw new TypeError('sendBytes must be a function');
    if (!Number.isSafeInteger(maxPending) || maxPending < 1 || maxPending > 4096) throw new RangeError('maxPending must be between 1 and 4096');
    if (!Number.isSafeInteger(requestTimeoutMs) || requestTimeoutMs < 0 || requestTimeoutMs > 600000) throw new RangeError('requestTimeoutMs must be between 0 and 600000');
    this.#sendBytes = sendBytes;
    this.#maxPending = maxPending;
    this.#requestTimeoutMs = requestTimeoutMs;
  }

  get closed() { return this.#closed; }
  get pendingCount() { return this.#pending.size; }

  on(name, listener) {
    if (typeof name !== 'string' || !name || typeof listener !== 'function') throw new TypeError('Event name and listener are required');
    const listeners = this.#listeners.get(name) || new Set();
    listeners.add(listener);
    this.#listeners.set(name, listeners);
    return () => {
      listeners.delete(listener);
      if (!listeners.size) this.#listeners.delete(name);
    };
  }

  #emit(name, payload) {
    for (const listener of this.#listeners.get(name) || []) {
      try { listener(payload); } catch { /* One UI listener must not break protocol dispatch. */ }
    }
  }

  async request(command, args = {}) {
    if (this.#closed) throw new Error('DAP session is closed');
    if (this.#pending.size >= this.#maxPending) throw new Error('Too many outstanding DAP requests');
    const seq = this.#seq++;
    if (!Number.isSafeInteger(this.#seq)) this.#seq = 1;
    const request = createDapRequest(command, args, seq);
    let resolvePending;
    let rejectPending;
    const promise = new Promise((resolve, reject) => { resolvePending = resolve; rejectPending = reject; });
    const pending = { command, resolve: resolvePending, reject: rejectPending, timer: null };
    this.#pending.set(seq, pending);
    if (this.#requestTimeoutMs > 0) {
      pending.timer = setTimeout(() => {
        if (!this.#pending.delete(seq)) return;
        const error = new Error(`DAP request '${command}' timed out after ${this.#requestTimeoutMs} ms`);
        pending.reject(error);
        this.#emit('requestTimeout', { seq, command, timeoutMs: this.#requestTimeoutMs });
        this.#emit(`requestTimeout:${command}`, { seq, command, timeoutMs: this.#requestTimeoutMs });
      }, this.#requestTimeoutMs);
    }
    try {
      await this.#sendBytes(request);
    } catch (error) {
      if (this.#pending.delete(seq)) {
        if (pending.timer) clearTimeout(pending.timer);
        pending.reject(error instanceof Error ? error : new Error(String(error)));
      }
    }
    return promise;
  }

  receive(message) {
    if (this.#closed || !message || typeof message !== 'object') return false;
    if (message.type === 'response') {
      const pending = this.#pending.get(message.request_seq);
      if (!pending || !isDapResponse(message, message.request_seq)) return false;
      this.#pending.delete(message.request_seq);
      if (pending.timer) clearTimeout(pending.timer);
      if (message.success) pending.resolve(message);
      else {
        const detail = typeof message.message === 'string' ? message.message : `DAP request '${pending.command}' failed`;
        const error = new Error(detail);
        error.response = message;
        pending.reject(error);
      }
      this.#emit('response', message);
      this.#emit(`response:${pending.command}`, message);
      return true;
    }
    if (message.type === 'event' && typeof message.event === 'string') {
      this.#emit('event', message);
      this.#emit(`event:${message.event}`, message.body ?? {});
      return true;
    }
    if (message.type === 'request' && typeof message.command === 'string') {
      this.#emit('adapterRequest', message);
      return true;
    }
    return false;
  }

  /** Reply to a request that the adapter sent to the client (a "reverse request"). */
  async respond(request, { success = true, body, message } = {}) {
    if (this.#closed) return false;
    if (!request || request.type !== 'request' || !Number.isSafeInteger(request.seq)) throw new TypeError('A DAP request is required');
    const reply = { seq: this.#seq++, type: 'response', request_seq: request.seq, success: Boolean(success), command: String(request.command || '') };
    if (!Number.isSafeInteger(this.#seq)) this.#seq = 1;
    if (success) { if (body !== undefined) reply.body = body; }
    else reply.message = String(message || 'Unsupported request').slice(0, 500);
    await this.#sendBytes(reply);
    return true;
  }

  normalizeBreakpoints(items) {
    if (!Array.isArray(items)) return [];
    return items.map(normalizeDapBreakpoint).filter(Boolean);
  }

  close(reason = 'DAP session closed') {
    if (this.#closed) return;
    this.#closed = true;
    const error = reason instanceof Error ? reason : new Error(String(reason));
    for (const pending of this.#pending.values()) {
      if (pending.timer) clearTimeout(pending.timer);
      pending.reject(error);
    }
    this.#pending.clear();
    this.#emit('close', error);
    this.#listeners.clear();
  }
}
