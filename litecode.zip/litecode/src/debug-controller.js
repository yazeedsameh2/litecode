import { PythonDebugWorkflow } from './dap-workflow.js';
import { describeAdapterFailure, formatExceptionInfo } from './python-errors.js';

const ACTIVE_STATES = new Set(['starting', 'running', 'stopped', 'stopping']);
const SYNC_STATES = new Set(['running', 'stopped', 'configuring']);
const MAX_VARIABLES = 200;

/**
 * Coordinates one Python debug session: ordered DAP startup, breakpoint sync, stop inspection,
 * shutdown and restart. Contains no DOM/Tauri code so the whole flow can be tested against a fake
 * adapter. UI state is reported through hooks:
 *   onState({state, detail}), onOutput({category, text}), onStopped(info), onLocation(loc|null),
 *   onScopes({frameId, scopes}).
 * Controller states: idle | starting | running | stopped | stopping | finished | disconnected.
 */
export class DebugController {
  #createClient; #store; #hooks; #startTimeoutMs; #isPathAllowed;
  #client = null; #workflow = null; #token = null;
  #state = 'idle'; #detail = ''; #config = null;
  #frames = []; #selectedFrameId = null; #stderr = '';
  #inspectGen = 0; #scopeGen = 0; #bpQueue = Promise.resolve(); #unsubscribe;

  constructor({ createClient, store, isPathAllowed = () => true, startTimeoutMs = 10000, ...hooks } = {}) {
    if (typeof createClient !== 'function') throw new TypeError('createClient must be a function');
    if (!store || typeof store.entries !== 'function') throw new TypeError('A breakpoint store is required');
    this.#createClient = createClient; this.#store = store; this.#isPathAllowed = isPathAllowed;
    this.#startTimeoutMs = startTimeoutMs;
    this.#hooks = {
      onState: () => {}, onOutput: () => {}, onStopped: () => {}, onLocation: () => {}, onScopes: () => {}, ...hooks,
    };
    this.#unsubscribe = store.subscribe((event) => {
      if (event.type === 'change' && event.path) this.syncBreakpoints(event.path);
    });
  }

  get state() { return this.#state; }
  get detail() { return this.#detail; }
  get active() { return ACTIVE_STATES.has(this.#state); }
  get config() { return this.#config ? { ...this.#config } : null; }
  get frames() { return [...this.#frames]; }
  get selectedFrameId() { return this.#selectedFrameId; }

  #setState(state, detail = '') {
    this.#state = state; this.#detail = detail;
    this.#hooks.onState({ state, detail });
  }
  #out(category, text) { this.#hooks.onOutput({ category, text }); }
  #isCurrent(token) { return token === this.#token && !token.ending && !token.cancelled; }
  #invalidate() { this.#inspectGen++; this.#scopeGen++; }

  async start(config) {
    if (this.active) throw new Error('A debug session is already active');
    if (!config || typeof config.program !== 'string' || !config.program.trim()) throw new TypeError('A Python file is required');
    if (typeof config.cwd !== 'string' || !config.cwd.trim()) throw new TypeError('A working directory is required');
    const token = { cancelled: false, ending: false };
    this.#token = token; this.#config = { ...config, args: [...(config.args || [])] };
    this.#stderr = ''; this.#frames = []; this.#selectedFrameId = null;
    this.#setState('starting', 'Starting debug adapter');
    let client = null;
    const guard = () => { if (token.cancelled) throw Object.assign(new Error('Debug start cancelled'), { cancelled: true }); };
    try {
      client = await this.#createClient({
        python: config.python || null,
        onStatus: (text, kind) => this.#out(kind === 'err' ? 'stderr' : 'adapter', `${text}\n`),
        onStderr: (text) => { this.#stderr = (this.#stderr + text).slice(-4000); this.#out('adapter', text.endsWith('\n') ? text : `${text}\n`); },
      });
      this.#client = client; guard();
      const workflow = new PythonDebugWorkflow(client, {
        onState: ({ state, detail }) => this.#onWorkflowState(token, state, detail),
        onOutput: ({ category, output }) => this.#out(category, output),
      });
      this.#workflow = workflow;
      await workflow.initialize(); guard();
      const { response } = await workflow.launch({
        program: config.program, cwd: config.cwd, args: config.args || [],
        stopOnEntry: config.stopOnEntry === true, env: config.env,
      });
      // debugpy answers `launch` only after configurationDone, so we must not await it here.
      // A launch *failure*, however, arrives early and must abort the wait for `initialized`.
      const launchFailed = response.then(() => new Promise(() => {}));
      await Promise.race([workflow.waitForInitializedEvent(this.#startTimeoutMs), launchFailed]); guard();
      await this.#sendAllBreakpoints(workflow); guard();
      if (config.breakOnUncaught !== false) {
        try { await workflow.setExceptionBreakpoints(['uncaught']); }
        catch (error) { this.#out('stderr', `Could not enable exception breakpoints: ${error.message}\n`); }
      }
      guard();
      await workflow.configurationDone(); guard();
      await response; guard();
      this.#out('adapter', 'Debug session started.\n');
      return this.#state;
    } catch (error) {
      token.ending = true;
      if (this.#token === token) await this.#teardown();
      else { try { await client?.close(); } catch { /* already closed */ } }
      if (error?.cancelled || token.cancelled) return this.#state;
      const hint = describeAdapterFailure(this.#stderr, config.python);
      const friendly = /not installed|Could not run/.test(hint) ? hint : (error?.message || String(error));
      this.#out('stderr', `Failed to start debugging: ${friendly}\n`);
      if (this.#state !== 'disconnected') this.#setState('idle', friendly);
      throw new Error(friendly);
    }
  }

  async #sendAllBreakpoints(workflow) {
    for (const [path] of this.#store.entries()) {
      if (!this.#isPathAllowed(path)) continue;
      const lines = this.#store.lines(path);
      const accepted = await workflow.setBreakpoints(path, lines);
      this.#store.applyAdapterResult(path, lines, accepted);
    }
  }

  #onWorkflowState(token, state, detail) {
    if (!this.#isCurrent(token)) return;
    switch (state) {
      case 'running':
        this.#invalidate(); this.#hooks.onLocation(null); this.#setState('running'); break;
      case 'stopped':
        this.#setState('stopped', detail); this.#inspect(token); break;
      case 'exited':
        this.#out('adapter', `Process finished (${detail}).\n`); break;
      case 'terminated':
        this.#finish(token); break;
      case 'disconnected':
        this.#lost(token, detail); break;
      case 'idle': break;
      default: this.#setState('starting', state);
    }
  }

  async #finish(token) {
    const exitCode = this.#workflow?.exitCode;
    token.ending = true; this.#invalidate();
    this.#hooks.onLocation(null);
    this.#setState('finished', exitCode == null ? 'Program finished' : `Exit code: ${exitCode}`);
    await this.#teardown();
  }

  async #lost(token, detail) {
    token.ending = true; this.#invalidate();
    this.#hooks.onLocation(null);
    const hint = describeAdapterFailure(this.#stderr, this.#config?.python);
    const reason = /not installed|Could not run/.test(hint) ? hint : detail;
    this.#out('stderr', `Debug adapter connection lost: ${reason}\n`);
    this.#setState('disconnected', reason);
    await this.#teardown();
  }

  async #teardown() {
    const workflow = this.#workflow; const client = this.#client;
    if (this.#token) this.#token.ending = true;
    this.#workflow = null; this.#client = null;
    this.#invalidate(); this.#frames = []; this.#selectedFrameId = null;
    try { await workflow?.stop(); } catch (error) { this.#out('stderr', `Debug stop warning: ${error?.message || error}\n`); }
    try { await client?.close(); } catch (error) { this.#out('stderr', `Adapter stop warning: ${error?.message || error}\n`); }
    this.#store.resetVerification();
  }

  async #inspect(token) {
    const gen = ++this.#inspectGen; this.#scopeGen++;
    const workflow = this.#workflow;
    if (!workflow) return;
    const stale = () => gen !== this.#inspectGen || !this.#isCurrent(token) || workflow.state !== 'stopped';
    try {
      let threadId = workflow.threadId;
      if (threadId === null) {
        const threads = await workflow.threads(); if (stale()) return;
        if (!threads.length) throw new Error('The adapter did not report a stopped thread');
        threadId = threads[0].id; workflow.threadId = threadId;
      }
      const frames = await workflow.stackTrace(threadId); if (stale()) return;
      this.#frames = frames;
      const stop = workflow.stopInfo || {};
      let exception = null;
      if (stop.reason === 'exception') {
        try {
          exception = await workflow.exceptionInfo(threadId);
          const text = formatExceptionInfo(exception);
          if (text) this.#out('stderr', text);
        } catch { /* exceptionInfo is optional */ }
        if (stale()) return;
      }
      this.#hooks.onStopped({ reason: stop.reason, description: stop.description, text: stop.text, exception, frames, threadId });
      await this.selectFrame(frames[0]?.id ?? null);
    } catch (error) {
      if (!stale()) this.#out('stderr', `Inspection failed: ${error?.message || error}\n`);
    }
  }

  /** Shows a frame's source line and loads its scopes (non-expensive ones eagerly). */
  async selectFrame(frameId) {
    const workflow = this.#workflow;
    if (!workflow || workflow.state !== 'stopped') return;
    const gen = ++this.#scopeGen;
    this.#selectedFrameId = frameId;
    const frame = this.#frames.find((f) => f.id === frameId);
    const isTop = frame && frame === this.#frames[0];
    const exception = workflow.stopInfo?.reason === 'exception';
    if (frame?.source?.path) {
      this.#hooks.onLocation({ path: frame.source.path, line: frame.line || 1, column: frame.column || 1, frameId, kind: isTop && exception ? 'exception' : isTop ? 'stop' : 'frame' });
    } else this.#hooks.onLocation(null);
    if (!Number.isSafeInteger(frameId)) { this.#hooks.onScopes({ frameId: null, scopes: [] }); return; }
    const stale = () => gen !== this.#scopeGen || workflow.state !== 'stopped' || this.#workflow !== workflow;
    try {
      const scopes = await workflow.scopes(frameId); if (stale()) return;
      const loaded = [];
      for (const scope of scopes.slice(0, 8)) {
        let variables = null;
        if (scope.expensive !== true) {
          variables = (await workflow.variables(scope.variablesReference)).slice(0, MAX_VARIABLES);
          if (stale()) return;
        }
        loaded.push({ name: scope.name, variablesReference: scope.variablesReference, expensive: scope.expensive === true, variables });
      }
      this.#hooks.onScopes({ frameId, scopes: loaded });
    } catch (error) {
      if (!stale()) this.#out('stderr', `Could not load variables: ${error?.message || error}\n`);
    }
  }

  /** Children of a structured variable (or an expensive scope); empty unless paused. */
  async expand(variablesReference) {
    const workflow = this.#workflow;
    if (!workflow || workflow.state !== 'stopped') return [];
    return (await workflow.variables(variablesReference)).slice(0, MAX_VARIABLES);
  }

  async evaluate(expression) {
    const workflow = this.#workflow;
    if (!workflow || workflow.state !== 'stopped') throw new Error('Pause the program (breakpoint or Pause) to evaluate expressions');
    return workflow.evaluate(expression, this.#selectedFrameId ?? undefined);
  }

  #requireStopped(action) {
    const workflow = this.#workflow;
    if (!workflow || workflow.state !== 'stopped') throw new Error(`${action} is only available while the program is paused`);
    return workflow;
  }
  async continue() { return this.#requireStopped('Continue').continue(); }
  async stepOver() { return this.#requireStopped('Step Over').stepOver(); }
  async stepInto() { return this.#requireStopped('Step Into').stepInto(); }
  async stepOut() { return this.#requireStopped('Step Out').stepOut(); }

  async pause() {
    const workflow = this.#workflow;
    if (!workflow || workflow.state !== 'running') throw new Error('Pause is only available while the program is running');
    const threadId = workflow.threadId ?? (await workflow.threads())[0]?.id;
    if (!Number.isSafeInteger(threadId)) throw new Error('The adapter has not reported a debuggable thread yet');
    return workflow.pause(threadId);
  }

  /** Re-sends one file's breakpoints; calls are serialized so the adapter sees them in order. */
  syncBreakpoints(path) {
    const workflow = this.#workflow;
    if (!workflow || !SYNC_STATES.has(workflow.state) || !this.#isPathAllowed(path)) return Promise.resolve();
    this.#bpQueue = this.#bpQueue.then(async () => {
      if (this.#workflow !== workflow || !SYNC_STATES.has(workflow.state)) return;
      const lines = this.#store.lines(path);
      const accepted = await workflow.setBreakpoints(path, lines);
      this.#store.applyAdapterResult(path, lines, accepted);
    }).catch((error) => this.#out('stderr', `Could not update breakpoints: ${error?.message || error}\n`));
    return this.#bpQueue;
  }

  /** User-initiated stop. Safe to call in any state, including while starting. */
  async stop() {
    const token = this.#token;
    if (!token || !this.active) {
      if (this.#state !== 'idle') { this.#hooks.onLocation(null); this.#setState('idle'); }
      return;
    }
    token.cancelled = true;
    this.#setState('stopping');
    this.#hooks.onLocation(null);
    await this.#teardown();
    this.#setState('idle');
    this.#out('adapter', 'Debug session stopped.\n');
  }

  /** Restarts with the last configuration (an explicit user action, like Start). */
  async restart() {
    const config = this.#config;
    if (!config) throw new Error('There is no previous debug session to restart');
    await this.stop();
    return this.start(config);
  }

  async dispose() {
    this.#unsubscribe();
    await this.stop();
  }
}
