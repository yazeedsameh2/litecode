// Pure Git status helpers kept separate so edge cases can be tested without Tauri.
const CONFLICT_CODES = new Set(['DD', 'AU', 'UD', 'UA', 'DU', 'AA', 'UU']);

export function isGitConflict(file) {
  const index = String(file?.index_status || ' ');
  const worktree = String(file?.worktree_status || ' ');
  return index === 'U' || worktree === 'U' || CONFLICT_CODES.has(index + worktree);
}

export function gitStatusLabel(file) {
  if (isGitConflict(file)) return '!';
  if (file?.untracked) return 'U';
  if (file?.index_status === 'D' || file?.worktree_status === 'D') return 'D';
  if (file?.index_status === 'A' || file?.worktree_status === 'A') return 'A';
  if (file?.index_status === 'R' || file?.worktree_status === 'R') return 'R';
  if (file?.index_status !== ' ' || file?.worktree_status !== ' ') return 'M';
  return 'M';
}
