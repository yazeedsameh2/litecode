import { replacePathPrefix, pathMatchesPrefix } from './path-utils.js';

const MAX_FILES = 500;
const MAX_LINES_PER_FILE = 2000;
const validLine = (line) => Number.isSafeInteger(line) && line > 0 && line < 10_000_000;
const sameLines = (a, b) => a.length === b.length && a.every((v, i) => v === b[i]);

/**
 * Source of truth for user breakpoints, independent from the editor and from any live session.
 * Listeners receive `{ type: 'change' | 'verification' | 'reset', path }`:
 *  - `change`: the user's breakpoints changed (sync them to a running adapter);
 *  - `verification`: the adapter adjusted/rejected lines (re-render only, do not re-send).
 */
export class BreakpointStore {
  #files = new Map(); // key -> { path, lines: number[] (sorted), unverified: Set<number> }
  #listeners = new Set();
  #insensitive;

  constructor({ caseInsensitive = false } = {}) { this.#insensitive = !!caseInsensitive; }

  #key(path) {
    const normalized = String(path).replace(/\\/g, '/');
    return this.#insensitive ? normalized.toLowerCase() : normalized;
  }
  #emit(event) { for (const fn of [...this.#listeners]) { try { fn(event); } catch { /* UI listener errors are isolated */ } } }
  subscribe(fn) { this.#listeners.add(fn); return () => this.#listeners.delete(fn); }

  lines(path) { return [...(this.#files.get(this.#key(path))?.lines || [])]; }
  unverified(path) { return [...(this.#files.get(this.#key(path))?.unverified || [])].sort((a, b) => a - b); }
  has(path, line) { return this.#files.get(this.#key(path))?.lines.includes(line) === true; }
  get count() { let n = 0; for (const f of this.#files.values()) n += f.lines.length; return n; }
  entries() { return [...this.#files.values()].filter((f) => f.lines.length).map((f) => [f.path, [...f.lines]]); }

  /** Replaces the lines of a file; returns true when something changed. */
  setLines(path, lines, { silent = false } = {}) {
    if (typeof path !== 'string' || !path) throw new TypeError('A file path is required');
    const next = [...new Set((Array.isArray(lines) ? lines : []).filter(validLine))].sort((a, b) => a - b).slice(0, MAX_LINES_PER_FILE);
    const key = this.#key(path);
    const current = this.#files.get(key);
    if (current && sameLines(current.lines, next)) return false;
    if (!current && !next.length) return false;
    if (!current && this.#files.size >= MAX_FILES) throw new RangeError(`At most ${MAX_FILES} files can have breakpoints`);
    if (!next.length) this.#files.delete(key);
    else {
      const unverified = new Set([...(current?.unverified || [])].filter((line) => next.includes(line)));
      this.#files.set(key, { path: current?.path || path, lines: next, unverified });
    }
    if (!silent) this.#emit({ type: 'change', path });
    return true;
  }

  /** Toggles a breakpoint; returns whether it is now set. */
  toggle(path, line) {
    if (!validLine(line)) throw new RangeError('Invalid breakpoint line');
    const lines = this.lines(path);
    const index = lines.indexOf(line);
    if (index >= 0) lines.splice(index, 1); else lines.push(line);
    this.setLines(path, lines);
    return index < 0;
  }

  remove(path) { if (this.#files.delete(this.#key(path))) this.#emit({ type: 'change', path }); }
  clear() { if (this.#files.size) { this.#files.clear(); this.#emit({ type: 'reset', path: null }); } }

  /**
   * Applies setBreakpoints results (same order as the requested sorted lines): lines the adapter
   * moved are updated, unverified ones are flagged. Does not trigger a re-send.
   */
  applyAdapterResult(path, requestedLines, accepted) {
    const entry = this.#files.get(this.#key(path));
    if (!entry || !Array.isArray(accepted)) return false;
    const requested = [...new Set(requestedLines.filter(validLine))].sort((a, b) => a - b);
    const nextLines = []; const unverified = new Set();
    requested.forEach((line, i) => {
      if (!entry.lines.includes(line)) return; // user changed it meanwhile; a newer sync will follow
      const result = accepted[i];
      const actual = validLine(result?.line) ? result.line : line;
      nextLines.push(actual);
      if (result && result.verified === false) unverified.add(actual);
    });
    // Keep breakpoints the user added after this request was made.
    for (const line of entry.lines) if (!requested.includes(line)) nextLines.push(line);
    const lines = [...new Set(nextLines)].sort((a, b) => a - b);
    const changed = !sameLines(lines, entry.lines) || ![...unverified].every((l) => entry.unverified.has(l)) || unverified.size !== entry.unverified.size;
    entry.lines = lines; entry.unverified = unverified;
    if (changed) this.#emit({ type: 'verification', path: entry.path });
    return changed;
  }

  /** Clears verification flags (e.g. when a debug session ends). */
  resetVerification() {
    let changed = false;
    for (const entry of this.#files.values()) if (entry.unverified.size) { entry.unverified.clear(); changed = true; }
    if (changed) this.#emit({ type: 'verification', path: null });
  }

  /** Follows renames/moves of a file or folder. */
  rename(from, to) {
    const moved = [];
    for (const [key, entry] of [...this.#files]) {
      if (!pathMatchesPrefix(entry.path, from, this.#insensitive)) continue;
      this.#files.delete(key);
      moved.push({ ...entry, path: replacePathPrefix(entry.path, from, to, this.#insensitive) });
    }
    for (const entry of moved) this.#files.set(this.#key(entry.path), entry);
    if (moved.length) this.#emit({ type: 'reset', path: null });
    return moved.length;
  }

  serialize() { return Object.fromEntries(this.entries()); }

  restore(data) {
    if (!data || typeof data !== 'object' || Array.isArray(data)) return 0;
    this.#files.clear();
    for (const [path, lines] of Object.entries(data).slice(0, MAX_FILES)) {
      if (typeof path === 'string' && path && Array.isArray(lines)) this.setLines(path, lines, { silent: true });
    }
    this.#emit({ type: 'reset', path: null });
    return this.#files.size;
  }
}
