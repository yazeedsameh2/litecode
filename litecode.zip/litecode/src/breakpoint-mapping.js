/**
 * Moves 1-based breakpoint line numbers across a document edit.
 * `oldDoc`/`newDoc` expose CodeMirror's `Text` API subset: `lines`, `line(n).from`, `lineAt(pos).number`.
 * `mapPos(pos, assoc)` maps an old position to the new document (CodeMirror `ChangeSet.mapPos`).
 * With assoc = 1, text inserted exactly at the start of a breakpoint line (Enter at column 0)
 * stays above it, so the breakpoint keeps following its code.
 */
export function remapBreakpointLines(lines, oldDoc, newDoc, mapPos) {
  const out = new Set();
  for (const line of lines) {
    if (!Number.isSafeInteger(line) || line < 1 || line > oldDoc.lines) continue;
    const mapped = mapPos(oldDoc.line(line).from, 1);
    out.add(newDoc.lineAt(Math.min(Math.max(0, mapped), newDoc.length)).number);
  }
  return [...out].sort((a, b) => a - b);
}
