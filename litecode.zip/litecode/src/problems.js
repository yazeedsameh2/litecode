const severityRank = (severity) => ({ 1: 0, 2: 1, 3: 2, 4: 3 })[severity] ?? 4;

export function collectProblems(diagnosticsByPath, { root = null, severity = 'all', query = '' } = {}) {
  const rows = [];
  const needle = String(query || '').trim().toLowerCase();
  for (const [path, diagnostics] of diagnosticsByPath instanceof Map ? diagnosticsByPath : []) {
    if (root && !withinRoot(path, root)) continue;
    for (const diagnostic of Array.isArray(diagnostics) ? diagnostics : []) {
      const level = [1, 2, 3, 4].includes(diagnostic?.severity) ? diagnostic.severity : 3;
      if (severity !== 'all' && String(level) !== String(severity)) continue;
      const message = String(diagnostic?.message || 'Language diagnostic').slice(0, 1000);
      const code = diagnostic?.code == null ? '' : String(diagnostic.code).slice(0, 80);
      const line = Math.max(1, Math.trunc(Number(diagnostic?.range?.start?.line) || 0) + 1);
      const column = Math.max(1, Math.trunc(Number(diagnostic?.range?.start?.character) || 0) + 1);
      if (needle && !`${path} ${message} ${code}`.toLowerCase().includes(needle)) continue;
      rows.push({ path, message, code, severity: level, line, column });
    }
  }
  return rows.sort((a, b) => severityRank(a.severity) - severityRank(b.severity) || a.path.localeCompare(b.path) || a.line - b.line || a.column - b.column);
}

export function withinRoot(path, root) {
  const normalize = (value) => String(value || '').replace(/\\/g, '/').replace(/\/+$/, '');
  const file = normalize(path);
  const base = normalize(root);
  if (!file || !base) return false;
  const insensitive = /^[A-Za-z]:\//.test(file) || /^[A-Za-z]:\//.test(base);
  const f = insensitive ? file.toLowerCase() : file;
  const b = insensitive ? base.toLowerCase() : base;
  return f === b || f.startsWith(`${b}/`);
}
