export function matchHtmlTagPrefix(before) {
  const match = before.match(/<([A-Za-z][\w:-]*)?$/);
  if (!match) return null;
  return { typed: match[1] || '', fromOffset: (match[1] || '').length };
}

export function buildHtmlTagInsertion(tag) {
  return { text: `${tag}></${tag}>`, cursorOffset: tag.length + 1 };
}

