/** High-level Python DAP workflow. The UI supplies a started DapClient and absolute paths.
 *
 * Ordering follows the DAP specification and debugpy behaviour:
 *   initialize -> launch (response is deferred!) -> `initialized` event ->
 *   setBreakpoints / setExceptionBreakpoints -> configurationDone -> launch response.
 * `launch()` therefore never waits for the launch response; callers await `{ response }`
 * only after `configurationDone()`.
 *
 * Race handling: stop/continue events and request responses can arrive in either order.
 * Resume commands switch to `running` *before* the request is sent, and any adapter event
 * that arrives later (e.g. `stopped` before the `continue` response) wins.
 */
const ENDED_STATES = new Set(['idle', 'terminated', 'exited', 'disconnected']);
const isId = (value) => Number.isSafeInteger(value) && value >= 0;

export class PythonDebugWorkflow {
  constructor(client, { onState = () => {}, onOutput = () => {}, onStopped = () => {}, onBreakpointEvent = () => {}, disconnectTimeoutMs = 3000 } = {}) {
    if (!client || typeof client.request !== 'function' || typeof client.on !== 'function') {
      throw new TypeError('A started DAP client is required');
    }
    if (!Number.isSafeInteger(disconnectTimeoutMs) || disconnectTimeoutMs < 0 || disconnectTimeoutMs > 60000) {
      throw new RangeError('disconnectTimeoutMs must be between 0 and 60000');
    }
    this.client = client;
    this.onState = onState;
    this.onOutput = onOutput;
    this.onStopped = onStopped;
    this.onBreakpointEvent = onBreakpointEvent;
    this._disconnectTimeoutMs = disconnectTimeoutMs;
    this.state = 'idle';
    this.capabilities = {};
    this.breakpoints = new Map();
    this.threadId = null;
    this.stopInfo = null;
    this.exitCode = null;
    this.closeReason = '';
    this._epoch = 0;
    this._offs = [];
    this.initializedEventReceived = false;
    this._initializedWaiters = new Set();
  }

  get ended() { return ENDED_STATES.has(this.state); }

  _setState(state, detail = '') {
    this.state = state;
    this.onState({ state, detail });
  }

  _failWaiters(error) {
    for (const waiter of [...this._initializedWaiters]) waiter.reject(error);
    this._initializedWaiters.clear();
  }

  async initialize() {
    if (this.state !== 'idle') throw new Error(`Cannot initialize debugger while ${this.state}`);
    this._setState('initializing');
    // Subscribe before initialize: fast adapters may emit `initialized` immediately
    // after their initialize response, before the awaiting continuation resumes.
    this._offs.push(this.client.on('event:initialized', () => {
      this.initializedEventReceived = true;
      if (this.state === 'initializing' || this.state === 'initialized' || this.state === 'launching') this._setState('configuring');
      for (const waiter of [...this._initializedWaiters]) waiter.resolve();
      this._initializedWaiters.clear();
    }));
    this._offs.push(this.client.on('event:stopped', (body) => {
      this._epoch++;
      this.threadId = isId(body?.threadId) ? body.threadId : null;
      this.stopInfo = {
        reason: typeof body?.reason === 'string' ? body.reason : 'pause',
        description: typeof body?.description === 'string' ? body.description : '',
        text: typeof body?.text === 'string' ? body.text : '',
        threadId: this.threadId,
        allThreadsStopped: body?.allThreadsStopped === true,
        hitBreakpointIds: Array.isArray(body?.hitBreakpointIds) ? body.hitBreakpointIds : [],
      };
      this._setState('stopped', this.stopInfo.reason);
      this.onStopped(this.stopInfo);
    }));
    this._offs.push(this.client.on('event:continued', () => {
      this._epoch++;
      if (this.state === 'stopped' || this.state === 'configuring') this._setState('running');
    }));
    this._offs.push(this.client.on('event:terminated', (body) => {
      this._epoch++;
      this._setState('terminated', body?.restart ? 'Restart requested by adapter' : '');
    }));
    this._offs.push(this.client.on('event:exited', (body) => {
      this._epoch++;
      this.exitCode = Number.isSafeInteger(body?.exitCode) ? body.exitCode : null;
      this._setState('exited', `Exit code: ${body?.exitCode ?? 'unknown'}`);
    }));
    this._offs.push(this.client.on('event:output', (body) => {
      if (typeof body?.output !== 'string' || body.category === 'telemetry') return;
      this.onOutput({ category: body.category || 'console', output: body.output });
    }));
    this._offs.push(this.client.on('event:breakpoint', (body) => {
      if (body?.breakpoint && typeof body.breakpoint === 'object') this.onBreakpointEvent({ reason: body.reason, breakpoint: body.breakpoint });
    }));
    this._offs.push(this.client.on('close', (error) => {
      const reason = error instanceof Error ? error.message : String(error || 'Debug adapter connection closed');
      this.closeReason = reason;
      this._failWaiters(new Error(reason));
      if (!this.ended) this._setState('disconnected', reason);
    }));
    try {
      const response = await this.client.request('initialize', {
        clientID: 'litecode', clientName: 'LiteCode', adapterID: 'python',
        pathFormat: 'path', linesStartAt1: true, columnsStartAt1: true,
        supportsVariableType: true, supportsVariablePaging: true,
        supportsRunInTerminalRequest: false, supportsProgressReporting: false,
      });
      this.capabilities = response.body || {};
      // Preserve a lifecycle transition if `initialized` arrived during the request.
      if (this.state === 'initializing') this._setState('initialized');
      return this.capabilities;
    } catch (error) {
      for (const off of this._offs.splice(0)) { try { off(); } catch { /* best effort */ } }
      this._setState('idle', error instanceof Error ? error.message : String(error));
      throw error;
    }
  }

  /**
   * Sends the launch request without waiting for its response (debugpy answers only after
   * configurationDone). Resolves to `{ response }` once the request has been dispatched.
   */
  async launch({ program, cwd, args = [], stopOnEntry = true, console = 'internalConsole', env, justMyCode = true } = {}) {
    if (this.state !== 'initialized' && this.state !== 'configuring') throw new Error('Initialize the debugger before launching a program');
    if (typeof program !== 'string' || !program.trim()) throw new TypeError('An absolute Python script path is required');
    if (typeof cwd !== 'string' || !cwd.trim()) throw new TypeError('A project working directory is required');
    if (!Array.isArray(args) || args.some((arg) => typeof arg !== 'string')) throw new TypeError('Program arguments must be strings');
    if (!['internalConsole', 'integratedTerminal'].includes(console)) throw new TypeError('Unsupported debug console');
    if (env != null && (typeof env !== 'object' || Array.isArray(env) || Object.values(env).some((v) => typeof v !== 'string'))) {
      throw new TypeError('Environment variables must be an object of strings');
    }
    if (!this.initializedEventReceived) this._setState('launching', program);
    const body = {
      name: 'LiteCode Python', type: 'python', request: 'launch', program, cwd,
      args, console, stopOnEntry: Boolean(stopOnEntry), justMyCode: Boolean(justMyCode),
      redirectOutput: true, subProcess: false,
    };
    if (env) body.env = env;
    const response = this.client.request('launch', body);
    response.catch(() => { /* reported by whoever awaits `response` */ });
    return { response };
  }

  waitForInitializedEvent(timeoutMs = 10000) {
    if (this.initializedEventReceived) return Promise.resolve();
    if (!Number.isSafeInteger(timeoutMs) || timeoutMs < 1 || timeoutMs > 120000) throw new RangeError('Initialization wait must be between 1 and 120000 ms');
    return new Promise((resolve, reject) => {
      let timer;
      const waiter = {
        resolve: () => { clearTimeout(timer); this._initializedWaiters.delete(waiter); resolve(); },
        reject: (error) => { clearTimeout(timer); this._initializedWaiters.delete(waiter); reject(error); },
      };
      this._initializedWaiters.add(waiter);
      timer = setTimeout(() => waiter.reject(new Error(`Timed out waiting ${timeoutMs} ms for the DAP initialized event`)), timeoutMs);
    });
  }

  async setBreakpoints(sourcePath, lines) {
    if (typeof sourcePath !== 'string' || !sourcePath.trim()) throw new TypeError('Breakpoint source path is required');
    if (!Array.isArray(lines)) throw new TypeError('Breakpoint lines must be an array');
    const normalized = [...new Set(lines.filter((line) => Number.isSafeInteger(line) && line > 0))].sort((a, b) => a - b);
    const response = await this.client.request('setBreakpoints', {
      source: { name: sourcePath.split(/[\\/]/).pop(), path: sourcePath },
      lines: normalized, breakpoints: normalized.map((line) => ({ line })), sourceModified: false,
    });
    const accepted = Array.isArray(response.body?.breakpoints) ? response.body.breakpoints : [];
    this.breakpoints.set(sourcePath, accepted);
    return accepted;
  }

  /** Enables the named exception filters the adapter advertises (e.g. `uncaught`). */
  async setExceptionBreakpoints(filters) {
    const offered = new Set((this.capabilities.exceptionBreakpointFilters || []).map((item) => item?.filter));
    const wanted = (Array.isArray(filters) ? filters : []).filter((name) => typeof name === 'string' && offered.has(name));
    await this.client.request('setExceptionBreakpoints', { filters: wanted });
    return wanted;
  }

  async configurationDone() {
    if (this.state !== 'configuring') throw new Error('Debugger is not waiting for configuration');
    if (this.capabilities.supportsConfigurationDoneRequest) await this.client.request('configurationDone', {});
    // A fast `stopped` event (stopOnEntry or an early breakpoint) may have arrived while the
    // configurationDone response was in flight; never overwrite it with `running`.
    if (this.state === 'configuring') this._setState('running');
  }

  async threads() {
    const response = await this.client.request('threads', {});
    return Array.isArray(response.body?.threads) ? response.body.threads : [];
  }

  async stackTrace(threadId = this.threadId) {
    if (!isId(threadId)) throw new Error('No stopped thread is available');
    const response = await this.client.request('stackTrace', { threadId, startFrame: 0, levels: 50 });
    return Array.isArray(response.body?.stackFrames) ? response.body.stackFrames : [];
  }

  async scopes(frameId) {
    if (!isId(frameId)) throw new TypeError('A valid stack frame ID is required');
    const response = await this.client.request('scopes', { frameId });
    return Array.isArray(response.body?.scopes) ? response.body.scopes : [];
  }

  async variables(variablesReference) {
    if (!isId(variablesReference)) throw new TypeError('A valid variables reference is required');
    const response = await this.client.request('variables', { variablesReference });
    return Array.isArray(response.body?.variables) ? response.body.variables : [];
  }

  async exceptionInfo(threadId = this.threadId) {
    if (!isId(threadId)) throw new Error('No stopped thread is available');
    const response = await this.client.request('exceptionInfo', { threadId });
    return response.body || {};
  }

  async evaluate(expression, frameId, context = 'repl') {
    if (typeof expression !== 'string' || !expression.trim()) throw new TypeError('An expression is required');
    if (expression.length > 10000) throw new RangeError('Expression is too long');
    const args = { expression, context };
    if (isId(frameId)) args.frameId = frameId;
    const response = await this.client.request('evaluate', args);
    return response.body || {};
  }

  async continue(threadId = this.threadId) { return this._resume('continue', threadId); }
  async stepOver(threadId = this.threadId) { return this._resume('next', threadId); }
  async stepInto(threadId = this.threadId) { return this._resume('stepIn', threadId); }
  async stepOut(threadId = this.threadId) { return this._resume('stepOut', threadId); }

  async _resume(command, threadId) {
    if (!isId(threadId)) throw new Error('No debug thread is available');
    this._setState('running');
    const mark = this._epoch;
    try {
      return await this.client.request(command, { threadId });
    } catch (error) {
      // Restore only if the adapter has not reported anything newer in the meantime.
      if (this._epoch === mark && this.state === 'running') this._setState('stopped', `${command} failed`);
      throw error;
    }
  }

  async pause(threadId = this.threadId) {
    if (!isId(threadId)) throw new Error('No debug thread is available');
    return this.client.request('pause', { threadId });
  }

  async stop() {
    for (const off of this._offs.splice(0)) { try { off(); } catch { /* best effort */ } }
    if (!this.ended && this.state !== 'initializing') {
      let timer;
      try {
        const disconnect = this.client.request('disconnect', { restart: false, terminateDebuggee: true });
        disconnect.catch(() => {});
        await Promise.race([
          disconnect,
          new Promise((resolve) => { timer = setTimeout(resolve, this._disconnectTimeoutMs); }),
        ]);
      } catch { /* Adapter may already be gone. */ } finally { clearTimeout(timer); }
    }
    this._failWaiters(new Error('Debug session stopped'));
    this.initializedEventReceived = false;
    this._setState('idle');
    this.threadId = null;
    this.stopInfo = null;
    this.breakpoints.clear();
  }
}
