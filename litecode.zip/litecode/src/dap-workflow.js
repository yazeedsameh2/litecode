/** High-level Python DAP workflow. The UI supplies a started DapClient and absolute paths. */
export class PythonDebugWorkflow {
  constructor(client, { onState = () => {}, onOutput = () => {} } = {}) {
    if (!client || typeof client.request !== 'function' || typeof client.on !== 'function') {
      throw new TypeError('A started DAP client is required');
    }
    this.client = client;
    this.onState = onState;
    this.onOutput = onOutput;
    this.state = 'idle';
    this.capabilities = {};
    this.breakpoints = new Map();
    this.threadId = null;
    this._offs = [];
    this.initializedEventReceived = false;
    this._initializedWaiters = new Set();
  }

  _setState(state, detail = '') {
    this.state = state;
    this.onState({ state, detail });
  }

  async initialize() {
    if (this.state !== 'idle') throw new Error(`Cannot initialize debugger while ${this.state}`);
    this._setState('initializing');
    // Subscribe before initialize: fast adapters may emit `initialized` immediately
    // after their initialize response, before the awaiting continuation resumes.
    this._offs.push(this.client.on('event:initialized', () => {
      this.initializedEventReceived = true;
      this._setState('configuring');
      for (const resolve of this._initializedWaiters) resolve();
      this._initializedWaiters.clear();
    }));
    this._offs.push(this.client.on('event:stopped', (body) => {
      this.threadId = Number.isSafeInteger(body?.threadId) ? body.threadId : null;
      this._setState('stopped', body?.reason || 'Paused');
    }));
    this._offs.push(this.client.on('event:continued', () => this._setState('running')));
    this._offs.push(this.client.on('event:terminated', () => this._setState('terminated')));
    this._offs.push(this.client.on('event:exited', (body) => this._setState('exited', `Exit code: ${body?.exitCode ?? 'unknown'}`)));
    this._offs.push(this.client.on('event:output', (body) => {
      if (typeof body?.output === 'string') this.onOutput({ category: body.category || 'console', output: body.output });
    }));
    try {
      const response = await this.client.request('initialize', {
        clientID: 'litecode', clientName: 'LiteCode', adapterID: 'python',
        pathFormat: 'path', linesStartAt1: true, columnsStartAt1: true,
        supportsVariableType: true, supportsVariablePaging: true,
        supportsRunInTerminalRequest: false, supportsProgressReporting: false,
      });
      this.capabilities = response.body || {};
      // Preserve a lifecycle transition if `initialized` arrived during the request.
      if (this.state === 'initializing') this._setState('initialized');
      return this.capabilities;
    } catch (error) {
      for (const off of this._offs.splice(0)) { try { off(); } catch { /* best effort */ } }
      this._setState('idle', error instanceof Error ? error.message : String(error));
      throw error;
    }
  }

  async launch({ program, cwd, args = [], stopOnEntry = true, console = 'internalConsole' } = {}) {
    if (this.state !== 'initialized') throw new Error('Initialize the debugger before launching a program');
    if (typeof program !== 'string' || !program.trim()) throw new TypeError('An absolute Python script path is required');
    if (typeof cwd !== 'string' || !cwd.trim()) throw new TypeError('A project working directory is required');
    if (!Array.isArray(args) || args.some((arg) => typeof arg !== 'string')) throw new TypeError('Program arguments must be strings');
    if (!['internalConsole', 'integratedTerminal'].includes(console)) throw new TypeError('Unsupported debug console');
    this._setState('launching', program);
    const response = await this.client.request('launch', {
      name: 'LiteCode Python', type: 'python', request: 'launch', program, cwd,
      args, console, stopOnEntry: Boolean(stopOnEntry), justMyCode: true,
      redirectOutput: true,
    });
    if (this.initializedEventReceived) this._setState('configuring', 'Adapter ready for breakpoint configuration');
    else this._setState('launching', 'Launch accepted; waiting for initialization event');
    return response;
  }


  waitForInitializedEvent(timeoutMs = 10000) {
    if (this.initializedEventReceived) return Promise.resolve();
    if (!Number.isSafeInteger(timeoutMs) || timeoutMs < 1 || timeoutMs > 120000) throw new RangeError('Initialization wait must be between 1 and 120000 ms');
    return new Promise((resolve, reject) => {
      let timer;
      const finish = (error) => {
        clearTimeout(timer);
        this._initializedWaiters.delete(onReady);
        if (error) reject(error); else resolve();
      };
      const onReady = () => finish();
      this._initializedWaiters.add(onReady);
      timer = setTimeout(() => finish(new Error(`Timed out waiting ${timeoutMs} ms for the DAP initialized event`)), timeoutMs);
    });
  }

  async setBreakpoints(sourcePath, lines) {
    if (typeof sourcePath !== 'string' || !sourcePath.trim()) throw new TypeError('Breakpoint source path is required');
    if (!Array.isArray(lines)) throw new TypeError('Breakpoint lines must be an array');
    const normalized = [...new Set(lines.filter((line) => Number.isSafeInteger(line) && line > 0))].sort((a, b) => a - b);
    const response = await this.client.request('setBreakpoints', {
      source: { name: sourcePath.split(/[\\/]/).pop(), path: sourcePath },
      lines: normalized, breakpoints: normalized.map((line) => ({ line })), sourceModified: false,
    });
    const accepted = Array.isArray(response.body?.breakpoints) ? response.body.breakpoints : [];
    this.breakpoints.set(sourcePath, accepted);
    return accepted;
  }

  async configurationDone() {
    if (this.state !== 'configuring') throw new Error('Debugger is not waiting for configuration');
    if (this.capabilities.supportsConfigurationDoneRequest) await this.client.request('configurationDone', {});
    this._setState('running');
  }

  async threads() {
    const response = await this.client.request('threads', {});
    return Array.isArray(response.body?.threads) ? response.body.threads : [];
  }

  async stackTrace(threadId = this.threadId) {
    if (!Number.isSafeInteger(threadId) || threadId < 0) throw new Error('No stopped thread is available');
    const response = await this.client.request('stackTrace', { threadId, startFrame: 0, levels: 50 });
    return Array.isArray(response.body?.stackFrames) ? response.body.stackFrames : [];
  }

  async scopes(frameId) {
    if (!Number.isSafeInteger(frameId) || frameId < 0) throw new TypeError('A valid stack frame ID is required');
    const response = await this.client.request('scopes', { frameId });
    return Array.isArray(response.body?.scopes) ? response.body.scopes : [];
  }

  async variables(variablesReference) {
    if (!Number.isSafeInteger(variablesReference) || variablesReference < 0) throw new TypeError('A valid variables reference is required');
    const response = await this.client.request('variables', { variablesReference });
    return Array.isArray(response.body?.variables) ? response.body.variables : [];
  }

  async continue(threadId = this.threadId) {
    if (!Number.isSafeInteger(threadId) || threadId < 0) throw new Error('No debug thread is available');
    const response = await this.client.request('continue', { threadId });
    this._setState('running');
    return response;
  }

  async stepOver(threadId = this.threadId) { return this._step('next', threadId); }
  async stepInto(threadId = this.threadId) { return this._step('stepIn', threadId); }
  async stepOut(threadId = this.threadId) { return this._step('stepOut', threadId); }
  async _step(command, threadId) {
    if (!Number.isSafeInteger(threadId) || threadId < 0) throw new Error('No debug thread is available');
    const response = await this.client.request(command, { threadId });
    this._setState('running');
    return response;
  }

  async pause(threadId = this.threadId) {
    if (!Number.isSafeInteger(threadId) || threadId < 0) throw new Error('No debug thread is available');
    return this.client.request('pause', { threadId });
  }

  async stop() {
    for (const off of this._offs.splice(0)) { try { off(); } catch { /* best effort */ } }
    if (this.state !== 'idle' && this.state !== 'terminated' && this.state !== 'exited') {
      try { await this.client.request('disconnect', { restart: false, terminateDebuggee: true }); } catch { /* Adapter may already be gone. */ }
    }
    for (const resolve of this._initializedWaiters) resolve();
    this._initializedWaiters.clear();
    this.initializedEventReceived = false;
    this._setState('idle');
    this.threadId = null;
    this.breakpoints.clear();
  }
}
