## 0.7.8 — Integrated Python debugger panel

- Added a visible Python Debugger panel with start, continue, step over/into/out, pause, and stop controls.
- Added per-file breakpoint lists and a toggle for the current editor line; breakpoints are sent to DAP during launch and updated during an active session.
- Added call-stack frame navigation, top-scope variable inspection, and a bounded debug console.
- Added a confirmation prompt before running the selected Python file under the debugger.
- Added F6 to open/start debugging and F5 to continue while the debugger panel is active; F5 remains Run elsewhere.
- This is an initial integration. Native Tauri compilation and a real `debugpy` session still need verification on a machine with the Rust toolchain and debugpy installed.

## 0.7.7 — DAP request timeout safety

- Added bounded, configurable request timeouts to the DAP session coordinator (30 seconds by default; zero disables timeouts).
- Timed-out requests are removed from the pending map and reject with a command-specific error, preventing indefinitely hanging debugger actions.
- Added timeout diagnostic events and ensured responses, send failures, and session shutdown clear timeout handles.
- Added regression tests for timeout rejection, slot cleanup, diagnostic events, normal response completion, and timeout option validation.

## 0.7.4 — Python DAP transport foundation
- Added native Tauri commands to start/stop a fixed Python `debugpy.adapter` process and send bounded DAP JSON messages over framed stdin/stdout.
- Added a JavaScript `DapClient` bridge that connects the existing DAP session coordinator to Tauri events and adapter transport commands.
- Kept the launcher constrained to the Python debugpy module instead of accepting arbitrary executable paths from the webview.
- This is transport groundwork only: no debugger UI, launch configuration flow, breakpoints, stepping, stack frames, or variables panel are integrated yet; debugpy must be installed locally.
- Validation: 61/61 Node tests pass and JavaScript syntax checks pass. Rust/Tauri compilation and end-to-end debugpy runtime were not available for verification.

## 0.7.3 — DAP session coordinator
- Added a transport-agnostic DAP session coordinator that tracks request sequence IDs and resolves out-of-order responses.
- Dispatches adapter events and adapter-originated requests to listeners; subscriptions can be removed cleanly.
- Bounds outstanding requests, handles adapter error responses and transport write failures, and rejects pending work when the session closes.
- Added tests for response correlation, failures, lifecycle cleanup, event dispatch, pending-request limits, and breakpoint normalization.
- This remains debugger infrastructure, not an integrated debugger: no Rust adapter process transport or launch/step/stack/variables UI is wired up yet.
- Validation: 61/61 Node tests pass; full Tauri build and desktop runtime remain unverified in this environment.

## 0.7.2 — Recovery-write performance
- Coalesced frequent editor-change recovery writes into a bounded 700 ms periodic write instead of serializing every keystroke.
- Flushes pending recovery state when the window is hidden or page is being left, reducing the chance of losing the latest edits.
- Disposes the scheduler before clearing recovery state on an intentional close, preventing a late lifecycle event from recreating a snapshot the user chose to discard.
- Added deterministic scheduler tests for coalescing, immediate flush, cancellation, disposal, and invalid arguments.
- Validation: 55/55 Node tests and JavaScript syntax checks pass; full Tauri build and real forced-crash behavior still require runtime verification.

# Changelog

## 0.6.4 — Rename synchronization
- Renaming a file or folder now updates affected open tabs using path-segment-aware matching, including nested files and Windows case-insensitive paths.
- Open language-server documents are closed under their old URIs and reopened under their new URIs; stale diagnostics are removed and the active editor language is refreshed.
- Added focused tests for nested paths, sibling-prefix safety, separator variants, and Windows path matching.
- Validation: Node tests and JavaScript syntax checks pass; full Tauri build and live LSP rename behavior still need runtime verification.

## 0.6.2 — LSP document formatting
- Added Format Document command (`Shift+Alt+F`) through the locally running language server.
- Formatting edits are validated and applied atomically; invalid, out-of-bounds, or overlapping edits are rejected.
- Offline-first behavior remains: formatting requires a locally installed and running language server, but does not require internet once installed.

## 0.5.8 — Inline diagnostics and navigation

- Added inline LSP diagnostic underlines and line highlights for errors, warnings, and informational messages.
- Added navigation commands for next and previous diagnostics (`F8` / `Shift+F8`).
- Added safe LSP range mapping with bounds clamping and UTF-16 offset handling.
- Added tests for multi-line, empty, invalid, and Unicode diagnostic ranges.
- Native Tauri/Rust build and runtime integration still require verification on a machine with the Rust toolchain and language servers installed.

# Changelog

## 0.5.7 — LSP-powered editor features
- Added Language Server Protocol completion as an asynchronous CodeMirror completion source, while preserving existing local completions as a fallback.
- Added command-palette actions for hover information and go-to-definition (F12).
- Added basic replies for common server-to-client LSP requests and normalized completion response handling, with unit tests.
- Reopening/saving a file under a new name now updates its LSP document; switching project roots stops the old server.
- Validation: JavaScript syntax checks and all Node tests pass. Native Tauri/Rust compilation and interactive server testing remain unverified.

## 0.5.5 — LSP transport foundation
- Added a native process bridge for Python (`pylsp`) and JavaScript/TypeScript (`typescript-language-server --stdio`) language servers.
- Added bounded Content-Length JSON-RPC framing, per-server message events, and explicit stop commands.
- Added transport helpers and tests for UTF-8 framing, incomplete frames, language IDs, and initialize capabilities.
- This release provided the transport foundation; lifecycle integration and editor-facing features were added in subsequent releases.

## 0.5.4 — HTML completion matcher fix
- Fixed an escaped regular-expression character class that prevented the custom HTML completion source from recognizing ordinary multi-character tag names.
- Extracted the tag-prefix matcher and insertion calculation into small functions with focused regression tests.
- This remains a partial update; LSP integration is tracked in the later 0.5.x releases.

## 0.5.3 — HTML tag completion insertion
- Added a dedicated HTML tag-name completion source for typing after `<`.
- Accepting a tag-name suggestion inserts both the opening and closing tags and places the cursor inside the element.
- Kept CodeMirror's native HTML completion source available for contextual attribute suggestions and other HTML completion behavior.
- Full integration/build verification is intentionally deferred until the planned feature set is implemented.

## 0.5.2 — Native HTML completion and closing tags
- Fixed a completion-source conflict: the custom override previously replaced CodeMirror's native HTML completion provider, which supplies context-aware tag and attribute suggestions.
- HTML files now use the native HTML completion source alongside LiteCode's local snippets and current-file words. Native HTML completion is responsible for context-aware tag completion and closing-tag behavior.
- Removed the custom HTML tag insertion handler to avoid competing with CodeMirror's built-in HTML behavior.
- Validation: JavaScript syntax checks and all 8 existing Node tests pass. A full dependency install/build and interactive UI test remain unverified in this environment.

## 0.5.1 — Completion popup and HTML tag insertion fix
- Replaced the merged completion results with one predictable, prefix-filtered completion source so suggestions have a consistent replacement range and visible options.
- Styled autocomplete labels and details explicitly for both light and dark themes.
- HTML tag completions now insert the closing tag as well and place the cursor inside the opening/closing pair when selected after `<` (for example, selecting `div` after `<di` produces `<div></div>` with the cursor between the tags).
- Kept existing snippets and language-specific completion lists.

## 0.5.0 — Smarter completions
- Added language-aware completion lists for Python, JavaScript/TypeScript, HTML, CSS, SQL, C/C++, Java, Rust, JSON, Markdown, XML/SVG, and YAML.
- Added reusable snippets for common Python, JavaScript, HTML, CSS, and SQL patterns.
- Added local-symbol suggestions from the current document, with duplicate filtering and a scan cap to keep completion responsive on larger files.
- Completion suggestions refresh when the active file's language changes.
- This is editor-side completion, not a Language Server Protocol (LSP) implementation; semantic type checking and project-wide symbol intelligence are not included yet.


## 0.4.1 — Cursor stability fix
- Fixed the cursor anti-blink override targeting the wrong CodeMirror element. The animation now disables on the focused cursor layer, which is the layer CodeMirror actually animates.
- Kept the existing custom caret color and native-caret hiding used with `drawSelection()`.
- No editor logic, file handling, project configuration, or dependencies changed.

## 0.2.0 — Product foundation

- Added a dedicated Settings dialog with Editor, Appearance, and Run & Tools sections.
- Added live controls for editor font size, tab size, word wrap, autosave, color theme, and Python command.
- Added the `Ctrl+,` shortcut and Settings command in the command palette.
- Added keyboard-friendly focus states, responsive layout, subtle surface depth, and reduced-motion support for the Settings dialog.
- Added `PRODUCT_ROADMAP.md` to make the larger product plan and release-quality requirements explicit.
- Updated README and version metadata.

## Verification

- `node --check src/main.js` — passed.
- `node --check src/editor.js` — passed.
- `node --test` — 5 tests passed.
- Full Vite/Tauri build and interactive desktop QA still need to be run in an environment with dependencies and the Rust/Tauri toolchain installed.


## 0.3.0 — Developer workflow foundation
- Added a Source Control view with Git status, staged/unstaged grouping, diff preview, stage/unstage actions, and commit messages.
- Added recent project shortcuts to the welcome screen.
- Added Ctrl+Shift+G and command-palette actions for Source Control.
- Git operations use direct process arguments (not a shell command string) and validate commit messages.


## 0.4.0 — Editor polish and package workflows
- Added a Packages & Dependencies sidebar with guarded install workflows for npm, pnpm, Yarn, Bun, pip, uv, Cargo, Composer, and RubyGems.
- Added project dependency installation actions and explicit confirmation before running package-manager commands in the integrated terminal.
- Moved the quick light/dark theme toggle into Settings and polished the Settings gear interaction.
- Disabled CodeMirror's blinking cursor and hid the native caret to avoid double-cursor flicker.
- Improved editor/preview minimum sizing and made resize handles easier to discover.
- Added package view and install actions to the command palette.


## 0.5.6 — LSP lifecycle integration
- Connected the existing Rust LSP process bridge to a JavaScript client: initialize/initialized handshake, JSON-RPC request tracking and timeouts, stderr/log events, document open/change/close notifications, and cleanup.
- Added command-palette actions to start/restart or stop the project language server. Starting supports Python (`pylsp`) and JavaScript/TypeScript (`typescript-language-server --stdio`), which must be installed separately and available on PATH.
- Reports server diagnostics as concise toast notifications. This release does not yet wire LSP completion, hover, go-to-definition, or inline diagnostic markers into the editor.
- Native Rust/Tauri build and interactive desktop testing remain unverified in this environment.

## 0.5.9 — Problems panel

- Added a Problems activity view that aggregates language-server diagnostics across the current workspace.
- Added severity filtering and text search over diagnostic messages, codes, and paths.
- Added one-click navigation to the diagnostic's file and line/column, opening files when needed.
- Added a workspace-scoped diagnostic count badge and summary for errors/warnings.
- Added unit tests for diagnostic collection, sorting, filtering, and path-boundary checks.


## 0.6.1 — Offline resilience

- Added an advisory Online/Offline status indicator; it never disables local editor features.
- Added clear offline-aware guidance when starting local language servers or launching package-install workflows.
- Documented which workflows are local-first and which may need a network connection.
- Added tests for connection-state labels and network-error classification.
- Important: `navigator.onLine` is only a hint, not a guarantee that a package registry or remote service is reachable.

## 0.6.3 — Crash recovery
- Added a separate local recovery snapshot written on editor changes, independent of the debounced regular session save.
- On startup, restores the newer recovery snapshot when it contains a more recent local editing session.
- Clears recovery data after a normal close, including explicit discard, so discarded edits are not resurrected.
- Added tests for snapshot round-tripping, corrupt data, timestamp selection, and clearing recovery data.

## 0.6.5 — Safe replace preview
- Replaced immediate project-wide replacement with a preview-first workflow.
- Added a native workspace scan that reports exact file and match totals before changes are applied.
- Preview shows representative before/after lines, with a 200-file display cap and an explicit notice when the preview is truncated.
- Applying changes requires an explicit confirmation; changed open buffers are reloaded and synced to the language server.
- Added safety limits for scanned files and file size to the preview path, matching the replacement operation.
- Native Tauri compilation/runtime still needs verification in an environment with Rust and frontend dependencies installed.


## 0.6.6 — Search precision and limits
- Search results now include the first match column and open the editor at that column, including lines containing non-ASCII characters.
- Added a visible result summary and an explicit notice when the 1,000-hit or 100,000-file safety limit is reached.
- Search validates the project root and caps query length; invalid regular expressions now return a readable error.
- JavaScript syntax and existing unit tests pass; native Rust/Tauri compilation and desktop interaction still require verification.


## 0.7.0 — Editor feel and project tasks
- Restored a subtle CodeMirror cursor blink instead of disabling the cursor-layer animation.
- Added gentle horizontal/vertical caret motion with reduced-motion accessibility support.
- Added settings toggles for cursor blink and smooth movement; preferences persist with other editor settings.
- Added named project tasks from `.litecode/tasks.json`, with explicit command confirmation and workspace-contained working directories.
- Added unit tests for task configuration validation and path boundaries.
- Native Tauri build and interactive cursor behavior still require verification on a real desktop build.


## 0.7.1 — DAP protocol foundation and caret polish
- Added a transport-independent Debug Adapter Protocol frame encoder and incremental byte-stream parser.
- Added request creation, response correlation, and breakpoint normalization helpers with input and frame-size validation.
- Added tests for fragmented/multiple frames, UTF-8 byte lengths, malformed frames, oversized payloads, request validation, and breakpoint data.
- Tuned caret transition timing and simplified the caret CSS so the transition targets CodeMirror's position properties; kept native blink configurable.
- This is protocol groundwork only: no adapter process, debugger UI, launch/attach, stepping, variables, or call stack is wired up yet.

## 0.7.5 — Python debugging workflow foundation

- Added a transport-independent Python DAP workflow for initialize/launch, breakpoint synchronization, configuration completion, thread and stack queries, scopes/variables, continue, stepping, pause, and disconnect.
- Added strict argument validation and lifecycle event handling for stopped/running/terminated/exited states.
- Added seven focused workflow tests; full JavaScript test suite passes (68/68).
- This remains an integration foundation: the workflow is not yet wired into a visible Debug panel, and the native Tauri/Rust build plus real debugpy execution have not been verified in this environment.


## 0.7.6 — DAP lifecycle race fix

- Fixed a race where a fast adapter could emit the DAP `initialized` event before the workflow registered its event listeners.
- Lifecycle listeners are now registered before sending `initialize`; initialization failures remove listeners and restore the workflow to `idle`.
- Added regression tests for early initialized events and failed initialization cleanup.
- The debugger is still not connected to a visible UI; native build and real-adapter behavior remain unverified.
