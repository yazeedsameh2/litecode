# Changelog

## 0.6.4 — Rename synchronization
- Renaming a file or folder now updates affected open tabs using path-segment-aware matching, including nested files and Windows case-insensitive paths.
- Open language-server documents are closed under their old URIs and reopened under their new URIs; stale diagnostics are removed and the active editor language is refreshed.
- Added focused tests for nested paths, sibling-prefix safety, separator variants, and Windows path matching.
- Validation: Node tests and JavaScript syntax checks pass; full Tauri build and live LSP rename behavior still need runtime verification.

## 0.6.2 — LSP document formatting
- Added Format Document command (`Shift+Alt+F`) through the locally running language server.
- Formatting edits are validated and applied atomically; invalid, out-of-bounds, or overlapping edits are rejected.
- Offline-first behavior remains: formatting requires a locally installed and running language server, but does not require internet once installed.

## 0.5.8 — Inline diagnostics and navigation

- Added inline LSP diagnostic underlines and line highlights for errors, warnings, and informational messages.
- Added navigation commands for next and previous diagnostics (`F8` / `Shift+F8`).
- Added safe LSP range mapping with bounds clamping and UTF-16 offset handling.
- Added tests for multi-line, empty, invalid, and Unicode diagnostic ranges.
- Native Tauri/Rust build and runtime integration still require verification on a machine with the Rust toolchain and language servers installed.

# Changelog

## 0.5.7 — LSP-powered editor features
- Added Language Server Protocol completion as an asynchronous CodeMirror completion source, while preserving existing local completions as a fallback.
- Added command-palette actions for hover information and go-to-definition (F12).
- Added basic replies for common server-to-client LSP requests and normalized completion response handling, with unit tests.
- Reopening/saving a file under a new name now updates its LSP document; switching project roots stops the old server.
- Validation: JavaScript syntax checks and all Node tests pass. Native Tauri/Rust compilation and interactive server testing remain unverified.

## 0.5.5 — LSP transport foundation
- Added a native process bridge for Python (`pylsp`) and JavaScript/TypeScript (`typescript-language-server --stdio`) language servers.
- Added bounded Content-Length JSON-RPC framing, per-server message events, and explicit stop commands.
- Added transport helpers and tests for UTF-8 framing, incomplete frames, language IDs, and initialize capabilities.
- This release provided the transport foundation; lifecycle integration and editor-facing features were added in subsequent releases.

## 0.5.4 — HTML completion matcher fix
- Fixed an escaped regular-expression character class that prevented the custom HTML completion source from recognizing ordinary multi-character tag names.
- Extracted the tag-prefix matcher and insertion calculation into small functions with focused regression tests.
- This remains a partial update; LSP integration is tracked in the later 0.5.x releases.

## 0.5.3 — HTML tag completion insertion
- Added a dedicated HTML tag-name completion source for typing after `<`.
- Accepting a tag-name suggestion inserts both the opening and closing tags and places the cursor inside the element.
- Kept CodeMirror's native HTML completion source available for contextual attribute suggestions and other HTML completion behavior.
- Full integration/build verification is intentionally deferred until the planned feature set is implemented.

## 0.5.2 — Native HTML completion and closing tags
- Fixed a completion-source conflict: the custom override previously replaced CodeMirror's native HTML completion provider, which supplies context-aware tag and attribute suggestions.
- HTML files now use the native HTML completion source alongside LiteCode's local snippets and current-file words. Native HTML completion is responsible for context-aware tag completion and closing-tag behavior.
- Removed the custom HTML tag insertion handler to avoid competing with CodeMirror's built-in HTML behavior.
- Validation: JavaScript syntax checks and all 8 existing Node tests pass. A full dependency install/build and interactive UI test remain unverified in this environment.

## 0.5.1 — Completion popup and HTML tag insertion fix
- Replaced the merged completion results with one predictable, prefix-filtered completion source so suggestions have a consistent replacement range and visible options.
- Styled autocomplete labels and details explicitly for both light and dark themes.
- HTML tag completions now insert the closing tag as well and place the cursor inside the opening/closing pair when selected after `<` (for example, selecting `div` after `<di` produces `<div></div>` with the cursor between the tags).
- Kept existing snippets and language-specific completion lists.

## 0.5.0 — Smarter completions
- Added language-aware completion lists for Python, JavaScript/TypeScript, HTML, CSS, SQL, C/C++, Java, Rust, JSON, Markdown, XML/SVG, and YAML.
- Added reusable snippets for common Python, JavaScript, HTML, CSS, and SQL patterns.
- Added local-symbol suggestions from the current document, with duplicate filtering and a scan cap to keep completion responsive on larger files.
- Completion suggestions refresh when the active file's language changes.
- This is editor-side completion, not a Language Server Protocol (LSP) implementation; semantic type checking and project-wide symbol intelligence are not included yet.


## 0.4.1 — Cursor stability fix
- Fixed the cursor anti-blink override targeting the wrong CodeMirror element. The animation now disables on the focused cursor layer, which is the layer CodeMirror actually animates.
- Kept the existing custom caret color and native-caret hiding used with `drawSelection()`.
- No editor logic, file handling, project configuration, or dependencies changed.

## 0.2.0 — Product foundation

- Added a dedicated Settings dialog with Editor, Appearance, and Run & Tools sections.
- Added live controls for editor font size, tab size, word wrap, autosave, color theme, and Python command.
- Added the `Ctrl+,` shortcut and Settings command in the command palette.
- Added keyboard-friendly focus states, responsive layout, subtle surface depth, and reduced-motion support for the Settings dialog.
- Added `PRODUCT_ROADMAP.md` to make the larger product plan and release-quality requirements explicit.
- Updated README and version metadata.

## Verification

- `node --check src/main.js` — passed.
- `node --check src/editor.js` — passed.
- `node --test` — 5 tests passed.
- Full Vite/Tauri build and interactive desktop QA still need to be run in an environment with dependencies and the Rust/Tauri toolchain installed.


## 0.3.0 — Developer workflow foundation
- Added a Source Control view with Git status, staged/unstaged grouping, diff preview, stage/unstage actions, and commit messages.
- Added recent project shortcuts to the welcome screen.
- Added Ctrl+Shift+G and command-palette actions for Source Control.
- Git operations use direct process arguments (not a shell command string) and validate commit messages.


## 0.4.0 — Editor polish and package workflows
- Added a Packages & Dependencies sidebar with guarded install workflows for npm, pnpm, Yarn, Bun, pip, uv, Cargo, Composer, and RubyGems.
- Added project dependency installation actions and explicit confirmation before running package-manager commands in the integrated terminal.
- Moved the quick light/dark theme toggle into Settings and polished the Settings gear interaction.
- Disabled CodeMirror's blinking cursor and hid the native caret to avoid double-cursor flicker.
- Improved editor/preview minimum sizing and made resize handles easier to discover.
- Added package view and install actions to the command palette.


## 0.5.6 — LSP lifecycle integration
- Connected the existing Rust LSP process bridge to a JavaScript client: initialize/initialized handshake, JSON-RPC request tracking and timeouts, stderr/log events, document open/change/close notifications, and cleanup.
- Added command-palette actions to start/restart or stop the project language server. Starting supports Python (`pylsp`) and JavaScript/TypeScript (`typescript-language-server --stdio`), which must be installed separately and available on PATH.
- Reports server diagnostics as concise toast notifications. This release does not yet wire LSP completion, hover, go-to-definition, or inline diagnostic markers into the editor.
- Native Rust/Tauri build and interactive desktop testing remain unverified in this environment.

## 0.5.9 — Problems panel

- Added a Problems activity view that aggregates language-server diagnostics across the current workspace.
- Added severity filtering and text search over diagnostic messages, codes, and paths.
- Added one-click navigation to the diagnostic's file and line/column, opening files when needed.
- Added a workspace-scoped diagnostic count badge and summary for errors/warnings.
- Added unit tests for diagnostic collection, sorting, filtering, and path-boundary checks.


## 0.6.1 — Offline resilience

- Added an advisory Online/Offline status indicator; it never disables local editor features.
- Added clear offline-aware guidance when starting local language servers or launching package-install workflows.
- Documented which workflows are local-first and which may need a network connection.
- Added tests for connection-state labels and network-error classification.
- Important: `navigator.onLine` is only a hint, not a guarantee that a package registry or remote service is reachable.

## 0.6.3 — Crash recovery
- Added a separate local recovery snapshot written on editor changes, independent of the debounced regular session save.
- On startup, restores the newer recovery snapshot when it contains a more recent local editing session.
- Clears recovery data after a normal close, including explicit discard, so discarded edits are not resurrected.
- Added tests for snapshot round-tripping, corrupt data, timestamp selection, and clearing recovery data.

## 0.6.5 — Safe replace preview
- Replaced immediate project-wide replacement with a preview-first workflow.
- Added a native workspace scan that reports exact file and match totals before changes are applied.
- Preview shows representative before/after lines, with a 200-file display cap and an explicit notice when the preview is truncated.
- Applying changes requires an explicit confirmation; changed open buffers are reloaded and synced to the language server.
- Added safety limits for scanned files and file size to the preview path, matching the replacement operation.
- Native Tauri compilation/runtime still needs verification in an environment with Rust and frontend dependencies installed.


## 0.6.6 — Search precision and limits
- Search results now include the first match column and open the editor at that column, including lines containing non-ASCII characters.
- Added a visible result summary and an explicit notice when the 1,000-hit or 100,000-file safety limit is reached.
- Search validates the project root and caps query length; invalid regular expressions now return a readable error.
- JavaScript syntax and existing unit tests pass; native Rust/Tauri compilation and desktop interaction still require verification.
