# Changelog

## 0.2.0 — Product foundation

- Added a dedicated Settings dialog with Editor, Appearance, and Run & Tools sections.
- Added live controls for editor font size, tab size, word wrap, autosave, color theme, and Python command.
- Added the `Ctrl+,` shortcut and Settings command in the command palette.
- Added keyboard-friendly focus states, responsive layout, subtle surface depth, and reduced-motion support for the Settings dialog.
- Added `PRODUCT_ROADMAP.md` to make the larger product plan and release-quality requirements explicit.
- Updated README and version metadata.

## Verification

- `node --check src/main.js` — passed.
- `node --check src/editor.js` — passed.
- `node --test` — 5 tests passed.
- Full Vite/Tauri build and interactive desktop QA still need to be run in an environment with dependencies and the Rust/Tauri toolchain installed.


## 0.3.0 — Developer workflow foundation
- Added a Source Control view with Git status, staged/unstaged grouping, diff preview, stage/unstage actions, and commit messages.
- Added recent project shortcuts to the welcome screen.
- Added Ctrl+Shift+G and command-palette actions for Source Control.
- Git operations use direct process arguments (not a shell command string) and validate commit messages.
